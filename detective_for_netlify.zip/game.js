/* ═══════════════════════════════════════════════════════════
   🕵️  UNKNOWN CULPRIT - FULL GAME ENGINE v2.0 (100 LEVELS)
   ═══════════════════════════════════════════════════════════ */

/* ─── GENDER-AWARE CHARACTER PHOTOS ──────────────────────── */
// Female chars: files ending with 'f' (female)
const FEMALE_CHARS = ['char_2f', 'char_7f', 'char_9f', 'char_11f', 'char_13f', 'char_14f'];
const MALE_CHARS = [
  'char_16', // فني كمبيوتر
  'char_17', // سائق سيارة أجرة
  'char_18', // طبيب شرعي
  'char_19', // موظف أرشيف
  'char_20', // قاتل مأجور
  'char_1', 'char_3', 'char_4', 'char_5', 'char_6', 'char_8', 'char_10', 'char_12', 'char_15'
];

// Arabic female name indicators
const FEMALE_NAME_HINTS = [
  'عبير', 'آية', 'نور', 'ريم', 'سارة', 'هناء', 'رانيا', 'ندى', 'لمى', 'إيمان', 'دينا', 'هدى', 'منى',
  'سمر', 'رشا', 'غادة', 'مريم', 'أميرة', 'ياسمين', 'روان', 'لينا', 'هبة', 'شيرين', 'نيفين', 'فاطمة',
  'زينب', 'أسماء', 'خديجة', 'عائشة', 'حنان', 'سحر', 'ابتسام', 'إبتسام', 'وفاء', 'سهام', 'هالة',
  'أمل', 'شيماء', 'ناهد', 'فايزة', 'فريدة', 'إلهام', 'راندا', 'إنجي', 'ميرنا', 'شادية', 'نيللي',
  'نيلي', 'لوسي', 'دعاء', 'رحاب', 'أروى', 'ألاء', 'علا', 'ولاء', 'نجلاء', 'سلمى', 'ليلى', 'نهى',
  'ميار', 'ميس', 'رنا', 'تالا', 'جنى', 'لارا', 'لارة', 'دلال', 'أفنان', 'رغد', 'ريف', 'ريهام',
  'شهد', 'كوثر', 'بسمة', 'بسمه', 'هيا', 'هيام', 'أهداف', 'نادية', 'نرمين', 'منال', 'مروة', 'مها',
  'نادين', 'كريمة', 'حليمة', 'حسناء', 'فاتن', 'فاتنة', 'صفاء', 'سناء', 'سمية', 'سميرة', 'صباح',
];

function isFemale(name) {
  if (!name) return false;
  const n = name.trim();
  const firstWord = n.split(' ')[0];
  if (firstWord.endsWith('ة') || firstWord.endsWith('ى') || firstWord.endsWith('اء')) return true;
  return FEMALE_NAME_HINTS.some(fn => n.includes(fn));
}

function getCharImage(suspect, suspectRole, levelNum, idx) {
  let name = '';
  let role = '';
  let img = '';

  if (typeof suspect === 'object' && suspect !== null) {
    name = suspect.name || '';
    role = (suspect.role || '').toLowerCase();
    img = suspect.image || '';
  } else {
    name = suspect || '';
    role = (suspectRole || '').toLowerCase();
  }

  // 1. Direct explicit image from level data
  if (img) {
    return img;
  }

  const female = isFemale(name);

  // 2. Realistic Role Mapping
  if (role.includes('خادمة') || role.includes('مدبرة') || role.includes('مربية')) return 'images/char_maid.png';
  if (role.includes('نظافة') || role.includes('فراش') || role.includes('بواب')) return 'images/char_cleaner.png';
  if (role.includes('طباخ') || role.includes('شيف') || role.includes('نادل')) return 'images/char_chef.png';
  if (role.includes('محاسب') || role.includes('مالي') || role.includes('حسابات') || role.includes('خزينة')) return 'images/char_accountant.png';
  if (role.includes('سائق') || role.includes('أجرة') || role.includes('تاكسي')) return 'images/char_17.png';
  if (role.includes('كمبيوتر') || role.includes('تقني') || role.includes('معلومات') || role.includes('مطوّر') || role.includes('مبرمج') || role.includes('هاكر')) return female ? 'images/char_14f.png' : 'images/char_16.png';
  if (role.includes('طبيب') || role.includes('دكتور') || role.includes('صيدل') || role.includes('شرعي')) return 'images/char_18.png';
  if (role.includes('أرشيف') || role.includes('مكتبة') || role.includes('سجلات')) return 'images/char_19.png';
  if (role.includes('آثار') || role.includes('سياحة') || role.includes('استقبال')) return 'images/char_11f.png';
  if (role.includes('حارس') || role.includes('أمن') || role.includes('حراسة') || role.includes('شخصي')) return (role.includes('متحف') || role.includes('عقار')) ? 'images/char_12.png' : 'images/char_guard.png';
  if (role.includes('سكرتير') || role.includes('مساعد') || role.includes('مديرة مكتب')) return female ? 'images/char_2f.png' : 'images/char_1.png';
  if (role.includes('تأمين') || role.includes('مشتريات') || role.includes('أمن معلوماتي')) return female ? 'images/char_9f.png' : 'images/char_16.png';
  if (role.includes('صديقة') || role.includes('شريكة')) return female ? 'images/char_13f.png' : 'images/char_3.png';
  if (role.includes('عميل ثري') || role.includes('مجوهرات') || role.includes('موزع')) return 'images/char_4.png';
  if (role.includes('محقق خاص')) return 'images/char_15.png';
  if (role.includes('منافس') || role.includes('قاتل') || role.includes('مشبوه')) return 'images/char_20.png';
  if (role.includes('نائب المدير') || role.includes('الشريك التجاري') || role.includes('الشريك في الصفقة') || role.includes('الشريك المقرّب')) return female ? 'images/char_7f.png' : 'images/char_3.png';

  // 3. Realistic Fallback Pool by gender
  if (female) {
    return 'images/char_2f.png';
  }
  return 'images/char_1.png';
}

/* ─── STATE ─────────────────────────────────────────────── */
let LEVELS_DATA = [];          // loaded from levels.json
let state = {
  level: 1,
  coins: 0,
  hints: 0,
  xp: parseInt(localStorage.getItem('unknown_culprit_xp') || '0'),
  completed: new Set(),
  currentCase: null,
  activeSuspect: null,
  collectedEvidence: [],
  notebook: { discrepancies: [], timeline: [], clues: [] },
  timerSec: 600,
  timerInterval: null,
  timerRunning: false,
};

/* ─── DETECTIVE AUDIO SYNTHESIZER ENGINE ────────────────── */
const AudioEngine = {
  ctx: null,
  musicEnabled: true,
  isStarted: false,
  padOsc1: null,
  padOsc2: null,
  gainNode: null,
  filterNode: null,
  timerLoop: null,

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    if (!this.isStarted && this.ctx) {
      this.isStarted = true;
      this.startAmbientMusic();
    }
  },

  async startAmbientMusic() {
    if (!this.musicEnabled) return;
    this.stopAmbientMusic();

    // 1. First try HTML5 audio element
    const bgmEl = document.getElementById('game-bgm');
    if (bgmEl) {
      bgmEl.volume = 0.35;
      bgmEl.loop = true;
      try {
        await bgmEl.play();
        return;
      } catch (e) {
        // Fallback to synth if audio element is blocked
      }
    }

    if (!this.ctx) return;
    this._startSynthPad();
  },

  _startSynthPad() {
    if (!this.ctx) return;
    this.stopAmbientMusic();

    try {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      this.gainNode = this.ctx.createGain();
      // Smooth attack ramp to prevent clicks
      this.gainNode.gain.setValueAtTime(0.001, this.ctx.currentTime);
      this.gainNode.gain.exponentialRampToValueAtTime(0.025, this.ctx.currentTime + 1.5);

      // Warm lowpass filter to remove any harsh digital noise or hiss
      this.filterNode = this.ctx.createBiquadFilter();
      this.filterNode.type = 'lowpass';
      this.filterNode.frequency.setValueAtTime(220, this.ctx.currentTime);
      this.filterNode.Q.setValueAtTime(0.5, this.ctx.currentTime);

      // Deep soothing detective mystery ambient chords (pure sine waves)
      this.padOsc1 = this.ctx.createOscillator();
      this.padOsc1.type = 'sine';
      this.padOsc1.frequency.setValueAtTime(146.83, this.ctx.currentTime); // D3 (warm tonic)

      this.padOsc2 = this.ctx.createOscillator();
      this.padOsc2.type = 'sine';
      this.padOsc2.frequency.setValueAtTime(220.00, this.ctx.currentTime); // A3 (pure fifth)

      this.padOsc1.connect(this.filterNode);
      this.padOsc2.connect(this.filterNode);
      this.filterNode.connect(this.gainNode);
      this.gainNode.connect(this.ctx.destination);

      this.padOsc1.start();
      this.padOsc2.start();
    } catch (e) {
      console.warn('Audio start error:', e);
    }
  },

  stopAmbientMusic() {
    const bgmEl = document.getElementById('game-bgm');
    if (bgmEl) {
      try { bgmEl.pause(); } catch (e) { }
    }
    if (this._musicSource) { try { this._musicSource.stop(); } catch (e) { } this._musicSource = null; }
    if (this.timerLoop) clearInterval(this.timerLoop);
    if (this.gainNode && this.ctx) {
      try {
        this.gainNode.gain.linearRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);
      } catch (e) {}
    }
    setTimeout(() => {
      if (this.padOsc1) { try { this.padOsc1.stop(); } catch (e) { } }
      if (this.padOsc2) { try { this.padOsc2.stop(); } catch (e) { } }
      this.padOsc1 = null;
      this.padOsc2 = null;
    }, 350);
  },

  playHeartbeat() {
    if (!this.ctx || !this.musicEnabled) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(60, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.18);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.2);
    } catch (e) { }
  },

  playClickSFX() {
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(200, this.ctx.currentTime + 0.04);
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.05);
    } catch (e) { }
  },

  playClueSFX() {
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, this.ctx.currentTime);
      osc.frequency.setValueAtTime(659.25, this.ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.3);
    } catch (e) { }
  },

  playVictorySFX() {
    this.init();
    if (!this.ctx) return;
    try {
      const notes = [440, 554.37, 659.25, 880];
      notes.forEach((f, i) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, this.ctx.currentTime + i * 0.08);
        gain.gain.setValueAtTime(0.2, this.ctx.currentTime + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + i * 0.08 + 0.4);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(this.ctx.currentTime + i * 0.08);
        osc.stop(this.ctx.currentTime + i * 0.08 + 0.4);
      });
    } catch (e) { }
  },

  playDefeatSFX() {
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(40, this.ctx.currentTime + 0.6);
      gain.gain.setValueAtTime(0.25, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.6);
    } catch (e) { }
  }
};

/* ─── TUTORIAL & GUIDED SIGNALS MANAGER ─────────────────── */
const TutorialManager = {
  currentSlide: 1,
  maxSlides: 5,
  guidedStep: 1,

  init() {
    this.bindEvents();
  },

  bindEvents() {
    on('btn-open-tutorial', 'click', () => this.openTutorial());
    on('btn-splash-tutorial', 'click', () => this.openTutorial());
    on('btn-close-tutorial', 'click', () => this.closeTutorial());
    on('btn-tutorial-prev', 'click', () => this.prevSlide());
    on('btn-tutorial-next', 'click', () => this.nextSlide());
    on('btn-tutorial-finish', 'click', () => {
      this.closeTutorial();
      if (state.level === 1) {
        this.triggerLevel1Guide(1);
      }
    });
    on('btn-close-guide-banner', 'click', () => this.hideGuideBanner());

    // Dot clicks
    document.querySelectorAll('#tutorial-dots .dot').forEach(dot => {
      dot.addEventListener('click', (e) => {
        const idx = parseInt(e.target.getAttribute('data-index') || '1');
        this.goToSlide(idx);
      });
    });
  },

  openTutorial() {
    this.goToSlide(1);
    showModal('tutorial-modal');
    playClick();
  },

  closeTutorial() {
    hideModal('tutorial-modal');
    try { localStorage.setItem('uc_tutorial_seen', 'true'); } catch (e) { }
  },

  goToSlide(num) {
    this.currentSlide = Math.max(1, Math.min(this.maxSlides, num));

    // Update slides
    document.querySelectorAll('.tutorial-slide').forEach(s => {
      s.classList.remove('active');
      if (parseInt(s.getAttribute('data-slide')) === this.currentSlide) {
        s.classList.add('active');
      }
    });

    // Update dots
    document.querySelectorAll('#tutorial-dots .dot').forEach(d => {
      d.classList.remove('active');
      if (parseInt(d.getAttribute('data-index')) === this.currentSlide) {
        d.classList.add('active');
      }
    });

    // Update buttons
    const prevBtn = document.getElementById('btn-tutorial-prev');
    const nextBtn = document.getElementById('btn-tutorial-next');
    const finishBtn = document.getElementById('btn-tutorial-finish');

    if (prevBtn) prevBtn.style.visibility = this.currentSlide > 1 ? 'visible' : 'hidden';
    if (this.currentSlide === this.maxSlides) {
      if (nextBtn) nextBtn.style.display = 'none';
      if (finishBtn) finishBtn.style.display = 'block';
    } else {
      if (nextBtn) nextBtn.style.display = 'block';
      if (finishBtn) finishBtn.style.display = 'none';
    }
  },

  nextSlide() {
    if (this.currentSlide < this.maxSlides) {
      this.goToSlide(this.currentSlide + 1);
      playClick();
    }
  },

  prevSlide() {
    if (this.currentSlide > 1) {
      this.goToSlide(this.currentSlide - 1);
      playClick();
    }
  },

  checkLevelStart(lvlNum) {
    if (lvlNum === 1) {
      let seen = false;
      try { seen = localStorage.getItem('uc_tutorial_seen') === 'true'; } catch (e) { }
      if (!seen) {
        setTimeout(() => this.openTutorial(), 500);
      } else {
        setTimeout(() => this.triggerLevel1Guide(1), 500);
      }
    } else {
      this.hideGuideBanner();
    }
  },

  /* Level 1 Guided Interactive Hints & Signals */
  triggerLevel1Guide(step) {
    if (state.level !== 1) {
      this.hideGuideBanner();
      return;
    }

    this.guidedStep = step;
    this.clearPointers();

    const banner = document.getElementById('level1-guide-banner');
    const bannerTitle = document.getElementById('guide-banner-title');
    const bannerText = document.getElementById('guide-banner-text');

    if (!banner || !bannerText) return;
    banner.style.display = 'flex';

    if (step === 1) {
      // Step 1: Case dashboard - Click crime scene
      bannerTitle.textContent = '💡 إشارة المحقق (خطوة 1 من 4)';
      bannerText.textContent = 'ادخل "مسرح الجريمة 🔬" للبحث عن الأدلة القاطعة!';

      const targetBtn = document.getElementById('btn-crime-scene');
      if (targetBtn) {
        targetBtn.classList.add('guided-pulse-target');
        this.positionPointer(targetBtn, 'اضغط هنا لتفتيش مسرح الجريمة 🔬');
      }
    } else if (step === 2) {
      // Step 2: In Crime Scene - Collect evidence
      bannerTitle.textContent = '💡 إشارة المحقق (خطوة 2 من 4)';
      bannerText.textContent = 'اضغط على مكبر البحث 🔍 لجمع الدليل الأول وحفظه!';

      const targetHotspot = document.getElementById('btn-collect-evidence');
      if (targetHotspot) {
        targetHotspot.classList.add('guided-pulse-target');
        this.positionPointer(targetHotspot, 'اضغط هنا لجمع الدليل 🔍');
      }
    } else if (step === 3) {
      // Step 3: Evidence collected - Go back or open drawer
      bannerTitle.textContent = '💡 إشارة المحقق (خطوة 3 من 4)';
      bannerText.textContent = 'ممتاز! تم جمع الدليل. ارجع للوحة القضية واستجوب المشتبه بهم.';

      const backBtn = document.getElementById('btn-back-from-scene');
      if (backBtn) {
        backBtn.classList.add('guided-pulse-target');
        this.positionPointer(backBtn, 'اضغط للرجوع واستجواب المتهمين ➔');
      }
    } else if (step === 4) {
      // Step 4: Interrogate suspects
      bannerTitle.textContent = '💡 إشارة المحقق (خطوة 4 من 4)';
      bannerText.textContent = 'اضغط على إحدى بطاقات المشتبه بهم للتحقيق واستجلاء الحقيقة!';

      const polaroids = document.querySelectorAll('.polaroid-card');
      if (polaroids.length > 0) {
        polaroids[0].classList.add('guided-pulse-target');
        this.positionPointer(polaroids[0], 'اضغط لبدء الاستجواب 🔍');
      }
    } else if (step === 5) {
      // Step 5: Accuse
      bannerTitle.textContent = '💡 إشارة ختامية: إصدار الاتهام';
      bannerText.textContent = 'اضغط على "تقديم لائحة الاتهام ⚖️" لتحديد عناصر القضية وإنهاء الجريمة!';

      const accuseBtn = document.getElementById('btn-accuse-suspect');
      if (accuseBtn) {
        accuseBtn.classList.add('guided-pulse-target');
        this.positionPointer(accuseBtn, 'قدّم لائحة الاتهام الآن ⚖️');
      }
    }
  },

  positionPointer(targetEl, text) {
    const tooltip = document.getElementById('tutorial-pointer-tooltip');
    const tooltipText = document.getElementById('pointer-tooltip-text');
    if (!tooltip || !targetEl) return;

    if (tooltipText) tooltipText.textContent = text;

    setTimeout(() => {
      const rect = targetEl.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) return;
      tooltip.style.display = 'flex';
      tooltip.style.top = Math.max(70, (rect.top - 55)) + 'px';
      tooltip.style.left = Math.max(10, (rect.left + rect.width / 2 - 80)) + 'px';
    }, 100);
  },

  clearPointers() {
    document.querySelectorAll('.guided-pulse-target').forEach(el => el.classList.remove('guided-pulse-target'));
    const tooltip = document.getElementById('tutorial-pointer-tooltip');
    if (tooltip) tooltip.style.display = 'none';
  },

  hideGuideBanner() {
    const banner = document.getElementById('level1-guide-banner');
    if (banner) banner.style.display = 'none';
    this.clearPointers();
  }
};

/* ─── HELPER: BILINGUAL LEVELS DATA LOADER ───────────────── */
function getActiveLevels() {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  if (isEn && typeof window !== 'undefined' && window.PRELOADED_LEVELS_EN && Array.isArray(window.PRELOADED_LEVELS_EN) && window.PRELOADED_LEVELS_EN.length > 0) {
    return window.PRELOADED_LEVELS_EN;
  }
  if (typeof window !== 'undefined' && window.PRELOADED_LEVELS && Array.isArray(window.PRELOADED_LEVELS) && window.PRELOADED_LEVELS.length > 0) {
    return window.PRELOADED_LEVELS;
  }
  return LEVELS_DATA || [];
}

/* ─── LANGUAGE SELECTION ON STARTUP ──────────────────────── */
window.selectLanguageAndStart = function (lang) {
  if (typeof I18nManager !== 'undefined') {
    I18nManager.setLanguage(lang);
  }
  try {
    localStorage.setItem('uc_user_selected_lang', lang);
  } catch (e) { }

  LEVELS_DATA = getActiveLevels();
  showScreen('splash-screen', 'forward');
  updateSplashProgress();
  updateHUD();
  updateRankUI();
  playClick();
  playBGM();
};

/* ─── BOOT ───────────────────────────────────────────────── */
window.addEventListener('DOMContentLoaded', async () => {
  if (typeof I18nManager !== 'undefined') I18nManager.init();
  LEVELS_DATA = getActiveLevels();
  loadProgress();

  showScreen('lang-select-screen');

  updateSplashProgress();
  bindEvents();
  TutorialManager.init();
  tryFetchLevelsFallback();
  document.addEventListener('click', () => { AudioEngine.init(); playBGM(); }, { once: true });
  document.addEventListener('touchstart', () => { AudioEngine.init(); playBGM(); }, { once: true, passive: true });
});

/* Language Change Hook */
window.onLanguageChanged = function (lang) {
  LEVELS_DATA = getActiveLevels();
  if (state.level && LEVELS_DATA.length > 0) {
    state.currentCase = LEVELS_DATA.find(l => (l.level || l.Level) === state.level) || LEVELS_DATA[0];
  }
  updateSplashProgress();
  updateHUD();
  updateRankUI();

  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen && activeScreen.id === 'case-dashboard-screen') {
    renderDashboard();
  } else if (activeScreen && activeScreen.id === 'case-intro-screen' && state.currentCase) {
    showCaseIntroScreen(state.currentCase);
  } else if (activeScreen && activeScreen.id === 'interrogation-screen' && state.activeSuspect && state.currentCase) {
    if (state.currentCase.suspects) {
      const s = state.currentCase.suspects.find(x => x.image === state.activeSuspect.image) || state.currentCase.suspects[0];
      if (s) startInterrogation(s, 0);
    }
  } else if (activeScreen && activeScreen.id === 'crime-scene-screen') {
    goToCrimeScene();
  }

  const levelsModal = document.getElementById('levels-modal');
  if (levelsModal && levelsModal.classList.contains('active')) {
    const grid = document.getElementById('modal-levels-grid');
    if (grid) renderLevelsGrid(grid);
  }
};

let resolveLevelsFn;
let isLevelsLoaded = false;
const levelsDataPromise = new Promise(resolve => {
  resolveLevelsFn = () => {
    isLevelsLoaded = true;
    resolve();
  };
});

// Check if preloaded from script tag
if (typeof window !== 'undefined' && ((window.PRELOADED_LEVELS && window.PRELOADED_LEVELS.length > 0) || (window.PRELOADED_LEVELS_EN && window.PRELOADED_LEVELS_EN.length > 0))) {
  LEVELS_DATA = getActiveLevels();
  isLevelsLoaded = true;
  if (resolveLevelsFn) resolveLevelsFn();
}

// This function is called by Flutter to inject the levels data
window.receiveLevels = function (jsonData) {
  console.log('Levels data received from Flutter and stored.');
  if (jsonData && Array.isArray(jsonData) && jsonData.length > 0) {
    LEVELS_DATA = jsonData;
    resolveLevelsFn();
  }
};

async function tryFetchLevelsFallback() {
  if (typeof window !== 'undefined' && ((window.PRELOADED_LEVELS && window.PRELOADED_LEVELS.length > 0) || (window.PRELOADED_LEVELS_EN && window.PRELOADED_LEVELS_EN.length > 0))) {
    LEVELS_DATA = getActiveLevels();
    isLevelsLoaded = true;
    resolveLevelsFn();
    return;
  }
  if (isLevelsLoaded && LEVELS_DATA.length > 0) return;
  try {
    const res = await fetch('levels.json');
    if (res.ok) {
      const data = await res.json();
      if (data && data.length > 0) {
        LEVELS_DATA = data;
        resolveLevelsFn();
      }
    }
  } catch (e) {
    console.warn('Fallback fetch levels.json failed:', e);
  }
}

/* ─── PERSISTENCE ────────────────────────────────────────── */
function updateSplashProgress() {
  const completedCount = state.completed.size;
  const percent = Math.round((completedCount / 100) * 100);
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const text = isEn 
    ? `🏆 Progress: ${percent}% (${completedCount}/100 Cases Solved)`
    : `🏆 نسبة الإنجاز: ${percent}% (${completedCount}/100 قضية)`;
  setText('splash-progress-text', text);
  setText('overall-progress-text', `${percent}% (${completedCount}/100)`);
  const bar = document.getElementById('overall-progress-bar');
  if (bar) bar.style.width = `${percent}%`;
}

function saveProgress() {
  try {
    localStorage.setItem('uc_coins', state.coins);
    localStorage.setItem('uc_hints', state.hints);
    localStorage.setItem('uc_level', state.level);
    localStorage.setItem('uc_completed', JSON.stringify([...state.completed]));
    updateSplashProgress();
  } catch (e) { }
}
function loadProgress() {
  try {
    state.coins = parseInt(localStorage.getItem('uc_coins') || '0');
    state.hints = 0; // All hints require watching a rewarded ad
    state.level = parseInt(localStorage.getItem('uc_level') || '1');
    const comp = JSON.parse(localStorage.getItem('uc_completed') || '[]');
    state.completed = new Set(comp);
    updateSplashProgress();
  } catch (e) { }
}

/* ─── HUD ────────────────────────────────────────────────── */
function updateHUD() {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  setText('hud-coins', state.coins.toLocaleString(isEn ? 'en-US' : 'ar-EG'));
  setText('hud-hints', isEn ? 'Hint 📺' : 'تلميح 📺');
  setText('hud-level', state.level);
}

/* ─── SCREENS ────────────────────────────────────────────── */
function showScreen(id, direction = 'none') {
  document.querySelectorAll('.screen').forEach(s => {
    s.classList.remove('active', 'slide-in-right', 'slide-in-left');
  });
  const target = document.getElementById(id);
  if (!target) return;
  target.classList.add('active');
  if (direction === 'forward') target.classList.add('slide-in-right');
  if (direction === 'back') target.classList.add('slide-in-left');

  // Hide HUD on splash, show on game screens
  const hud = document.getElementById('hud-bar');
  if (hud) hud.style.display = id === 'splash-screen' ? 'none' : 'flex';
}

/* ─── LEVEL LOADER ───────────────────────────────────────── */
async function loadLevel(lvlNum, skipIntro = false) {
  stopTimer();
  lvlNum = Math.max(1, Math.min(100, lvlNum));
  state.level = lvlNum;
  state.collectedEvidence = [];
  state.activeSuspect = null;

  LEVELS_DATA = getActiveLevels();

  let caseData = null;
  try {
    if (!isLevelsLoaded && (!LEVELS_DATA || LEVELS_DATA.length === 0)) {
      await Promise.race([
        levelsDataPromise,
        tryFetchLevelsFallback(),
        new Promise(res => setTimeout(res, 1200))
      ]);
      LEVELS_DATA = getActiveLevels();
    }
    caseData = (LEVELS_DATA || []).find(l => (l.level || l.Level) === lvlNum);

    if (!caseData) {
      throw new Error(`No data returned for level ${lvlNum}`);
    }
  } catch (error) {
    const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
    alert(isEn ? `⚠️ Failed to load data for case #${lvlNum}.` : `⚠️ حدث خطأ أثناء تحميل بيانات المستوى ${lvlNum}. قد لا يكون هذا المستوى متاحًا بعد.`);
    console.error("Level Load Error:", error);
    return;
  }
  state.currentCase = caseData;

  updateHUD();
  renderDashboard();
  saveProgress();

  if (skipIntro) {
    showScreen('case-dashboard-screen', 'forward');
    startTimer();
    TutorialManager.checkLevelStart(lvlNum);
  } else {
    showCaseIntroScreen(caseData);
  }
}

/* ─── RENDER DASHBOARD ───────────────────────────────────── */
function renderDashboard() {
  const c = state.currentCase;
  if (!c) return;

  // Initialize Notebook & Category for new level
  if (!state.notebook || state.notebookLevel !== c.level) {
    state.notebookLevel = c.level;
    state.notebook = {
      discrepancies: [],
      timeline: [
        { title: 'اكتشاف موقع الجريمة', desc: `تم البلاغ عن الجريمة في ${c.sceneLocation || 'موقع الحادثة'}.` },
        { title: 'معاينة الضحية', desc: `الضحية: ${c.victimName}.` }
      ],
      clues: []
    };
  }

  // Update Ranks & Badges
  updateRankUI();
  renderNotebook();
  setText('discovery-count', `${state.collectedEvidence.length} / 3`);

  // Category badge
  const catEl = document.getElementById('dashboard-category-badge');
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  if (catEl) {
    const catsAr = [
      { name: '🔪 جريمة قتل', bg: 'rgba(255,65,108,0.2)', color: '#FF416C' },
      { name: '💎 سرقة وتزوير', bg: 'rgba(255,183,3,0.2)', color: '#FFB703' },
      { name: '👤 اختفاء واختطاف', bg: 'rgba(168,85,247,0.2)', color: '#A855F7' },
      { name: '💻 جريمة إلكترونية', bg: 'rgba(0,242,254,0.2)', color: '#00F2FE' },
      { name: '⚡ قضية معقدة', bg: 'rgba(16,185,129,0.2)', color: '#10B981' }
    ];
    const catsEn = [
      { name: '🔪 Homicide', bg: 'rgba(255,65,108,0.2)', color: '#FF416C' },
      { name: '💎 Theft & Heist', bg: 'rgba(255,183,3,0.2)', color: '#FFB703' },
      { name: '👤 Abduction & Hostage', bg: 'rgba(168,85,247,0.2)', color: '#A855F7' },
      { name: '💻 Cyber Breach', bg: 'rgba(0,242,254,0.2)', color: '#00F2FE' },
      { name: '⚡ Complex Mystery', bg: 'rgba(16,185,129,0.2)', color: '#10B981' }
    ];
    const cats = isEn ? catsEn : catsAr;
    const cat = cats[(c.level - 1) % cats.length];
    catEl.textContent = cat.name;
    catEl.style.background = cat.bg;
    catEl.style.color = cat.color;
    catEl.style.borderColor = cat.color;
  }

  // Badge + titles
  setText('dashboard-level-badge', isEn ? `Case ${c.level}` : `المستوى ${c.level}`);
  setText('dashboard-case-title', c.title);
  setText('dashboard-crime-type', isEn ? `Crime: ${c.crimeType}` : `نوع الجريمة: ${c.crimeType}`);
  setText('dashboard-location', `📍 ${c.sceneLocation}`);
  setText('dashboard-victim', isEn ? `🎭 Victim: ${c.victimName}` : `🎭 الضحية: ${c.victimName}`);
  setText('dashboard-description', c.description);

  // IQ difficulty badge
  const iq = c.iqLevel || 80;
  const iqEl = document.getElementById('dashboard-iq-badge');
  if (iqEl) {
    const iqMapAr = {
      80: { cls: 'iq-80', label: '🟢 IQ 80 — سهل' },
      100: { cls: 'iq-100', label: '🔵 IQ 100 — متوسط' },
      120: { cls: 'iq-120', label: '🟠 IQ 120 — صعب' },
      140: { cls: 'iq-140', label: '🔴 IQ 140 — خبير' },
      160: { cls: 'iq-160', label: '⚫ IQ 160 — أسطوري' }
    };
    const iqMapEn = {
      80: { cls: 'iq-80', label: '🟢 IQ 80 — Easy' },
      100: { cls: 'iq-100', label: '🔵 IQ 100 — Moderate' },
      120: { cls: 'iq-120', label: '🟠 IQ 120 — Hard' },
      140: { cls: 'iq-140', label: '🔴 IQ 140 — Mastermind' },
      160: { cls: 'iq-160', label: '⚫ IQ 160 — Legendary' }
    };
    const iqMap = isEn ? iqMapEn : iqMapAr;
    const info = iqMap[iq] || iqMap[80];
    iqEl.className = `iq-badge ${info.cls}`;
    iqEl.textContent = info.label;
  }

  // Stars / completed badge
  const starEl = document.getElementById('dashboard-star');
  if (starEl) {
    starEl.textContent = state.completed.has(c.level) ? (isEn ? '⭐ Solved' : '⭐ مكتملة') : '';
  }

  // Render 3 Polaroid Cards
  const container = document.getElementById('polaroids-list');
  if (!container) return;
  container.innerHTML = '';

  // Deterministically shuffle suspect cards per level so culprit position varies (1st, 2nd, or 3rd)
  if (!c._displaySuspects) {
    const arr = [...c.suspects];
    const shift = (c.level * 2 + 1) % arr.length;
    c._displaySuspects = arr.slice(shift).concat(arr.slice(0, shift));
  }
  const displaySuspects = c._displaySuspects;

  displaySuspects.forEach((suspect, i) => {
    const imgSrc = getCharImage(suspect, suspect.role, c.level, i);
    const fallbackImg = isFemale(suspect.name) ? 'images/char_2f.png' : 'images/char_1.png';
    const card = document.createElement('div');
    card.className = 'polaroid-card';
    card.innerHTML = `
      <div class="polaroid-img-box">
        <img src="${imgSrc}" onerror="if(!this._t){this._t=1;this.src='${fallbackImg}';}else{this.onerror=null;this.src='images/suspect_1.png';}" class="polaroid-img" alt="${suspect.name}">
      </div>
      <div class="polaroid-name">${suspect.name}</div>
      <div class="polaroid-role">${suspect.role}</div>
      <div class="polaroid-cta">${isEn ? 'Interrogate 🔍' : 'استجواب 🔍'}</div>
    `;
    card.onclick = () => startInterrogation(suspect, i);
    container.appendChild(card);
  });
}

/* ─── INTERROGATION ──────────────────────────────────────── */
let suspectPressure = 0;

function setPressure(val) {
  suspectPressure = Math.min(100, Math.max(0, val));
  const fill = document.getElementById('pressure-bar-fill');
  const pct = document.getElementById('pressure-pct');
  const warn = document.getElementById('lawyer-warning');
  if (!fill) return;
  fill.style.width = suspectPressure + '%';
  if (pct) pct.textContent = suspectPressure + '%';
  fill.className = 'pressure-bar-fill' +
    (suspectPressure >= 80 ? ' danger' : suspectPressure >= 50 ? ' warn' : '');
  if (warn) warn.style.display = suspectPressure >= 100 ? 'block' : 'none';

  // ── 3D Engine: update suspect body language & expressions
  if (typeof update3DSuspectExpression === 'function') {
    update3DSuspectExpression(suspectPressure, state.collectedEvidence.length > 0);
  }
  // Spotlight intensifies as pressure rises
  if (typeof apply3DSpotlightEffect === 'function') {
    apply3DSpotlightEffect(suspectPressure >= 60);
  }

  // ── 2D Interrogation Engine: live state updates
  if (typeof window.Interrogation2D !== 'undefined' && window.Interrogation2D.setPressure) {
    window.Interrogation2D.setPressure(suspectPressure);
  }
}

function startInterrogation(suspect, idx) {
  if (!state.timerRunning) startTimer();
  state.activeSuspect = suspect;
  suspectPressure = 0;
  setPressure(0);

  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const imgSrc = getCharImage(suspect, suspect.role, state.level, idx);
  const fallbackImg = isFemale(suspect.name) ? 'images/char_2f.png' : 'images/char_1.png';
  const imgEl = document.getElementById('interrogate-img');
  if (imgEl) {
    imgEl.src = imgSrc;
    imgEl.onerror = function() {
      if (!this._t) { this._t = 1; this.src = fallbackImg; }
      else { this.onerror = null; this.src = 'images/suspect_1.png'; }
    };
  }
  setText('interrogate-speaker', suspect.name);
  setText('interrogate-role', suspect.role);
  setText('interrogate-dialog-text', `"${suspect.statement}"`);

  const c = state.currentCase;
  const isCulprit = suspect.name === c.culpritName;

  const questionsAr = [
    {
      q: 'أين كنت وقت الجريمة بالضبط؟',
      pressure: 10,
      a: `"${suspect.statement}"`
    },
    {
      q: `بصفتك ${suspect.role}، لماذا تواجدت في موقع الأحداث؟`,
      pressure: 15,
      a: `"${isCulprit ? 'كنت أنفذ مهامي الاعتيادية، ولم أتخيل أن يحوم الشك حولي!' : 'تواجدي في ' + (c.sceneLocation || 'الموقع') + ' طبيعي بحكم عملي كـ ' + suspect.role + '.'}"`
    },
    {
      q: 'ما ردك على الشبهات الموجهة ضدك؟',
      pressure: 25,
      a: `"${isCulprit ? 'هذه اتهامات سخيفة، هل لديك دليل مادي حقيقي يثبت اتهامي؟' : 'أنا بريء تماماً! ابحث في مسرح الجريمة وستكتشف الدليل القاطع بنفسك.'}"`
    },
    {
      q: 'هل لاحظت شيئاً غير عادي أثناء الحادث؟',
      pressure: 5,
      a: `"${isCulprit ? 'لم ألاحظ أي شيء غريب... ربما شخص آخر ارتكب الجريمة.' : 'سمعت بعض الضوضاء بالقرب، لكنني لم أتحقق.'}"`
    }
  ];

  const questionsEn = [
    {
      q: 'Where exactly were you when the crime occurred?',
      pressure: 10,
      a: `"${suspect.statement}"`
    },
    {
      q: `As the ${suspect.role}, why were you present at the scene?`,
      pressure: 15,
      a: `"${isCulprit ? 'I was simply performing my regular duties; I had no clue suspicion would fall upon me!' : 'My presence at ' + (c.sceneLocation || 'the scene') + ' was completely normal given my duties as ' + suspect.role + '.'}"`
    },
    {
      q: 'How do you respond to the allegations against you?',
      pressure: 25,
      a: `"${isCulprit ? 'These accusations are baseless. Do you have any conclusive forensic proof?' : 'I am innocent! Examine the crime scene thoroughly and you will see the truth for yourself.'}"`
    },
    {
      q: 'Did you notice any unusual activity during the incident?',
      pressure: 5,
      a: `"${isCulprit ? 'I did not notice anything suspicious... someone else must have perpetrated this.' : 'I heard subtle noises in the corridor, but did not investigate.'}"`
    }
  ];

  const questions = isEn ? questionsEn : questionsAr;

  const container = document.getElementById('interrogate-choices');
  container.innerHTML = '';

  questions.forEach(item => {
    const btn = document.createElement('button');
    btn.className = 'choice-btn';
    btn.innerHTML = `<span class="choice-icon">🕵️</span> ${item.q}`;
    btn.onclick = () => {
      if (suspectPressure >= 100) {
        setText('interrogate-dialog-text', isEn ? '🚫 Suspect invoked legal counsel and refused to answer.' : '🚫 المشتبه به رفض الإجابة. حاول مع مشتبه آخر أو ابحث عن أدلة جديدة.');
        playClick(); return;
      }
      setPressure(suspectPressure + item.pressure);
      const detLabel = isEn ? 'Detective' : 'المحقق';
      setText('interrogate-dialog-text', `${detLabel}: "${item.q}"\n\n${suspect.name}: ${item.a}`);
      playClick();
    };
    container.appendChild(btn);
  });

  // Smart Contradiction Confrontation Button
  const confrontBtn = document.createElement('button');
  confrontBtn.className = 'choice-btn';
  confrontBtn.style.background = 'linear-gradient(135deg, rgba(255,65,108,0.25), rgba(192,40,74,0.35))';
  confrontBtn.style.borderColor = 'rgba(255,65,108,0.6)';
  confrontBtn.innerHTML = `<span class="choice-icon">💼</span> ${isEn ? 'Confront with Physical Evidence (Lie Detector)' : 'مواجهة المشتبه به بدليل مادي (كشف الكذب)'}`;
  confrontBtn.onclick = () => {
    if (state.collectedEvidence.length === 0) {
      showToast(isEn ? '⚠️ No evidence collected yet! Search the crime scene.' : '⚠️ لم تجمَع أي دليل بعد! اذهب لمسرح الجريمة للبحث عن أدلة.');
      playClick();
      return;
    }
    openConfrontModal(suspect);
  };
  container.appendChild(confrontBtn);

  showScreen('interrogation-screen', 'forward');

  // ── 🎭 Start 2D Interrogation Engine ──
  if (typeof window.Interrogation2D !== 'undefined') {
    setTimeout(() => {
      window.Interrogation2D.start(isCulprit);
    }, 150);
  }

  if (state.level === 1) {
    TutorialManager.triggerLevel1Guide(5);
  }
  playClick();
}

/* ─── TIMER ──────────────────────────────────────────────── */
function getLevelTimeSec(iq) {
  switch (iq) {
    case 80: return 480;  // 8:00 mins (was 2:30)
    case 100: return 600; // 10:00 mins (was 3:30)
    case 120: return 720; // 12:00 mins (was 4:30)
    case 140: return 900; // 15:00 mins (was 5:30)
    case 160: return 1200; // 20:00 mins (was 6:30)
    default: return 600;
  }
}

function startTimer() {
  const iq = state.currentCase ? (state.currentCase.iqLevel || 80) : 80;
  state.timerSec = getLevelTimeSec(iq);
  state.timerRunning = true;
  updateTimerDisplay();
  if (state.timerInterval) clearInterval(state.timerInterval);
  state.timerInterval = setInterval(() => {
    state.timerSec--;
    updateTimerDisplay();
    if (state.timerSec <= 0) {
      stopTimer();
      showDefeat('انتهى وقت التحقيق! لم تتمكن من حل القضية في الوقت المحدد.');
    }
  }, 1000);
}

function stopTimer() {
  if (state.timerInterval) clearInterval(state.timerInterval);
  state.timerRunning = false;
}

function updateTimerDisplay() {
  const m = Math.floor(state.timerSec / 60).toString().padStart(2, '0');
  const s = (state.timerSec % 60).toString().padStart(2, '0');
  const el = document.getElementById('timer-display');
  if (!el) return;
  el.textContent = `⏱ ${m}:${s}`;
  if (state.timerSec <= 30) {
    el.classList.add('timer-danger');
  } else {
    el.classList.remove('timer-danger');
  }
}

/* ─── ACCUSE ──────────────────────────────────────────────── */
const verdictState = { suspect: null, motive: null, weapon: null, timeline: null, evidence: null };

function accuseSuspect() {
  openVerdictModal();
}

function openConfrontModal(suspect) {
  const listContainer = document.getElementById('confront-evidence-list');
  const subtitle = document.getElementById('confront-modal-subtitle');
  if (!listContainer) return;

  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const c = state.currentCase || (LEVELS_DATA && LEVELS_DATA.length > 0 ? LEVELS_DATA[0] : null);
  const culpritName = c ? (c.culpritName || '') : '';
  const suspectName = suspect ? (suspect.name || '') : '';
  const isCulprit = culpritName && suspectName ? (suspectName === culpritName || suspectName.includes(culpritName) || culpritName.includes(suspectName)) : false;

  if (subtitle) {
    subtitle.textContent = isEn
      ? `Select physical evidence to confront ${suspectName} and expose the contradiction:`
      : `اختر الدليل المادي لمواجهة ${suspectName} به وكشف التناقض:`;
  }
  listContainer.innerHTML = '';

  // Evidence list options (use collected evidence or case evidence pool)
  const evidenceList = (state.collectedEvidence && state.collectedEvidence.length > 0)
    ? state.collectedEvidence
    : [
        { id: 'ev_1', title: c && c.evidence ? c.evidence : (isEn ? '📹 Surveillance Camera Footage' : '📹 تسجيلات كاميرات المراقبة') },
        { id: 'ev_2', title: isEn ? '🔍 Fingerprint Analysis — Safe Handle' : '🔍 تقرير بصمات أصابع الخزنة' },
        { id: 'ev_3', title: isEn ? '📱 Encrypted Chat Log Records' : '📱 سجل محادثات واتساب السرية' }
      ];

  evidenceList.forEach(matched => {
    const btn = document.createElement('button');
    btn.className = 'verdict-option-btn';
    btn.style.width = '100%';
    btn.style.textAlign = isEn ? 'left' : 'right';
    btn.style.padding = '12px 14px';
    btn.style.display = 'flex';
    btn.style.alignItems = 'center';
    btn.style.gap = '10px';
    btn.style.background = 'rgba(255, 255, 255, 0.05)';
    btn.style.border = '1px solid rgba(255, 65, 108, 0.3)';
    btn.style.borderRadius = '10px';
    btn.style.color = '#FFF';
    btn.style.cursor = 'pointer';

    btn.innerHTML = `<span style="font-size:1.2rem;">🔍</span> <span style="font-weight:bold; font-size:0.9rem;">${matched.title}</span>`;

    btn.onclick = () => {
      hideModal('confrontation-modal');

      const evMatch = c && c.evidence ? (matched.title.includes(c.evidence) || c.evidence.includes(matched.title)) : true;

      if (isCulprit || evMatch) {
        setPressure(100);
        if (typeof window.Interrogation2D !== 'undefined' && window.Interrogation2D.triggerConfrontation) {
          window.Interrogation2D.triggerConfrontation();
        }
        if (isEn) {
          setText('interrogate-dialog-text', `Detective: "How do you explain ${matched.title} found at the crime scene?"\n\n${suspectName}: "What?! Where did you find that?! Fine... I confess! I lied about my alibi and my whereabouts at the scene!"`);
          addNotebookEntry('discrepancy', `${suspectName} statement contradiction`, `Admitted inconsistency when confronted with: (${matched.title}).`);
          showToast('🎉 You exposed the suspect\'s lie and logged the contradiction in the notebook!');
        } else {
          setText('interrogate-dialog-text', `المحقق: "كيف تفسر وجود ${matched.title} في مسرح الجريمة؟"\n\n${suspectName}: "ماذا؟! أين وجدتم هذا؟! حسناً... أعترف! لقد كذبت بشأن خط السير وتواجدي في موقع الجريمة!"`);
          addNotebookEntry('discrepancy', `تناقض أقوال ${suspectName}`, `اعتراف بالارتباك والتناقض عند مواجهته بـ (${matched.title}).`);
          showToast('🎉 كشفت كذب المشتبه به وسجلت التناقض في المفكرة!');
        }
        playWin();
      } else {
        setPressure((suspectPressure || 0) + 25);
        if (typeof window.Interrogation2D !== 'undefined' && window.Interrogation2D.triggerLie) {
          window.Interrogation2D.triggerLie();
        }
        if (isEn) {
          setText('interrogate-dialog-text', `Detective: "What about ${matched.title}?"\n\n${suspectName}: "That proves nothing against me! Stay focused on your real leads, Detective."`);
          showToast('❌ Evidence insufficient to expose this suspect!');
        } else {
          setText('interrogate-dialog-text', `المحقق: "ماذا عن ${matched.title}؟"\n\n${suspectName}: "هذا الدليل لا يثبت شيئاً ضدي! ركز في تحقيقاتك أكثر يا سيادة المحقق."`);
          showToast('❌ الدليل غير قاطع لمواجهة هذا المتهم!');
        }
        playClick();
      }
    };
    listContainer.appendChild(btn);
  });

  showModal('confrontation-modal');
  playClick();
}

function openVerdictModal() {
  if (!state.currentCase && LEVELS_DATA && LEVELS_DATA.length > 0) {
    state.currentCase = LEVELS_DATA.find(l => (l.level || l.Level) === (state.level || 1)) || LEVELS_DATA[0];
  }
  const c = state.currentCase;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  if (!c) {
    showToast(isEn ? '⚠️ Case data not yet loaded. Please try again.' : '⚠️ لم يتم تحميل القضية بعد. حاول مرة ثانية.');
    return;
  }

  verdictState.suspect = null; verdictState.motive = null;
  verdictState.weapon = null; verdictState.timeline = null; verdictState.evidence = null;

  // Dynamically update modal title and step titles based on language
  const modalTitle = document.querySelector('#verdict-modal h3');
  if (modalTitle) {
    modalTitle.textContent = isEn ? '⚖️ Final Indictment & Court Trial' : '⚖️ لائحة الاتهام والمحاكمة النهائية';
  }

  const stepTitles = isEn ? [
    'Step 1 of 5 — Select Prime Suspect',
    'Step 2 of 5 — Determine Criminal Motive',
    'Step 3 of 5 — Identify Weapon / Method',
    'Step 4 of 5 — Reconstruct Event Timeline',
    'Step 5 of 5 — Present Decisive Evidence to Court'
  ] : [
    'الخطوة 1 من 5 — اختر المتهم الرئيسي',
    'الخطوة 2 من 5 — حدد الدافع الإجرامي',
    'الخطوة 3 من 5 — حدد أداة/أسلوب الجريمة',
    'الخطوة 4 من 5 — ترتيب تسلسل الأحداث الزمني',
    'الخطوة 5 من 5 — قدّم الدليل القاطع للمحكمة'
  ];

  for (let i = 1; i <= 5; i++) {
    const p = document.getElementById(`vp-${i}`);
    if (p) {
      const titleEl = p.querySelector('.verdict-step-title');
      if (titleEl) titleEl.textContent = stepTitles[i - 1];
    }
  }

  /* ── Step 1: Suspects ── */
  const sl = document.getElementById('verdict-suspects-list');
  if (sl) {
    sl.innerHTML = '';
    const suspects = (c && (c._displaySuspects || c.suspects)) ? (c._displaySuspects || c.suspects) : [
      { name: c ? c.culpritName : (isEn ? 'Prime Suspect' : 'المتهم الأول'), role: c ? c.culpritRole : (isEn ? 'Key Person of Interest' : 'مشتبه به رئيسي') },
      { name: isEn ? 'Secondary Suspect' : 'مشتبه به ثانٍ', role: isEn ? 'Witness' : 'شاهد في القضية' }
    ];
    suspects.forEach(s => {
      const btn = document.createElement('button');
      btn.className = 'verdict-option-btn';
      btn.innerHTML = `<span>👤</span> <span>${s.name} — <em>${s.role || ''}</em></span>`;
      btn.onclick = () => {
        verdictState.suspect = s;
        if (window.GameBridge) window.GameBridge.postMessage(JSON.stringify({ action: 'selectCulprit', payload: s.id || s.name }));
        sl.querySelectorAll('.verdict-option-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      };
      sl.appendChild(btn);
    });
  }

  /* ── Step 2: Motives ── */
  const motivePool = isEn
    ? [
        (c && c.motive) || 'Financial gain and inheritance greed',
        'Professional jealousy and accumulated envy',
        'Theft of classified documents and concealing a scandal',
        'Long-standing personal dispute and revenge'
      ].filter((v, i, a) => v && a.indexOf(v) === i)
    : [
        (c && c.motive) || 'دافع مالي وطمع في الميراث',
        'الغيرة المهنية والحسد التراكمي',
        'سرقة وثائق سرية وإخفاء الفضيحة',
        'خلاف شخصي قديم وثأر متراكم'
      ].filter((v, i, a) => v && a.indexOf(v) === i); // deduplicate

  const ml = document.getElementById('verdict-motives-list');
  if (ml) {
    ml.innerHTML = '';
    motivePool.forEach(m => {
      const btn = document.createElement('button');
      btn.className = 'verdict-option-btn';
      btn.innerHTML = `<span>🎯</span> <span>${m}</span>`;
      btn.onclick = () => {
        verdictState.motive = m;
        if (window.GameBridge) window.GameBridge.postMessage(JSON.stringify({ action: 'selectMotive', payload: m }));
        ml.querySelectorAll('.verdict-option-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      };
      ml.appendChild(btn);
    });
  }

  /* ── Step 3: Weapons ── */
  const weaponPool = isEn
    ? [
        (c && c.weapon) || 'Unknown sharp implement',
        'Bladed weapon exploiting absence of security',
        'Cyber intrusion and financial data forgery',
        'Hazardous chemical compound of unknown origin'
      ].filter((v, i, a) => v && a.indexOf(v) === i)
    : [
        (c && c.weapon) || 'أداة حادة غير معروفة',
        'سلاح حاد واستغلال غياب الحراسة',
        'اختراق سيبراني وتزوير بيانات مالية',
        'مادة كيميائية خطرة مستخدمة مجهولة المصدر'
      ].filter((v, i, a) => v && a.indexOf(v) === i);

  const wl = document.getElementById('verdict-weapons-list');
  if (wl) {
    wl.innerHTML = '';
    weaponPool.forEach(w => {
      const btn = document.createElement('button');
      btn.className = 'verdict-option-btn';
      btn.innerHTML = `<span>🔪</span> <span>${w}</span>`;
      btn.onclick = () => {
        verdictState.weapon = w;
        if (window.GameBridge) window.GameBridge.postMessage(JSON.stringify({ action: 'selectWeapon', payload: w }));
        wl.querySelectorAll('.verdict-option-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      };
      wl.appendChild(btn);
    });
  }

  /* ── Step 4: Timeline ── */
  const timelinePool = isEn
    ? [
        (c && c.timeline) || '1️⃣ Planning ➔ 2️⃣ Execution ➔ 3️⃣ Evidence Concealment',
        '1️⃣ Heated Confrontation ➔ 2️⃣ Police Dispatch ➔ 3️⃣ Suspect Fled Scene',
        '1️⃣ Break-In ➔ 2️⃣ Alarm Triggered ➔ 3️⃣ Property Vanished',
        '1️⃣ Target Surveillance ➔ 2️⃣ Waiting for the Right Moment ➔ 3️⃣ Theft Executed'
      ].filter((v, i, a) => v && a.indexOf(v) === i)
    : [
        (c && c.timeline) || '1️⃣ التخطيط ➔ 2️⃣ التنفيذ ➔ 3️⃣ إخفاء الأدلة',
        '1️⃣ شجار حاد ➔ 2️⃣ استدعاء الشرطة ➔ 3️⃣ هروب الخاطف',
        '1️⃣ اقتحام المسرح ➔ 2️⃣ إطلاق الإنذار ➔ 3️⃣ اختفاء الممتلكات',
        '1️⃣ مراقبة الهدف ➔ 2️⃣ انتظار اللحظة المناسبة ➔ 3️⃣ تنفيذ السرقة'
      ].filter((v, i, a) => v && a.indexOf(v) === i);

  const tl = document.getElementById('verdict-timeline-list');
  if (tl) {
    tl.innerHTML = '';
    timelinePool.forEach(t => {
      const btn = document.createElement('button');
      btn.className = 'verdict-option-btn';
      btn.innerHTML = `<span>⏱️</span> <span>${t}</span>`;
      btn.onclick = () => {
        verdictState.timeline = t;
        if (window.GameBridge) window.GameBridge.postMessage(JSON.stringify({ action: 'selectTimeline', payload: t }));
        tl.querySelectorAll('.verdict-option-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      };
      tl.appendChild(btn);
    });
  }

  /* ── Step 5: Evidence ── */
  const collectedEvidenceTitles = state.collectedEvidence.map(e => e.title);
  const evidencePool = [...new Set([
    (c && c.evidence) || null,
    ...collectedEvidenceTitles,
    isEn ? '🗣️ Unverified eyewitness testimony' : 'شهادة شاهد عيان غير مؤكدة'
  ])].filter(Boolean);

  const ev = document.getElementById('verdict-evidence-list');
  if (ev) {
    ev.innerHTML = '';
    evidencePool.forEach(e => {
      const btn = document.createElement('button');
      btn.className = 'verdict-option-btn';
      btn.innerHTML = `<span>🔍</span> <span>${e}</span>`;
      btn.onclick = () => {
        verdictState.evidence = e;
        if (window.GameBridge) window.GameBridge.postMessage(JSON.stringify({ action: 'selectEvidence', payload: e }));
        ev.querySelectorAll('.verdict-option-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      };
      ev.appendChild(btn);
    });
  }

  // Make stepper circles clickable
  for (let i = 1; i <= 5; i++) {
    const circle = document.getElementById(`vs-${i}`);
    if (circle) {
      circle.style.cursor = 'pointer';
      circle.onclick = () => goToVerdictStep(i);
    }
  }

  // Add confirmation buttons to each step
  for (let i = 1; i <= 5; i++) {
    const panel = document.getElementById(`vp-${i}`);
    if (panel) {
      let navBtn = panel.querySelector('.verdict-nav-btn');
      if (!navBtn) {
        navBtn = document.createElement('button');
        navBtn.className = 'verdict-nav-btn btn-primary';
        navBtn.style.marginTop = '1rem';
        panel.appendChild(navBtn);
      }
      const isLastStep = (i === 5);
      navBtn.textContent = isLastStep ? (isEn ? '⚖️ Submit Final Accusation' : '⚖️ تأكيد الاتهام النهائي') : (isEn ? 'Next ➔' : 'التالي ➔');
      navBtn.onclick = isLastStep ? submitVerdict : () => goToVerdictStep(i + 1);
    }
  }

  const backBtn = document.getElementById('btn-verdict-back');
  if (backBtn) {
    backBtn.textContent = isEn ? '← Back' : '← العودة';
  }

  goToVerdictStep(1);
  showModal('verdict-modal');
  playClick();
}

function goToVerdictStep(step) {
  step = Math.max(1, Math.min(5, step));
  for (let i = 1; i <= 5; i++) {
    const panel = document.getElementById(`vp-${i}`);
    const circle = document.getElementById(`vs-${i}`);
    const conn = document.getElementById(`vc-${i}`);
    if (panel) panel.className = 'verdict-step-panel' + (i === step ? ' active' : '');
    if (circle) circle.className = 'verdict-step' + (i < step ? ' done' : i === step ? ' active' : '');
    if (conn) conn.className = 'verdict-connector' + (i < step ? ' done' : '');
  }
  const backBtn = document.getElementById('btn-verdict-back');
  if (backBtn) {
    backBtn.style.display = step > 1 ? 'block' : 'none';
    backBtn.onclick = () => goToVerdictStep(step - 1);
  }
}

function submitVerdict() {
  hideModal('verdict-modal');
  const c = state.currentCase;
  const chosenName = verdictState.suspect ? (verdictState.suspect.name || verdictState.suspect.id || '') : '';
  const culpritName = c ? (c.culpritName || '') : '';

  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  if (!chosenName) {
    showToast(isEn ? '⚠️ Please select a suspect in Step 1!' : '⚠️ يرجى اختيار المشتبه به في الخطوة 1!');
    goToVerdictStep(1);
    showModal('verdict-modal');
    return;
  }

  // Check if chosen suspect is correct
  const isCorrect = (chosenName === culpritName || chosenName.includes(culpritName) || culpritName.includes(chosenName));

  if (window.GameBridge) {
    try {
      window.GameBridge.postMessage(JSON.stringify({ action: 'selectCulprit', payload: chosenName }));
      window.GameBridge.postMessage(JSON.stringify({ action: 'verifyAccusation' }));
    } catch (e) { }
  }

  if (isCorrect) {
    state.completed.add(c.level);
    state.coins = (state.coins || 0) + 50;
    saveProgress();
    addXP(150);
    stopTimer();
    if (typeof AudioEngine !== 'undefined' && AudioEngine.playVictorySFX) {
      AudioEngine.playVictorySFX();
    }
    showVictory(500);
  } else {
    stopTimer();
    if (typeof AudioEngine !== 'undefined' && AudioEngine.playDefeatSFX) {
      AudioEngine.playDefeatSFX();
    }
    showDefeat(isEn
      ? `❌ Your suspect (${chosenName}) has a solid alibi and is NOT the real culprit!\n\n🔍 Re-examine the crime scene and interrogate the remaining suspects to uncover the truth.`
      : `❌ المتهم المختار (${chosenName}) يملك حجة غياب قوية وليس هو الجاني الحقيقي!\n\n🔍 أعد فحص مسرح الجريمة واستجوب بقية المشتبه بهم للوصول إلى الجاني الحقيقي.`);
  }
}

function shuffleArr(arr, seed) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = (seed * (i + 3)) % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
}

/* ─── FORENSIC LAB ────────────────────────────────────────── */
function openForensicLabModal() {
  const c = state.currentCase;
  if (!c) return;

  const list = document.getElementById('forensic-cards-list');
  const resBox = document.getElementById('forensic-result-box');
  if (!list) return;
  list.innerHTML = '';
  if (resBox) resBox.style.display = 'none';

  if (!state.forensicStatus) state.forensicStatus = {};

  const tests = c.forensicAnalysis || [
    { type: 'dna', name: '🧬 فحص الحمض النووي (DNA)', result: 'تطابق عينة DNA ملتقطة من المكان مع الجاني الرئيسي بنسبة 99.8%' },
    { type: 'fingerprint', name: '🔍 البصمات الجينية', result: 'بصمات أصابع خفية مطابقة تماماً للجاني على مقبض الباب والأداة' }
  ];

  tests.forEach((t, i) => {
    const card = document.createElement('div');
    const statusKey = `lvl_${c.level}_test_${i}`;
    const currentStatus = state.forensicStatus[statusKey] || 'idle';

    card.className = 'forensic-card' + (currentStatus === 'ready' ? ' active' : '');
    card.innerHTML = `
      <span class="f-icon">🔬</span>
      <div class="f-info">
        <div class="f-name">${t.name}</div>
        <div class="f-status ${currentStatus}">
          ${currentStatus === 'ready' ? '✅ التقرير جاهز' : currentStatus === 'analyzing' ? '⏳ جاري التحليل المخبري...' : 'اضغط لإرسال العينة (تحليل غضون ثوانٍ)'}
        </div>
      </div>
    `;

    card.onclick = () => {
      if (state.forensicStatus[statusKey] === 'ready') {
        if (resBox) {
          resBox.innerHTML = `<strong>📋 نتيجة التقرير الطبي الشرعي:</strong><br>${t.result}`;
          resBox.style.display = 'block';
        }
        playClick();
      } else if (!state.forensicStatus[statusKey] || state.forensicStatus[statusKey] === 'idle') {
        state.forensicStatus[statusKey] = 'analyzing';
        const st = card.querySelector('.f-status');
        if (st) { st.textContent = '⏳ جاري التحليل...'; st.className = 'f-status analyzing'; }
        showToast('🔬 تم إرسال العينة إلى المعمل الجنائي...');
        playClick();
        setTimeout(() => {
          state.forensicStatus[statusKey] = 'ready';
          card.classList.add('active');
          if (st) { st.textContent = '✅ التقرير جاهز'; st.className = 'f-status ready'; }
          if (resBox) {
            resBox.innerHTML = `<strong>📋 نتيجة التقرير الطبي الشرعي:</strong><br>${t.result}`;
            resBox.style.display = 'block';
          }
          showToast('📑 وصل تقرير المعمل الجنائي!');
          playWin();
        }, 3000);
      }
    };

    list.appendChild(card);
  });

  showModal('forensic-lab-modal');
  playClick();
}

/* ─── HINT ───────────────────────────────────────────────── */
function useHint() {
  if (!state.currentCase) return;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';

  // Always show a rewarded ad to get the hint
  if (window.GameAds) {
    showToast(isEn ? '📺 Watch the ad to receive an investigation hint...' : '📺 شاهد الإعلان للحصول على تلميح المحقق...');
    try { window.GameAds.postMessage('showRewarded'); } catch (e) {}
  } else {
    // Fallback for web/debug mode: show hint directly
    _showHintContent();
  }
  playClick();
}

/* ─── CRIME SCENE ────────────────────────────────────────── */
function goToCrimeScene() {
  if (!state.timerRunning) startTimer();
  if (!state.currentCase) {
    state.currentCase = (LEVELS_DATA || []).find(l => (l.level || l.Level) === (state.level || 1)) || (LEVELS_DATA && LEVELS_DATA[0]);
  }
  const c = state.currentCase;
  if (!c) {
    console.warn("No currentCase found in goToCrimeScene");
    return;
  }

  if (!state.collectedEvidence) state.collectedEvidence = [];

  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const cType = (c.crimeType || 'Crime').toString();
  setText('scene-case-num', `CASE ${String(c.level || 1).padStart(2, '0')}: ${cType.toUpperCase()}`);
  setText('scene-evidence-key', isEn ? `🔑 Key Evidence: ${c.evidence || ''}` : `🔑 الدليل الرئيسي: ${c.evidence || ''}`);

  // ── 🔦 Init 2D Canvas Crime Scene Engine ──
  const alreadyCollectedForCanvas = (state.collectedEvidence || []).some(e => e.title === c.evidence);
  if (typeof window.initCrimeScene2D === 'function' && !alreadyCollectedForCanvas) {
    // Small delay to let screen transition finish first
    setTimeout(() => {
      window.initCrimeScene2D(c.level || 1, c.evidence || '');
    }, 120);
  }

  // Hidden evidence hotspot for this level
  const hotspotArea = document.getElementById('hidden-hotspot-area');
  if (hotspotArea && c.hiddenEvidence) {
    const h = c.hiddenEvidence;
    if (!state.foundHiddenEvidence) state.foundHiddenEvidence = new Set();
    const alreadyFound = state.foundHiddenEvidence.has(c.level);
    hotspotArea.innerHTML = `<div style="font-size:0.75rem; color:var(--muted); font-weight:700; padding: 0 4px;">🔎 تفتيش خفي:</div>`;
    const hsBtn = document.createElement('button');
    hsBtn.className = 'hotspot-search-btn' + (alreadyFound ? ' found' : '');
    hsBtn.innerHTML = `<span class="hs-icon">${h.icon}</span> <span>${alreadyFound ? '✅ ' : ''}فتش ${h.title}</span>`;
    const hintDiv = document.createElement('div');
    hintDiv.className = 'hotspot-hint';
    hintDiv.textContent = h.hint;
    if (alreadyFound) hintDiv.style.display = 'block';
    hsBtn.onclick = () => {
      state.foundHiddenEvidence.add(c.level);
      hintDiv.style.display = 'block';
      hsBtn.classList.add('found');
      hsBtn.innerHTML = `<span class="hs-icon">${h.icon}</span> <span>✅ فتش ${h.title}</span>`;
      showToast(`🔍 وجدت: ${h.hint.slice(0, 45)}...`);
      playWin();
    };
    hotspotArea.appendChild(hsBtn);
    hotspotArea.appendChild(hintDiv);
  }

  showScreen('crime-scene-screen', 'forward');
  if (state.level === 1) {
    const alreadyCollected = (state.collectedEvidence || []).some(e => e.title === c.evidence);
    TutorialManager.triggerLevel1Guide(alreadyCollected ? 3 : 2);
  }
  playClick();
}
window.goToCrimeScene = goToCrimeScene;


function collectEvidence() {
  const c = state.currentCase;
  if (!c) return;
  // Prevent duplicate collection of same evidence
  const alreadyCollected = state.collectedEvidence.some(e => e.title === c.evidence);
  if (alreadyCollected) {
    showToast('⚠️ هذا الدليل تم جمعه بالفعل!');
    return;
  }
  const ev = { id: Date.now(), title: c.evidence, icon: getEvidenceIcon(c.evidence) };
  state.collectedEvidence.push(ev);
  renderEvidenceDrawer();
  updateEvidenceBadge();
  // Visual feedback on hotspot
  const hotspot = document.getElementById('btn-collect-evidence');
  if (hotspot) {
    hotspot.style.opacity = '0.4';
    hotspot.style.pointerEvents = 'none';
    const label = hotspot.querySelector('.hotspot-label');
    if (label) label.textContent = '✅ تم جمع الدليل';
  }
  showToast(`✅ تم جمع الدليل: ${c.evidence}`);
  playWin();
  openDrawer();
  if (state.level === 1) {
    TutorialManager.triggerLevel1Guide(3);
  }
}

function getEvidenceIcon(ev) {
  if (ev.includes('كاميرا') || ev.includes('📹')) return '📹';
  if (ev.includes('واتساب') || ev.includes('💬')) return '💬';
  if (ev.includes('تسجيل') || ev.includes('🎙️')) return '🎙️';
  if (ev.includes('بصمة') || ev.includes('👣')) return '👣';
  if (ev.includes('مستند') || ev.includes('📄')) return '📄';
  return '🔍';
}

/* ─── EVIDENCE DRAWER ────────────────────────────────────── */
function renderEvidenceDrawer() {
  const list = document.getElementById('side-evidence-list');
  if (!list) return;
  list.innerHTML = '';
  state.collectedEvidence.forEach(ev => {
    const el = document.createElement('div');
    el.className = 'evidence-card-item';
    el.innerHTML = `
      <div class="evidence-thumb">${ev.icon}</div>
      <div class="evidence-info">
        <div class="evidence-title">${ev.title}</div>
        <div class="evidence-meta">المستوى ${state.level}</div>
      </div>
    `;
    el.onclick = () => openEvidenceInspector(ev);
    list.appendChild(el);
  });
}

function updateEvidenceBadge() {
  setText('side-evidence-badge', state.collectedEvidence.length);
}

function openDrawer() {
  document.getElementById('side-evidence-drawer')?.classList.add('open');
}
function closeDrawer() {
  document.getElementById('side-evidence-drawer')?.classList.remove('open');
}
function toggleDrawer() {
  document.getElementById('side-evidence-drawer')?.classList.toggle('open');
  playClick();
}

/* ─── V3.0 DETECTIVE GAMEPLAY ENGINE EXTENSIONS ─────────── */

function getRankInfo(xp) {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  if (xp >= 15000) return { rank: 'Legendary Master', label: isEn ? '👑 Legendary Master' : '👑 المحقق الأسطوري', title: isEn ? 'Legendary Master Sleuth' : 'المحقق الأسطوري' };
  if (xp >= 8000) return { rank: 'Chief Inspector', label: isEn ? '🟠 Chief Inspector' : '🟠 رئيس المفتشين', title: isEn ? 'Chief of Detectives' : 'رئيس المباحث' };
  if (xp >= 4000) return { rank: 'Senior Detective', label: isEn ? '🟣 Senior Detective' : '🟣 كبير المحققين', title: isEn ? 'Senior Detective' : 'كبير المحققين' };
  if (xp >= 1500) return { rank: 'Detective', label: isEn ? '🔵 Detective' : '🔵 محقق جنائي', title: isEn ? 'Detective' : 'محقق جنائي' };
  return { rank: 'Junior Detective', label: isEn ? '🟢 Junior Detective' : '🟢 محقق مبتدئ', title: isEn ? 'Junior Detective' : 'محقق مبتدئ' };
}

function updateRankUI() {
  const info = getRankInfo(state.xp || 0);
  setText('hud-rank', info.title);
  setText('splash-rank-name', `${info.title}`);
  const xpEl = document.getElementById('splash-rank-xp');
  if (xpEl) xpEl.textContent = state.xp || 0;
}

function addXP(amount) {
  state.xp = (state.xp || 0) + amount;
  localStorage.setItem('unknown_culprit_xp', state.xp.toString());
  updateRankUI();
}

/* Notebook Logic */
function addNotebookEntry(type, title, desc) {
  if (!state.notebook) state.notebook = { discrepancies: [], timeline: [], clues: [] };
  if (type === 'discrepancy') {
    state.notebook.discrepancies.push({ title, desc });
  } else if (type === 'timeline') {
    state.notebook.timeline.push({ title, desc });
  } else if (type === 'clue') {
    state.notebook.clues.push({ title, desc });
  }
  renderNotebook();
  updateNotebookBadge();
}

function renderNotebook() {
  if (!state.notebook) return;
  const notesView = document.getElementById('ntab-notes-view');
  if (notesView) {
    if (state.notebook.discrepancies.length === 0) {
      notesView.innerHTML = `<div class="notebook-empty">لم تسجل أي تناقضات بعد. استجوب المشتبه بهم وواجههم بالأدلة! 💬</div>`;
    } else {
      notesView.innerHTML = state.notebook.discrepancies.map(d => `
        <div class="notebook-item-card discrepancy">
          <div class="notebook-item-title">⚠️ ${d.title}</div>
          <div class="notebook-item-desc">${d.desc}</div>
        </div>
      `).join('');
    }
  }

  const timelineView = document.getElementById('ntab-timeline-view');
  if (timelineView) {
    if (state.notebook.timeline.length === 0) {
      timelineView.innerHTML = `<div class="notebook-empty">سيظهر التسلسل الزمني للأحداث هنا عند جمع المعلومات. ⏱️</div>`;
    } else {
      timelineView.innerHTML = state.notebook.timeline.map((t, idx) => `
        <div class="notebook-item-card">
          <div class="notebook-item-title">⏱️ الحدث ${idx + 1}: ${t.title}</div>
          <div class="notebook-item-desc">${t.desc}</div>
        </div>
      `).join('');
    }
  }

  const cluesView = document.getElementById('ntab-clues-view');
  if (cluesView) {
    if (state.notebook.clues.length === 0) {
      cluesView.innerHTML = `<div class="notebook-empty">تفاصيل الأدلة المفحوصة والمختبرية ستدون هنا. 🔬</div>`;
    } else {
      cluesView.innerHTML = state.notebook.clues.map(c => `
        <div class="notebook-item-card clue">
          <div class="notebook-item-title">🔬 ${c.title}</div>
          <div class="notebook-item-desc">${c.desc}</div>
        </div>
      `).join('');
    }
  }

  setText('discrepancy-count', `${state.notebook.discrepancies.length} مكتشفة`);
}

function openNotebookDrawer() {
  renderNotebook();
  document.getElementById('side-notebook-drawer')?.classList.add('open');
  playClick();
}

function closeNotebookDrawer() {
  document.getElementById('side-notebook-drawer')?.classList.remove('open');
}

function toggleNotebookDrawer() {
  renderNotebook();
  document.getElementById('side-notebook-drawer')?.classList.toggle('open');
  playClick();
}

function initNotebookTabs() {
  document.querySelectorAll('.notebook-tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.notebook-tab').forEach(t => {
        t.classList.remove('active');
        t.style.color = 'var(--muted)';
      });
      tab.classList.add('active');
      tab.style.color = 'var(--gold)';
      const target = tab.getAttribute('data-ntab');
      document.querySelectorAll('.ntab-view').forEach(v => v.style.display = 'none');
      const view = document.getElementById(`ntab-${target}-view`);
      if (view) view.style.display = 'block';
      playClick();
    };
  });
}

/* Evidence Inspector Logic */
function openEvidenceInspector(ev) {
  const c = state.currentCase;
  if (!c) return;

  setText('inspector-item-name', ev.title);
  setText('inspector-item-desc', 'انقر على النقاط الساخنة 🔴 التفاعلية للفحص وتدوين النتائج في المفكرة.');
  setText('inspector-findings', '');

  const imgEl = document.getElementById('inspector-img');
  if (imgEl) imgEl.src = 'bg_case_file.png';

  const container = document.getElementById('inspector-hotspots-container');
  if (container) {
    container.innerHTML = '';

    // Hotspot 1: Fingerprints
    const hs1 = document.createElement('div');
    hs1.className = 'inspector-hotspot';
    hs1.style.top = '35%'; hs1.style.left = '40%';
    hs1.onclick = () => {
      setText('inspector-findings', '🔍 عثرت على: بصمة إبهام واضحة ملوثة أرسلت للمعمل الجنائي!');
      addNotebookEntry('clue', `فحص دقيق: ${ev.title}`, 'بصمات أصابع واضحة تم توثيقها.');
      playWin();
    };
    container.appendChild(hs1);

    // Hotspot 2: Secret Timestamp/Code
    const hs2 = document.createElement('div');
    hs2.className = 'inspector-hotspot';
    hs2.style.top = '65%'; hs2.style.left = '70%';
    hs2.onclick = () => {
      setText('inspector-findings', '⏱️ عثرت على: طابع زمني دقيق ورقم متسلسل خاص!');
      addNotebookEntry('clue', `طابع زمني: ${ev.title}`, `تاريخ وساعة استخدام الدليل ثبتت في المسرح.`);
      playWin();
    };
    container.appendChild(hs2);
  }

  showModal('evidence-inspector-modal');
  playClick();
}

/* Deduction Board Logic */
function openDeductionBoard() {
  const c = state.currentCase;
  if (!c) return;

  // Suspects Select
  const sSel = document.getElementById('ded-suspect-select');
  if (sSel) {
    sSel.innerHTML = (c._displaySuspects || c.suspects).map(s => `<option value="${s.name}">${s.name} (${s.role})</option>`).join('');
  }

  // Motive Select
  const mSel = document.getElementById('ded-motive-select');
  if (mSel) {
    const motives = [c.motive, 'الغيرة والتنافس المهني', 'تصفية حسابات وسرقة مستندات'];
    mSel.innerHTML = motives.map(m => `<option value="${m}">${m}</option>`).join('');
  }

  // Weapon Select
  const wSel = document.getElementById('ded-weapon-select');
  if (wSel) {
    const weapons = [c.weapon, 'سلاح حاد حاسم', 'تسلل وتأثير كيميائي'];
    wSel.innerHTML = weapons.map(w => `<option value="${w}">${w}</option>`).join('');
  }

  // Evidence Select
  const eSel = document.getElementById('ded-evidence-select');
  if (eSel) {
    const evs = [c.evidence, 'محادثة مشفرة', 'تسجيل صوتي مسرب'];
    eSel.innerHTML = evs.map(e => `<option value="${e}">${e}</option>`).join('');
  }

  const statusBox = document.getElementById('deduction-status-box');
  if (statusBox) statusBox.style.display = 'none';

  showModal('deduction-board-modal');
  playClick();
}

function verifyDeduction() {
  const c = state.currentCase;
  if (!c) return;

  const sVal = document.getElementById('ded-suspect-select')?.value;
  const mVal = document.getElementById('ded-motive-select')?.value;
  const wVal = document.getElementById('ded-weapon-select')?.value;
  const eVal = document.getElementById('ded-evidence-select')?.value;

  const isCorrect = (sVal === c.culpritName && mVal === c.motive && wVal === c.weapon && eVal === c.evidence);
  const statusBox = document.getElementById('deduction-status-box');

  if (statusBox) {
    statusBox.style.display = 'block';
    if (isCorrect) {
      statusBox.style.background = 'rgba(16,185,129,0.2)';
      statusBox.style.border = '1px solid #10B981';
      statusBox.style.color = '#10B981';
      statusBox.innerHTML = '✅ جميع خيوط الاستنتاج مترابطة منطقياً 100%! يمكنك الآن الاتهام والدخول للمحكمة بثقة.';
      playWin();
    } else {
      statusBox.style.background = 'rgba(255,65,108,0.2)';
      statusBox.style.border = '1px solid #FF416C';
      statusBox.style.color = '#FF416C';
      statusBox.innerHTML = '⚠️ هناك تناقض منطقي بين اختيار المتهم والدافع أو أداة الجريمة، راجع الأدلة والمفكرة!';
      playClick();
    }
  }
}

/* ─── V4.0 FLAGSHIP DETECTIVE ENGINE EXTENSIONS ─────────── */

/* Smartphone Simulator */
function openSmartphone() {
  const c = state.currentCase;
  if (!c) return;
  switchPhoneApp('calls');
  showModal('smartphone-modal');
  playClick();
}

function switchPhoneApp(appName) {
  const c = state.currentCase;
  const content = document.getElementById('phone-app-content');
  if (!content || !c) return;

  if (appName === 'calls') {
    content.innerHTML = `
      <div style="color:#10B981; font-weight:700; margin-bottom:6px;">📞 سجل المكالمات الأخيرة:</div>
      <div style="margin-bottom:4px;">• مكالمة لم يُرد عليها من <strong>${c.culpritName}</strong> (الساعة 10:15 م)</div>
      <div style="margin-bottom:4px;">• مكالمة صادرة إلى الرقم الطوارئ (الساعة 10:40 م - 12 ثانية)</div>
      <div>• مكالمة دولية مشفرة قبل الحادث بـ 3 ساعات.</div>
    `;
  } else if (appName === 'messages') {
    content.innerHTML = `
      <div style="color:#3B82F6; font-weight:700; margin-bottom:6px;">💬 محادثة مسربة (WhatsApp):</div>
      <div style="background:rgba(255,255,255,0.05); padding:6px; border-radius:6px; margin-bottom:6px;">
        <strong>مرسل مجهول:</strong> "إذا لم تنفذ الاتفاق قبل المنتصف، سنتخذ إجراءً حاسماً في ${c.sceneLocation || 'الموقع'}!"
      </div>
    `;
  } else if (appName === 'deleted') {
    content.innerHTML = `
      <div style="color:#EF4444; font-weight:700; margin-bottom:6px;">♻️ استعادة الملفات المحذوفة:</div>
      <p style="margin-bottom:8px;">تم استرجاع مقطع صوتي محذوف: <em>"تسجيل صوتي لتهديد صريح بالدافع (${c.motive})!"</em></p>
      <button class="btn-primary" id="btn-recover-deleted" style="font-size:0.75rem; padding:4px 10px;">إضافة الدليل المسترجَع إلى الحقيبة 💼</button>
    `;
    setTimeout(() => {
      on('btn-recover-deleted', 'click', () => {
        const title = `تسجيل صوتي محذوف: ${c.motive}`;
        if (!state.collectedEvidence.some(e => e.title === title)) {
          state.collectedEvidence.push({ id: Date.now(), title, icon: '🎙️' });
          renderEvidenceDrawer();
          updateEvidenceBadge();
          addNotebookEntry('clue', 'هاتف الجريمة', 'تم استرجاع التسجيل الصوتي المحذوف وإضافته للحقيبة.');
          showToast('✅ تم استرجاع التسجيل الصوتي وإضافته للأدلة!');
          playWin();
        }
      });
    }, 100);
  } else if (appName === 'photos') {
    content.innerHTML = `
      <div style="color:#F59E0B; font-weight:700; margin-bottom:6px;">🖼️ معرض الصور والبيانات الجغرافية:</div>
      <p>صورة التقُطت في ${c.sceneLocation}: <strong>البيانات الوصفية GPS تؤكد وجود المتهم في محيط 50 متر!</strong></p>
    `;
  } else if (appName === 'email') {
    content.innerHTML = `
      <div style="color:#A855F7; font-weight:700; margin-bottom:6px;">📧 البريد الإلكتروني:</div>
      <p>فاتورة شراء أداة الجريمة (<strong>${c.weapon}</strong>) مسجلة باسم أحد المشتبه بهم بتاريخ أمس!</p>
    `;
  } else if (appName === 'gps') {
    content.innerHTML = `
      <div style="color:#06B6D4; font-weight:700; margin-bottom:6px;">📍 تتبع الموقع الجغرافي GPS:</div>
      <p>المارّات الجغرافية: التحرك بدأ من مقر العمل وسجل التوقف النهائي في ${c.sceneLocation} الساعة 10:30 م.</p>
    `;
  }
}

/* Red-String Corkboard */
function openCorkboard() {
  const c = state.currentCase;
  if (!c) return;

  const container = document.getElementById('corkboard-pins-container');
  if (container) {
    container.innerHTML = `
      <div class="cork-pin" style="position:absolute; top:20%; left:15%; background:#EF4444; color:#fff; padding:4px 8px; border-radius:6px; font-size:0.75rem; font-weight:700; border:1px solid #FFF;">
        📌 المتهم: ${c.culpritName}
      </div>
      <div class="cork-pin" style="position:absolute; top:60%; left:30%; background:#F59E0B; color:#fff; padding:4px 8px; border-radius:6px; font-size:0.75rem; font-weight:700; border:1px solid #FFF;">
        📌 الدافع: ${c.motive}
      </div>
      <div class="cork-pin" style="position:absolute; top:35%; left:65%; background:#10B981; color:#fff; padding:4px 8px; border-radius:6px; font-size:0.75rem; font-weight:700; border:1px solid #FFF;">
        📌 الدليل: ${c.evidence}
      </div>
    `;
  }

  const svg = document.getElementById('corkboard-strings-svg');
  if (svg) {
    svg.innerHTML = `
      <line x1="20%" y1="25%" x2="35%" y2="65%" stroke="#EF4444" stroke-width="3" stroke-dasharray="4" />
      <line x1="35%" y1="65%" x2="70%" y2="40%" stroke="#EF4444" stroke-width="3" />
    `;
  }

  showModal('corkboard-modal');
  playClick();
}

function verifyCorkboard() {
  showToast('🧵 خيوط الاستنتاج الحمراء موصولة ومترابطة منطقياً 100%!');
  addNotebookEntry('clue', 'لوحة الفلين الجدارية', 'تم توثيق الترابط بين المتهم والدافع والدليل بخيوط حمراء قاطعة.');
  playWin();
}

/* Suspect Dossier */
function openDossier() {
  const suspect = state.activeSuspect || (state.currentCase ? state.currentCase.suspects[0] : null);
  if (!suspect) return;

  const c = state.currentCase;
  setText('dossier-name', `📁 الملف الجنائي: ${suspect.name}`);
  setText('dossier-role', suspect.role);
  setText('dossier-relation', `مرتبط بالضحية (${c.victimName}) بحكم العمل والقرابة.`);
  setText('dossier-bio', suspect.statement + '\n\n• تشير التحريات إلى تواجده في محيط الجريمة وعدم وجود حجة غياب مؤكدة 100%.');

  const img = document.getElementById('dossier-img');
  if (img) img.src = getCharImage(suspect.name, c.level, 0);

  showModal('suspect-dossier-modal');
  playClick();
}

/* Torch Mode & Scene Exploration */
let torchActive = false;
function toggleTorchMode() {
  torchActive = !torchActive;
  const overlay = document.getElementById('torch-vignette-overlay');
  const btn = document.getElementById('btn-toggle-torch');
  if (overlay) overlay.style.display = torchActive ? 'block' : 'none';
  if (btn) btn.style.background = torchActive ? 'var(--gold)' : 'none';
  if (btn) btn.style.color = torchActive ? '#000' : 'var(--gold)';
  showToast(torchActive ? '🔦 تم تفعيل الكشاف الجنائي للتفتيش المظلم' : '💡 تم إيقاف الكشاف');
  playClick();
}

function searchSceneObject(type) {
  const c = state.currentCase;
  if (!c) return;

  if (type === 'drawers') {
    showToast('🗄️ فتحت الأدراج: عثرت على ملاحظة مكتوبة بخط اليد حول الموعد!');
    addNotebookEntry('clue', 'تفتيش الأدراج', 'ملاحظة سرية مدونة بخط يدوي تم العثور عليها داخل أدراج المكتب.');
  } else if (type === 'carpet') {
    showToast('🧹 رفعت السجادة: عثرت على آثار دماء خفيفة ومفتاح سري!');
    addNotebookEntry('clue', 'تفتيش السجادة', 'آثار دماء ملوثة خفيفة تم رصدها أسفل سجاد المسرح.');
  } else if (type === 'painting') {
    showToast('🖼️ فحصت خلف اللوحة: عثرت على رقم الخزينة السرية!');
    addNotebookEntry('clue', 'خلف اللوحة الجدارية', 'رمز سري مرقوم خلف الإطار الفني.');
  }
  playWin();
}

/* Event Binding Updates */
const originalBindEvents = bindEvents;
bindEvents = function () {
  originalBindEvents();

  // Phone buttons
  on('btn-open-phone', openSmartphone);
  on('btn-close-phone', () => hideModal('smartphone-modal'));
  document.querySelectorAll('.phone-app-icon').forEach(btn => {
    btn.addEventListener('click', () => {
      const app = btn.getAttribute('data-app');
      switchPhoneApp(app);
      playClick();
    });
  });

  // Corkboard buttons
  on('btn-open-corkboard', openCorkboard);
  on('btn-close-corkboard', () => hideModal('corkboard-modal'));
  on('btn-verify-cork-strings', verifyCorkboard);

  // Dossier
  on('btn-view-dossier', openDossier);
  on('btn-close-dossier', () => hideModal('suspect-dossier-modal'));

  // Evidence Inspector (2D)
  on('btn-close-inspect-modal', 'click', () => hideModal('evidence-inspect-modal'));

  // Evidence Inspector
  on('btn-close-inspector', 'click', () => hideModal('evidence-inspector-modal'));

  // Torch & Scene Actions
  on('btn-toggle-torch', toggleTorchMode);
  on('btn-search-drawers', () => searchSceneObject('drawers'));
  on('btn-search-carpet', () => searchSceneObject('carpet'));
  on('btn-search-painting', () => searchSceneObject('painting'));
};

function showVictory(rewardCoins) {
  const c = state.currentCase;
  if (!c) return;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';

  const totalTime = getLevelTimeSec(c.iqLevel || 80);
  const remaining = state.timerSec;
  const mR = Math.floor(remaining / 60);
  const sR = (remaining % 60).toString().padStart(2, '0');

  setText('victory-culprit', c.culpritName || (isEn ? 'Culprit' : 'الجاني'));
  setText('victory-reward', `+${rewardCoins || 500} 🪙`);

  const expEl = document.getElementById('victory-explanation');
  if (expEl) {
    const timeSummary = isEn
      ? `\n\n⏱️ Remaining Time: ${mR}:${sR} / Total Allotted: ${Math.floor(totalTime / 60)}:${(totalTime % 60).toString().padStart(2, '0')}`
      : `\n\n⏱️ الوقت المتبقي: ${mR}:${sR} / مجموع الوقت: ${Math.floor(totalTime / 60)}:${(totalTime % 60).toString().padStart(2, '0')}`;
    expEl.textContent = (c.solutionExplanation || (isEn ? 'The culprit has been exposed and convicted successfully!' : 'تم كشف الجاني وإثبات التهمة بنجاح!')) + timeSummary;
  }

  const nextBtn = document.getElementById('btn-next-level');
  if (nextBtn) {
    if (c.level < 100) {
      nextBtn.textContent = isEn ? `Case ${c.level + 1} ➔` : `القضية ${c.level + 1} ➔`;
    } else {
      nextBtn.textContent = isEn ? '🏆 All Cases Completed!' : '🏆 أنهيت جميع القضايا!';
    }
  }
  showModal('victory-modal');
}

function showDefeat(msg) {
  setText('defeat-message', msg);
  showModal('defeat-modal');
}

function showModal(id) {
  const el = document.getElementById(id);
  if (el) { el.style.display = 'flex'; el.classList.add('modal-pop'); }
}
function hideModal(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'none';
}

/* ─── LEVELS GRID ────────────────────────────────────────── */
function openLevelsModal() {
  const grid = document.getElementById('modal-levels-grid');
  if (!grid) return;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';

  const completedCount = state.completed.size;
  const percent = Math.round((completedCount / 100) * 100);

  setText('overall-progress-text', isEn ? `${percent}% (${completedCount}/100 Cases)` : `${percent}% (${completedCount}/100 قضية)`);
  const progressBar = document.getElementById('overall-progress-bar');
  if (progressBar) progressBar.style.width = `${percent}%`;

  // Rebuild grid with IQ difficulty dots
  grid.innerHTML = '';
  for (let i = 1; i <= 100; i++) {
    const card = document.createElement('button');
    const done = state.completed.has(i);
    const iq = i <= 20 ? 80 : i <= 45 ? 100 : i <= 70 ? 120 : i <= 90 ? 140 : 160;
    card.className = 'level-grid-btn' + (done ? ' completed' : '');
    card.innerHTML = `<span>${i}</span>${done ? '<span class="star">⭐</span>' : `<span class="iq-dot iq-dot-${iq}"></span>`}`;
    card.title = done ? `قضية ${i} — مكتملة ⭐` : `قضية ${i} (IQ ${iq})`;
    card.onclick = () => {
      hideModal('levels-modal');
      showGameInterstitial();
      loadLevel(i);
    };
    grid.appendChild(card);
  }
  showModal('levels-modal');
}

/* ─── TOAST ──────────────────────────────────────────────── */
function showToast(msg) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

/* ─── SOUNDS ──────────────────────────────────────────────── */
function playClick() {
  AudioEngine.init();
  if (!AudioEngine.ctx) return;
  try {
    const o = AudioEngine.ctx.createOscillator(), g = AudioEngine.ctx.createGain();
    o.type = 'sine'; o.frequency.value = 660;
    g.gain.setValueAtTime(0.08, AudioEngine.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, AudioEngine.ctx.currentTime + 0.08);
    o.connect(g); g.connect(AudioEngine.ctx.destination);
    o.start(); o.stop(AudioEngine.ctx.currentTime + 0.08);
  } catch (e) { }
}

function playWin() {
  AudioEngine.init();
  if (!AudioEngine.ctx) return;
  try {
    const notes = [523, 659, 784, 1047];
    notes.forEach((freq, i) => {
      const o = AudioEngine.ctx.createOscillator(), g = AudioEngine.ctx.createGain();
      o.type = 'triangle'; o.frequency.value = freq;
      const t = AudioEngine.ctx.currentTime + i * 0.12;
      g.gain.setValueAtTime(0.15, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
      o.connect(g); g.connect(AudioEngine.ctx.destination);
      o.start(t); o.stop(t + 0.2);
    });
  } catch (e) { }
}

/* ─── INTERSTITIAL ADS CONTROLLER ────────────────────────── */
let lastInterstitialTimestamp = 0;
function showGameInterstitial() {
  const now = Date.now();
  // Throttle to at least 15 seconds to prevent rapid consecutive triggers
  if (now - lastInterstitialTimestamp < 15000) return;
  lastInterstitialTimestamp = now;
  if (typeof window !== 'undefined' && window.GameAds) {
    try {
      window.GameAds.postMessage('showInterstitial');
    } catch (e) {
      console.log('Error triggering interstitial ad:', e);
    }
  }
}

/* ─── BIND EVENTS ────────────────────────────────────────── */
function bindEvents() {
  on('btn-toggle-music', 'click', () => AudioEngine.toggleMusic());

  // Splash & Direct Start to Suspects
  on('btn-start-investigation', () => {
    AudioEngine.playClickSFX();
    playBGM();
    showGameInterstitial();
    loadLevel(state.level || 1, true);
  });
  on('btn-splash-chapters', 'click', openChaptersModal);
  on('btn-open-chapters', 'click', openChaptersModal);
  on('btn-enter-crime-scene', 'click', proceedFromIntroToDashboard);
  on('btn-intro-skip', 'click', proceedFromIntroToDashboard);
  on('btn-show-rank', 'click', openRankProfileModal);
  on('btn-hud-hint', 'click', useSmartHint);
  on('btn-open-case-files', 'click', () => {
    AudioEngine.playClickSFX();
    openLevelsModal();
  });

  // Dashboard
  on('btn-back-to-dossier', 'click', () => {
    if (state.currentCase) {
      showCaseIntroScreen(state.currentCase);
    }
  });
  on('btn-crime-scene', 'click', goToCrimeScene);
  on('btn-toggle-drawer', 'click', toggleDrawer);
  on('btn-levels-modal', 'click', openLevelsModal);
  on('btn-hint-dash', 'click', useHint);
  on('btn-back-from-interrogate', 'click', () => {
    showScreen('case-dashboard-screen', 'back');
    // Keep timer running but update display to show it's still active
    if (state.timerRunning) updateTimerDisplay();
    if (state.level === 1) {
      TutorialManager.triggerLevel1Guide(4);
    }
  });
  on('btn-back-from-scene', 'click', () => {
    // Stop 2D canvas engine to save battery
    if (typeof window.stopCrimeScene2D === 'function') window.stopCrimeScene2D();
    showScreen('case-dashboard-screen', 'back');
    if (state.timerRunning) updateTimerDisplay();
    if (state.level === 1) {
      const hasEvidence = state.collectedEvidence.length > 0;
      TutorialManager.triggerLevel1Guide(hasEvidence ? 4 : 1);
    }
  });

  // Crime scene
  on('btn-collect-evidence', 'click', collectEvidence);

  // Interrogation & Accusation
  on('btn-accuse-suspect', 'click', openVerdictModal);
  on('btn-accuse-dash', 'click', openVerdictModal);
  on('btn-hint-interrogate', 'click', useHint);

  // Drawer & Notebook
  on('btn-close-drawer', 'click', closeDrawer);
  on('btn-open-notebook', 'click', toggleNotebookDrawer);
  on('btn-open-notebook-dash', 'click', toggleNotebookDrawer);
  on('btn-close-notebook-drawer', 'click', closeNotebookDrawer);
  initNotebookTabs();

  // Victory
  on('btn-next-level', 'click', () => {
    hideModal('victory-modal');
    showGameInterstitial();
    if (state.level < 100) loadLevel(state.level + 1);
    else showScreen('splash-screen');
  });
  on('btn-replay-level', 'click', () => {
    hideModal('victory-modal');
    loadLevel(state.level);
  });

  // Defeat
  on('btn-retry', 'click', () => {
    hideModal('defeat-modal');
    showGameInterstitial();
    loadLevel(state.level);
  });
  on('btn-defeat-hint', 'click', () => {
    hideModal('defeat-modal');
    useHint();
  });

  // Modals dismiss
  on('btn-close-levels', 'click', () => hideModal('levels-modal'));
  on('btn-close-hint', 'click', () => hideModal('hint-modal'));
  on('btn-close-accuse-modal', 'click', () => hideModal('accuse-evidence-modal'));
  on('btn-close-lab-modal', 'click', () => hideModal('forensic-lab-modal'));
  on('btn-open-lab', 'click', openForensicLabModal);

  // Evidence inspector modals close buttons
  on('btn-close-inspector', 'click', () => hideModal('evidence-inspector-modal'));
  on('btn-close-3d-inspector', 'click', () => hideModal('modal-3d-evidence-inspector'));
  on('btn-close-telemetry', 'click', () => hideModal('telemetry-dashboard-modal'));
  on('btn-close-deduction', 'click', () => hideModal('deduction-board-modal'));
  on('btn-close-phone', 'click', () => hideModal('smartphone-modal'));
  on('btn-close-dossier', 'click', () => hideModal('suspect-dossier-modal'));
  on('btn-close-theory', 'click', () => hideModal('case-theory-builder-modal'));
  on('btn-close-verdict', 'click', () => hideModal('verdict-modal'));

  on('btn-verdict-back', 'click', () => {
    // go back one step (find current step)
    for (let i = 4; i >= 2; i--) {
      const p = document.getElementById(`vp-${i}`);
      if (p && p.classList.contains('active')) { goToVerdictStep(i - 1); break; }
    }
  });
}

/* ─── V5.0 STRATEGIC GAMEPLAY ENGINE EXTENSIONS ─────────── */

/* Progressive Feature Unlocking per Level Range */
function isFeatureUnlocked(featureKey, level) {
  if (level === 'daily') return true;
  const lvl = level || state.level || 1;
  if (featureKey === 'phone' && lvl < 11) return false;
  if (featureKey === 'lab' && lvl < 21) return false;
  if (featureKey === 'corkboard' && lvl < 41) return false;
  return true;
}

/* Daily AI Procedural Case Generator */
function startDailyCase() {
  const seed = new Date().getDate() + new Date().getMonth() * 31;
  const victimNames = ['د. طارق الحكيم', 'م. سليم الجوهري', 'المهندسة نادية صادق', 'التاجر كمال الشريف'];
  const victim = victimNames[seed % victimNames.length];

  const dailyCase = {
    level: 'daily',
    title: '📅 القضية اليومية الخاصة (AI Daily Case)',
    crimeType: 'قتل واستيلاء على عينات سرية',
    sceneLocation: 'المختبر الجنائي المركزي',
    victimName: victim,
    description: `تم العثور على ${victim} متوفى في ظروف غامضة داخل المختبر الذكي. عُثر على هاتف ملقى وبقع مواد كيميائية وساعات توقف متزامنة!`,
    culpritName: 'د. سامح زكي',
    culpritRole: 'رئيس قسم الأبحاث',
    motive: 'سرقة معادلة الكيمياء الحيوية وإلغاء براءة الاختراع',
    weapon: 'سم سمي خفي أُضيف إلى الفنجان',
    evidence: '🧪 فنجان ملوث بآثار المادة الكيميائية الخفية',
    iqLevel: 140,
    suspects: [
      { id: 'd1', name: 'د. سامح زكي', role: 'رئيس قسم الأبحاث', statement: 'كنت أعاين العينات في القاعة الشرقية ولم أقترب من مكتب الضحية.' },
      { id: 'd2', name: 'منى الفايز', role: 'أخصائية التحاليل', statement: 'سمعت صراخاً خفيفاً في تمام الساعة 10:15 مساءً وسارعت لإبلاغ الأمن.' },
      { id: 'd3', name: 'عادل عمران', role: 'حارس الأمن الليلي', statement: 'لم يدخل أي غريب للمبنى، كل التركات كانت من الطاقم الداخلي.' }
    ]
  };

  state.currentCase = dailyCase;
  state.collectedEvidence = [];
  renderDashboard();
  showScreen('case-dashboard-screen');
  showToast('📅 تم توليد القضية اليومية بالذكاء الاصطناعي بنجاح! حظاً موفقاً يا سيادة المحقق.');
  playWin();
}

/* Dynamic Live Timeline Ticker System */
function updateLiveTimelineTicker() {
  const tickerTime = document.getElementById('ticker-time');
  const tickerEvent = document.getElementById('ticker-event');
  if (!tickerTime || !tickerEvent) return;

  const totalTime = getLevelTimeSec(state.currentCase?.iqLevel || 80);
  const elapsedRatio = 1 - (state.timerSec / totalTime);

  if (elapsedRatio < 0.25) {
    tickerTime.textContent = '08:00 AM';
    tickerEvent.textContent = 'وقوع الجريمة واكتشاف الموقع';
  } else if (elapsedRatio < 0.50) {
    tickerTime.textContent = '08:30 AM';
    tickerEvent.textContent = '🚨 شاهد جديد يدلي بشهادة عن تحركات مشبوهة!';
  } else if (elapsedRatio < 0.75) {
    tickerTime.textContent = '09:00 AM';
    tickerEvent.textContent = '🔬 وصول النتائج الأوليّة للمعمل الجنائي هاتفياً!';
  } else {
    tickerTime.textContent = '09:30 AM';
    tickerEvent.textContent = '⚠️ أحد المشتبه بهم يبدي ارتباكاً ويحاول تبرير حجة غيابه!';
  }
}

// Hook timer interval to update live ticker
const originalStartTimer = startTimer;
startTimer = function () {
  originalStartTimer();
  updateLiveTimelineTicker();
};

/* Case Theory Builder Engine */
function openCaseTheoryBuilder() {
  const c = state.currentCase;
  if (!c) return;

  setText('theory-victim-name', c.victimName);

  const sSel = document.getElementById('theory-suspect-select');
  if (sSel) {
    sSel.innerHTML = (c._displaySuspects || c.suspects).map(s => `<option value="${s.name}">${s.name} (${s.role})</option>`).join('');
  }

  const mSel = document.getElementById('theory-motive-select');
  if (mSel) {
    const motives = [c.motive, 'الحسد والتنافس المالي', 'تدمير المستندات الرسمية'];
    mSel.innerHTML = motives.map(m => `<option value="${m}">${m}</option>`).join('');
  }

  const wSel = document.getElementById('theory-weapon-select');
  if (wSel) {
    const weapons = [c.weapon, 'سلاح حاد حاسم', 'تأثير سمومي خفي'];
    wSel.innerHTML = weapons.map(w => `<option value="${w}">${w}</option>`).join('');
  }

  const eSel = document.getElementById('theory-evidence-select');
  if (eSel) {
    const evs = [c.evidence, 'تسجيل صوتي مسرب', 'محادثة مشفرة'];
    eSel.innerHTML = evs.map(e => `<option value="${e}">${e}</option>`).join('');
  }

  showModal('case-theory-builder-modal');
  playClick();
}

function submitCaseTheory() {
  const c = state.currentCase;
  if (!c) return;

  const s = document.getElementById('theory-suspect-select')?.value;
  const m = document.getElementById('theory-motive-select')?.value;
  const w = document.getElementById('theory-weapon-select')?.value;
  const e = document.getElementById('theory-evidence-select')?.value;

  hideModal('case-theory-builder-modal');

  if (s === c.culpritName && m === c.motive && w === c.weapon && e === c.evidence) {
    showToast('⚖️ نظرية القضية منطقية ومكتملة الخيوط 100%! جاري التوجه للمحكمة...');
    playWin();
    accuseSuspect();
  } else {
    showDefeat(`❌ تم رفض نظرية القضية! أحد عناصرها الأربعة خاطئ.\n\n🔍 أعد الفحص واستجواب المشتبه بهم بشكل أعمق للوصول إلى الحقيقة.`);
    playClick();
  }
}

/* Event Binding Updates V5.0 */
const v4BindEvents = bindEvents;
bindEvents = function () {
  v4BindEvents();

  on('btn-daily-case', startDailyCase);

  on('btn-open-theory', openCaseTheoryBuilder);
  on('btn-close-theory', () => hideModal('case-theory-builder-modal'));
  on('btn-submit-case-theory', submitCaseTheory);

  // Progressive Feature Unlocking Overrides
  const phoneBtn = document.getElementById('btn-open-phone');
  if (phoneBtn) {
    phoneBtn.addEventListener('click', (e) => {
      if (!isFeatureUnlocked('phone')) {
        e.stopImmediatePropagation();
        showToast('🔒 هاتف الضحية ينفتح في المستوى 11 ضمن التدرّج المهني للمحقق!');
      }
    }, true);
  }

  const labBtn = document.getElementById('btn-open-lab');
  if (labBtn) {
    labBtn.addEventListener('click', (e) => {
      if (!isFeatureUnlocked('lab')) {
        e.stopImmediatePropagation();
        showToast('🔒 معمل الطب الشرعي ينفتح في المستوى 21!');
      }
    }, true);
  }

  const corkBtn = document.getElementById('btn-open-corkboard');
  if (corkBtn) {
    corkBtn.addEventListener('click', (e) => {
      if (!isFeatureUnlocked('corkboard')) {
        e.stopImmediatePropagation();
        showToast('🔒 لوحة الخيوط الحمراء تنفتح في المستوى 41!');
      }
    }, true);
  }
};

/* ─── V6.0 MASTERPIECE GAMEPLAY ENGINE EXTENSIONS ─────────── */

/* Free-Roam Sandbox Mode */
let isSandboxMode = false;

function startSandboxMode() {
  isSandboxMode = true;
  state.level = 'sandbox';
  const c = state.currentCase || (LEVELS_DATA.length > 0 ? LEVELS_DATA[0] : null);
  if (!c) return;

  state.currentCase = c;
  state.collectedEvidence = [];
  renderDashboard();

  // Show Sandbox badge
  const catEl = document.getElementById('dashboard-category-badge');
  if (catEl) {
    catEl.textContent = '🕵️‍♂️ وضع المحقق الحر (Sandbox Mode)';
    catEl.style.background = 'rgba(139,92,246,0.25)';
    catEl.style.color = '#A78BFA';
    catEl.style.borderColor = '#8B5CF6';
  }

  showScreen('case-dashboard-screen');
  showToast('🕵️‍♂️ تم تفعيل وضع المحقق الحر! حرية كاملة للتفتيش، الفحص، والمحاكمة.');
  playWin();
}

/* Courtroom Cross-Examination System */
let pendingTrialCulprit = null;

function openCourtroomTrial(culpritName) {
  const c = state.currentCase;
  if (!c) return;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';

  pendingTrialCulprit = culpritName || c.culpritName;
  const qEl = document.getElementById('judge-question-text');
  if (qEl) {
    qEl.textContent = isEn
      ? `"Detective, you have formally accused ${pendingTrialCulprit} of this crime. What decisive direct physical evidence do you submit before the court to prove their guilt beyond reasonable doubt?"`
      : `"سيادة المحقق، لقد اتهمت ${pendingTrialCulprit} بالتورط الإجرامي. ما هو الدليل المادي القاطع المباشر الذي تقدمه أمام هيئة المحكمة لإدانته؟"`;
  }

  const list = document.getElementById('court-evidence-options-list');
  if (list) {
    list.innerHTML = '';

    // Mix collected evidence + distractors
    const options = isEn
      ? [
          c.evidence || 'Decisive physical clue recovered from the scene',
          '💬 Uncorroborated oral witness statement',
          '📄 Outdated financial ledger from last year',
          '🔍 General observation of nervousness during questioning'
        ]
      : [
          c.evidence || 'الدليل المادي القاطع المرفوع من المسرح',
          '💬 شهادة شفهية غير مؤكدة من أحد الجيران',
          '📄 تقرير مالي قديم يرجع للعام الماضي',
          '🔍 انطباع عام حول الارتباك أثناء الاستجواب'
        ];

    options.forEach(ev => {
      const btn = document.createElement('button');
      btn.className = 'verdict-option-btn';
      btn.innerHTML = `<span>⚖️</span> <span>${isEn ? 'Present Evidence:' : 'تقديم الدليل:'} <strong>${ev}</strong></span>`;
      btn.onclick = () => evaluateCourtroomEvidence(ev);
      list.appendChild(btn);
    });
  }

  showModal('courtroom-trial-modal');
  playClick();
}

function evaluateCourtroomEvidence(chosenEvidence) {
  hideModal('courtroom-trial-modal');
  const c = state.currentCase;
  if (!c) return;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';

  if (chosenEvidence === c.evidence || (c.evidence && chosenEvidence.includes(c.evidence))) {
    // Conclusive Conviction!
    const earnedXP = 500 + (typeof c.level === 'number' ? c.level * 10 : 200);
    state.coins += 500;
    addXP(earnedXP);
    if (typeof c.level === 'number') state.completed.add(c.level);
    saveProgress(); updateHUD();

    showVictory(500);
    setText('victory-title', isEn ? `⚖️ The Court Sentences the Culprit to Full Conviction!` : `⚖️ حكمت المحكمة بالسجن المشدد والإدانة القاطعة!`);
    playWin();
  } else {
    // Insufficient Evidence Release!
    state.coins = Math.max(0, state.coins - 50);
    saveProgress(); updateHUD();

    showDefeat(isEn
      ? `⚖️ Final Court Ruling:\n"The Court orders the suspect's release due to insufficient material evidence!"\n\n🔍 Search for conclusive evidence at the crime scene and try again!`
      : `⚖️ قرار المحكمة النهائي:\n"أمرت المحكمة بالإفراج عن المتهم لعدم كفاية الأدلة المادية القاطعة!"\n\n🔍 ابحث عن الدليل القاطع في مسرح الجريمة وجربه مجدداً!`);
    playClick();
  }
}

/* Event Binding Updates V6.0 */
const v5BindEvents = bindEvents;
bindEvents = function () {
  v5BindEvents();

  on('btn-sandbox-mode', startSandboxMode);
  on('btn-close-courtroom', () => hideModal('courtroom-trial-modal'));
};

/* ─── V7.0 ULTIMATE ARCHITECTURE GAMEPLAY ENGINE EXTENSIONS ─────────── */

/* 1️⃣ Granular CaseState Persistence System */
function saveCaseState() {
  if (!state.currentCase) return;

  const caseStateTree = {
    caseId: state.currentCase.level || 'daily',
    collectedEvidence: state.collectedEvidence || [],
    notebook: state.notebook || [],
    openedDrawers: !!state.openedDrawers,
    carpetSearched: !!state.carpetSearched,
    paintingMoved: !!state.paintingMoved,
    torchActive: !!torchActive,
    timerSec: state.timerSec || 0,
    timestamp: Date.now()
  };

  try {
    localStorage.setItem('unknown_culprit_case_state', JSON.stringify(caseStateTree));
  } catch (e) {
    console.warn('Unable to save CaseState:', e);
  }
}

function restoreCaseState() {
  try {
    const data = localStorage.getItem('unknown_culprit_case_state');
    if (!data) return false;
    const tree = JSON.parse(data);

    if (state.currentCase && (state.currentCase.level === tree.caseId)) {
      state.collectedEvidence = tree.collectedEvidence || [];
      state.notebook = tree.notebook || [];
      state.openedDrawers = tree.openedDrawers;
      state.carpetSearched = tree.carpetSearched;
      state.paintingMoved = tree.paintingMoved;
      if (tree.torchActive) toggleTorchMode();
      renderDashboard();
      renderNotebook();
      showToast('🔄 تم استرجاع تفاصيل واستنتاجات القضية السابقة بنجاح!');
      return true;
    }
  } catch (e) {
    console.warn('Unable to restore CaseState:', e);
  }
  return false;
}

/* 2️⃣ Dynamic World Event System */
function triggerWorldEvent() {
  const events = [
    '🌧️ هطول أمطار غزيرة خارج الموقع تسببت في مسح بعض الآثار الخارجية!',
    '⚡ انقطاع مفاجئ للتيار الكهربائي في الموقع وتم تفعيل الكشاف الجنائي تلقائياً!',
    '📰 تسريب إعلامي عاجل للصحافة أدى لزيادة توتر وخوف جميع المشتبه بهم!',
    '🗣️ شاهد عيان جديد يدلي بأقوال طارئة تعدل التسلسل الزمني للأحداث!'
  ];

  const randEv = events[Math.floor(Math.random() * events.length)];
  const banner = document.getElementById('world-event-alert-banner');
  const textEl = document.getElementById('world-event-text');

  if (banner && textEl) {
    textEl.textContent = randEv;
    banner.style.display = 'flex';
    banner.classList.add('modal-pop');
    playClick();
  }

  // Trigger blackout torch if event is power outage
  if (randEv.includes('انقطاع مفاجئ') && !torchActive) {
    toggleTorchMode();
  }
}

/* 3️⃣ NPC AI Personality Vector Engine */
function updateNpcPersonality(suspectId) {
  const c = state.currentCase;
  if (!c) return;

  const currentPressure = state.suspectPressure[suspectId] || 0;

  // Calculate dynamic vectors
  const fear = Math.min(100, Math.floor(currentPressure * 0.95));
  const confidence = Math.max(0, Math.floor(100 - currentPressure * 0.85));
  const anger = Math.min(100, Math.floor((100 - confidence) * 0.5));

  setText('vec-confidence', `${confidence}%`);
  setText('vec-fear', `${fear}%`);
  setText('vec-anger', `${anger}%`);
}

// Hook interrogation choice to update personality vectors and save state
// Define stub if not already defined (actual logic is inline in startInterrogation)
if (typeof chooseInterrogationOption === 'undefined') {
  var chooseInterrogationOption = function (suspectId, choiceIdx) { };
}
const originalChooseInterrogationOption = chooseInterrogationOption;
chooseInterrogationOption = function (suspectId, choiceIdx) {
  originalChooseInterrogationOption(suspectId, choiceIdx);
  updateNpcPersonality(suspectId);
  saveCaseState();
};

/* Event Binding Updates V7.0 */
const v6BindEvents = bindEvents;
bindEvents = function () {
  v6BindEvents();

  // Try restoring case state on start
  restoreCaseState();

  // Schedule random World Event after 15 seconds of investigation
  setTimeout(triggerWorldEvent, 15000);
};

/* ─── V8.0 AAA MODULAR ENGINE ARCHITECTURE EXTENSIONS ─────────── */

/* 1️⃣ Centralized Event Bus System */
const EventBus = {
  listeners: {},
  on(eventName, handler) {
    if (!this.listeners[eventName]) this.listeners[eventName] = [];
    this.listeners[eventName].push(handler);
  },
  publish(eventName, data) {
    if (this.listeners[eventName]) {
      this.listeners[eventName].forEach(fn => fn(data));
    }
  }
};

/* 2️⃣ Case Finite State Machine (FSM) Engine */
const CaseFSM = {
  currentState: 'CRIME_SCENE',
  setState(newState) {
    this.currentState = newState;
    EventBus.publish('CASE_STATE_CHANGED', newState);
  }
};

/* 3️⃣ Data Versioning & Migration Engine */
const SaveMigrator = {
  CURRENT_VERSION: '8.0',
  ensureVersion(saveObject) {
    if (!saveObject) return { version: this.CURRENT_VERSION };
    if (!saveObject.version) saveObject.version = this.CURRENT_VERSION;
    return saveObject;
  }
};

/* 4️⃣ Implicit NPC Body Language & Expression Engine */
function updateImplicitNpcExpressions(suspectId) {
  const currentPressure = (state.suspectPressure && state.suspectPressure[suspectId]) || suspectPressure || 0;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';

  const faceEl = document.getElementById('expression-face-text');
  const bodyEl = document.getElementById('expression-body-text');

  if (!faceEl || !bodyEl) return;

  if (currentPressure < 30) {
    faceEl.textContent = isEn ? '👀 Facial Expression: Calm and maintaining direct eye contact.' : '👀 تعبيرات الوجه: هادئ ويتطلع بثبات مباشر في عيني المحقق.';
    bodyEl.textContent = isEn ? '🤚 Body Language: Relaxed with steady, regular breathing.' : '🤚 لغة الجسد: مسترخٍ وتنفسه منتظم كلياً.';
  } else if (currentPressure < 70) {
    faceEl.textContent = isEn ? '👀 Facial Expression: Averting eye contact and swallowing nervously.' : '👀 تعبيرات الوجه: يتجنب التواصل البصري ويزدرد ريقه عند السؤال.';
    bodyEl.textContent = isEn ? '🤚 Body Language: Restless finger tapping and shifting posture.' : '🤚 لغة الجسد: حركة مضطربة لأصابعه وتوتر خفيف في الجلسة.';
  } else {
    faceEl.textContent = isEn ? '👀 Facial Expression: Dilated pupils and cold sweat glistening on brow!' : '👀 تعبيرات الوجه: حدقتا عينيه تتسعان برعب وعرق بارد على جبينه!';
    bodyEl.textContent = isEn ? '🤚 Body Language: Trembling hands and faltering voice before speaking!' : '🤚 لغة الجسد: يشبك يديه بتردد مرتعد وصوته يتلعثم قبل الرد!';
  }
}

// Override updateNpcPersonality to use implicit expressions instead of raw numbers
updateNpcPersonality = function (suspectId) {
  updateImplicitNpcExpressions(suspectId);
};

/* 5️⃣ Telemetry & Developer Analytics Engine */
const TelemetryEngine = {
  stats: { casesPlayed: 1, casesWon: 1, falseAccusations: 0 },

  recordWin() {
    this.stats.casesWon++;
    this.updateDashboardUI();
  },

  recordFalseAccusation() {
    this.stats.falseAccusations++;
    this.updateDashboardUI();
  },

  updateDashboardUI() {
    const rateEl = document.getElementById('tel-success-rate');
    const falseEl = document.getElementById('tel-false-accusations');
    if (rateEl) {
      const rate = Math.round((this.stats.casesWon / Math.max(1, this.stats.casesPlayed)) * 100);
      rateEl.textContent = `${rate}%`;
    }
    if (falseEl) falseEl.textContent = this.stats.falseAccusations;
  }
};

/* Event Binding Updates V8.0 */
const v7BindEvents = bindEvents;
bindEvents = function () {
  v7BindEvents();

  on('btn-close-telemetry', () => hideModal('telemetry-dashboard-modal'));

  // Subscribe EventBus listeners
  EventBus.on('EVIDENCE_FOUND', (evData) => {
    addNotebookEntry('clue', 'دليل مادي مكتشف', evData);
    addXP(50);
  });
};

/* ─── V9.0 PHYSICAL INTERACTIVE ENGINE EXTENSIONS ─────────── */

/* 1️⃣ Physical Drag & Drop Tools System */
let activeDraggedTool = null;

function initDragAndDropTools() {
  const tools = document.querySelectorAll('.tool-item-drag');
  tools.forEach(tool => {
    tool.addEventListener('dragstart', (e) => {
      activeDraggedTool = tool.getAttribute('data-tool');
      e.dataTransfer.setData('text/plain', activeDraggedTool);
      playClick();
    });
  });

  const dropzone = document.getElementById('dropzone-locked-door');
  if (dropzone) {
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.style.background = 'rgba(255,183,3,0.25)';
      dropzone.style.borderColor = 'var(--cyan)';
    });

    dropzone.addEventListener('dragleave', () => {
      dropzone.style.background = 'rgba(255,183,3,0.08)';
      dropzone.style.borderColor = 'var(--gold)';
    });

    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.style.background = 'rgba(255,183,3,0.08)';
      dropzone.style.borderColor = 'var(--gold)';
      const toolType = e.dataTransfer.getData('text/plain') || activeDraggedTool;
      evaluateToolDropAction(toolType);
    });
  }
}

/* 2️⃣ Multiple Solution Paths & Soft Consequences Engine */
function evaluateToolDropAction(toolType) {
  if (toolType === 'key') {
    showToast('🔑 استخدام المفتاح الأصلي: فتح الباب بسلاسة ونظافة وحفظ كامل للأدلة (+100% تقييم)!');
    addNotebookEntry('clue', 'فتح الباب بالمفتاح', 'تم فتح الباب دون تدمير مع الحفاظ الكامل على نسيج الموقع.');
    playWin();
  } else if (toolType === 'hammer') {
    showToast('🔨 استخدام المطرقة: كسر القفل بالقوة المباشرة وحدثت ضوضاء مع تضرر جزئي بالمقابض!');
    addNotebookEntry('clue', 'كسر القفل بالقوة', 'تم فتح الباب بالقوة المباشرة مع إحداث أضرار طفيفة بإطار الباب.');
    state.coins = Math.max(0, state.coins - 20);
    playClick();
  } else if (toolType === 'screwdriver') {
    showToast('🪛 استخدام المفك: فك مفصلات الباب بهدوء وسحب الترباس (+90% تقييم).');
    addNotebookEntry('clue', 'فك مفصلات الباب', 'تم سحب الترباس بهدوء ودقة جنائية عالية.');
    playWin();
  } else if (toolType === 'powder') {
    showToast('🧤 تطبيق بودرة البصمات: ظهرت 3 بصمات واضحة على مقبض الباب الجانبي!');
    addNotebookEntry('clue', 'بصمات مقبض الباب', 'تم رفـع 3 بصمات جنائية متباينة وإرسالها للمعمل.');
    playWin();
  } else if (toolType === 'uv') {
    showToast('🔦 تطبيق مصباح UV: ظهرت بقع مواد كيميائية خفية متطايرة أسفل الحافة!');
    addNotebookEntry('clue', 'آثار الأشعة فوق البنفسجية', 'رصد بقع مادة بيولوجية مشعة تحت ضوء UV.');
    playWin();
  }
}

/* 3️⃣ Ambient & Distractor Room Interaction */
function interactWithAmbientObject(objType) {
  if (objType === 'bed') {
    showToast('🛏️ فحصت السرير: المفارش مرتبة كلياً ولا يوجد أي مخبأ أسفل الوسادة.');
  } else if (objType === 'clock') {
    showToast('🕰️ فحصت الساعة الجدارية: توقفت العقارب تماماً عند الساعة 09:15 مساءً.');
  }
  playClick();
}

/* Event Binding Updates V9.0 */
const v8BindEvents = bindEvents;
bindEvents = function () {
  v8BindEvents();

  initDragAndDropTools();

  on('btn-search-bed', () => interactWithAmbientObject('bed'));
  on('btn-search-clock', () => interactWithAmbientObject('clock'));
};

/* ─── V10.0 IMMERSIVE EVIDENCE INSPECTION 360° ENGINE ─────────── */

/* 1️⃣ Haptic Feedback Vibration Integration */
function triggerHapticFeedback(pattern) {
  try {
    if (navigator.vibrate) {
      navigator.vibrate(pattern || [30, 40, 30]);
    }
  } catch (e) { }
}

/* 2️⃣ 360° 3D Evidence Object Inspector Engine */
let current3DRotY = 0;
let current3DRotX = 0;
let isDragging3D = false;
let startX = 0;
let startY = 0;

function open3DEvidenceInspector(icon, title) {
  const iconEl = document.getElementById('inspector-3d-object-view');
  const titleEl = document.getElementById('inspector-3d-title');
  const traceEl = document.getElementById('inspector-3d-rear-trace');
  const wrap = document.getElementById('inspector-3d-canvas-wrap');

  if (iconEl) iconEl.textContent = icon || '🔪';
  if (titleEl) titleEl.textContent = `🔬 فحص الدليل المادي: ${title || 'دليل جنائي'}`;
  if (traceEl) traceEl.style.display = 'none';

  current3DRotY = 0;
  current3DRotX = 0;
  update3DRotationUI();

  if (wrap) {
    wrap.onmousedown = (e) => { isDragging3D = true; startX = e.clientX; startY = e.clientY; };
    wrap.onmousemove = (e) => {
      if (!isDragging3D) return;
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;
      startX = e.clientX;
      startY = e.clientY;
      current3DRotY += deltaX * 1.5;
      current3DRotX -= deltaY * 1.5;
      update3DRotationUI();
    };
    window.onmouseup = () => { isDragging3D = false; };

    // Touch events for Mobile
    wrap.ontouchstart = (e) => {
      if (e.touches.length > 0) {
        isDragging3D = true;
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
      }
    };
    wrap.ontouchmove = (e) => {
      if (!isDragging3D || e.touches.length === 0) return;
      const deltaX = e.touches[0].clientX - startX;
      const deltaY = e.touches[0].clientY - startY;
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      current3DRotY += deltaX * 1.5;
      current3DRotX -= deltaY * 1.5;
      update3DRotationUI();
    };
    wrap.ontouchend = () => { isDragging3D = false; };
  }

  showModal('modal-3d-evidence-inspector');
  playClick();
}

function update3DRotationUI() {
  const iconEl = document.getElementById('inspector-3d-object-view');
  const statusEl = document.getElementById('inspector-3d-status');
  const traceEl = document.getElementById('inspector-3d-rear-trace');

  const normY = Math.abs(Math.round(current3DRotY) % 360);

  if (iconEl) {
    iconEl.style.transform = `rotateY(${current3DRotY}deg) rotateX(${current3DRotX}deg)`;
  }
  if (statusEl) {
    statusEl.textContent = `دوران 3D نشط — زاوية الدوران الحالي: ${normY}°`;
  }

  // Reveal rear trace when rotated past 140 degrees
  if (normY > 140 && normY < 220 && traceEl) {
    if (traceEl.style.display === 'none') {
      traceEl.style.display = 'block';
      triggerHapticFeedback([50, 100, 50]);
      addNotebookEntry('clue', 'فحص خلفي 3D للدليل', 'تم كشف بصمة مطبوعة في المقبض الخلفي عند تدوير المجسم 360°.');
      playWin();
    }
  }
}

/* Event Binding Updates V10.0 */
const v9BindEvents = bindEvents;
bindEvents = function () {
  v9BindEvents();

  on('btn-close-3d-inspector', () => hideModal('modal-3d-evidence-inspector'));

  // Trigger 3D inspector when clicking scene key evidence
  const keyEl = document.getElementById('scene-evidence-key');
  if (keyEl) {
    keyEl.addEventListener('click', () => open3DEvidenceInspector('🔪', 'سكين الجريمة'));
  }
};

/* ─── HELPERS ─────────────────────────────────────────────── */
function on(id, ev, fn) {
  if (typeof ev === 'function') {
    fn = ev;
    ev = 'click';
  }
  const el = document.getElementById(id);
  if (el && fn) el.addEventListener(ev, fn);
}

// Global Backdrop Click & Escape Key Handler for All Modals
document.addEventListener('click', (e) => {
  if (e.target && e.target.classList && e.target.classList.contains('modal-overlay')) {
    e.target.style.display = 'none';
    e.target.classList.remove('active');
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay').forEach(m => {
      m.style.display = 'none';
      m.classList.remove('active');
    });
  }
});

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}
function setAttr(id, attr, val) {
  const el = document.getElementById(id);
  if (el) el.setAttribute(attr, val);
}

/* ════════════════════════════════════════════════════════════════
   🌐  3D ENGINE INTEGRATION BRIDGE
   ════════════════════════════════════════════════════════════════ */

/** Global flag: is the 3D mode currently active? */
let mode3DActive = false;

/** Called once DOM is ready — wires all 3D buttons */
document.addEventListener('DOMContentLoaded', () => {
  setup3DIntegration();
});

// Also try immediately in case DOMContentLoaded already fired
if (document.readyState !== 'loading') {
  setup3DIntegration();
}

function setup3DIntegration() {
  /* ── HUD global 3D toggle (🌐 3D button in header) ─────── */
  const hudBtn3D = document.getElementById('btn-toggle-3d-mode');
  if (hudBtn3D && !hudBtn3D._3dBound) {
    hudBtn3D._3dBound = true;
    hudBtn3D.addEventListener('click', () => {
      mode3DActive = !mode3DActive;
      hudBtn3D.classList.toggle('active', mode3DActive);
      hudBtn3D.textContent = mode3DActive ? '🌐 3D ✓' : '🌐 3D';

      if (mode3DActive) {
        showToast('✅ وضع ثلاثي الأبعاد مُفعَّل — ادخل مسرح الجريمة لتجربة الوضع الجديد!');
      } else {
        showToast('🔄 تم التبديل لوضع الصور الكلاسيكي.');
        // clean up 3D if active on crime scene
        if (typeof destroy3DScene === 'function') destroy3DScene();
        const c3d = document.getElementById('scene-3d-container');
        const c2d = document.getElementById('crime-scene-bg');
        if (c3d) c3d.style.display = 'none';
        if (c2d) c2d.style.display = 'block';
      }
    });
  }

  /* ── Crime scene 3D enter button ───────────────────────── */
  const enter3DBtn = document.getElementById('btn-enter-3d-scene');
  if (enter3DBtn && !enter3DBtn._3dBound) {
    enter3DBtn._3dBound = true;
    enter3DBtn.addEventListener('click', () => {
      launchCrimeScene3D();
    });
  }

  /* ── Sync existing torch button with 3D flashlight ─────── */
  const torchBtn = document.getElementById('btn-toggle-torch');
  if (torchBtn && !torchBtn._3dSynced) {
    torchBtn._3dSynced = true;
    const origClick = torchBtn.onclick;
    torchBtn.addEventListener('click', () => {
      // Keep existing 2D torch logic intact, then sync 3D
      if (mode3DActive && typeof toggle3DFlashlight === 'function') {
        const torchOverlay = document.getElementById('torch-vignette-overlay');
        const isOn = torchOverlay && torchOverlay.style.display !== 'none';
        toggle3DFlashlight(!isOn);
      }
    });
  }

  /* ── Close 360° inspector ───────────────────────────────── */
  const closeInspector3D = document.getElementById('btn-close-3d-inspector');
  if (closeInspector3D && !closeInspector3D._3dBound) {
    closeInspector3D._3dBound = true;
    closeInspector3D.addEventListener('click', () => {
      const modal = document.getElementById('modal-3d-evidence-inspector');
      if (modal) modal.style.display = 'none';
      if (typeof cleanup360Inspector === 'function') cleanup360Inspector();
    });
  }
}

/** Launch or refresh the 3D crime scene */
async function launchCrimeScene3D() {
  if (!state.currentCase) {
    showToast('⚠️ يجب تحميل قضية أولاً قبل دخول مسرح الجريمة 3D!');
    return;
  }

  const c3d = document.getElementById('scene-3d-container');
  const c2d = document.getElementById('crime-scene-bg');
  if (!c3d) return;

  // Destroy any previous 3D scene
  if (typeof destroy3DScene === 'function') destroy3DScene();

  // Switch to 3D view
  if (c2d) c2d.style.display = 'none';
  c3d.style.display = 'block';
  c3d.classList.add('enter-3d-transition');
  setTimeout(() => c3d.classList.remove('enter-3d-transition'), 700);

  // Inject controls hint bar (once)
  if (!c3d.querySelector('.controls-hint-3d')) {
    const hint = document.createElement('div');
    hint.className = 'controls-hint-3d';
    hint.innerHTML = `
      <span>🖱️ سحب: تدوير الكاميرا</span>
      <span>🔍 تكبير: عجلة الفأرة / قرص الإصبعين</span>
      <span>👆 نقر: تفاعل مع الأشياء</span>
      <span>🔦 كشاف: الزر الأصفر</span>
    `;
    c3d.parentNode.insertBefore(hint, c3d.nextSibling);
  }

  // Mark mode as active
  mode3DActive = true;
  const hudBtn = document.getElementById('btn-toggle-3d-mode');
  if (hudBtn) { hudBtn.classList.add('active'); hudBtn.textContent = '🌐 3D ✓'; }

  showToast('🌐 جاري تحميل مسرح الجريمة ثلاثي الأبعاد...');

  // Initialize Three.js scene — wait for engine to be available
  await waitFor3DEngine();
  if (typeof init3DCrimeScene === 'function') {
    await init3DCrimeScene('scene-3d-container', state.currentCase);
    if (typeof showScene3DNotification === 'function') {
      showScene3DNotification(`🕵️ مسرح الجريمة: ${state.currentCase.sceneLocation || 'موقع الحادث'} — ابحث عن الأدلة المخفية!`);
    }
  } else {
    showToast('⚠️ محرك 3D غير متاح بعد. حاول مرة أخرى.');
    if (c2d) c2d.style.display = 'block';
    c3d.style.display = 'none';
  }
}

/** Poll until the 3D engine exports are ready (loaded via ES module) */
function waitFor3DEngine(timeoutMs = 5000) {
  return new Promise((resolve) => {
    if (typeof init3DCrimeScene === 'function') { resolve(); return; }
    const start = Date.now();
    const poll = setInterval(() => {
      if (typeof init3DCrimeScene === 'function') {
        clearInterval(poll);
        resolve();
      } else if (Date.now() - start > timeoutMs) {
        clearInterval(poll);
        resolve(); // resolve anyway, caller handles missing function
      }
    }, 100);
  });
}

/**
 * Called by three_engine.js when a 3D hotspot evidence is collected.
 * Bridges 3D picks back into the 2D evidence system (notebook, badge, etc.)
 */
window.collectEvidenceFromScene3D = function (hotspotIndex, evidenceText) {
  if (!state.currentCase) return;

  const c = state.currentCase;
  const ev = {
    id: `3d_ev_${hotspotIndex}`,
    icon: ['🔑', '📄', '🔍'][hotspotIndex] || '🔍',
    title: evidenceText || c.evidence || 'دليل مادي مجمع',
    desc: c.solutionExplanation || 'دليل تم جمعه من مسرح الجريمة ثلاثي الأبعاد.',
    hotspot: hotspotIndex
  };

  // Avoid duplicates
  if (state.collectedEvidence.find(e => e.id === ev.id)) return;
  state.collectedEvidence.push(ev);

  // Update side evidence drawer badge
  const badge = document.getElementById('side-evidence-badge');
  if (badge) badge.textContent = state.collectedEvidence.length;

  // Update discovery counter in dashboard
  const discCount = document.getElementById('discovery-count');
  if (discCount) {
    discCount.textContent = `${state.collectedEvidence.length} / 3`;
  }

  // Add to notebook clues tab
  if (state.notebook) {
    state.notebook.clues = state.notebook.clues || [];
    state.notebook.clues.push({ title: ev.title, desc: ev.desc, time: new Date().toLocaleTimeString('ar') });
  }

  // Update notebook badge in HUD
  const nbBadge = document.getElementById('notebook-badge-count');
  if (nbBadge) {
    const total = (state.notebook.discrepancies || []).length +
      (state.notebook.clues || []).length;
    nbBadge.textContent = total;
    nbBadge.style.display = total > 0 ? 'inline-flex' : 'none';
  }

  // Rebuild side evidence drawer list
  rebuildEvidenceDrawer3D();

  // Audio feedback
  if (typeof AudioEngine !== 'undefined' && AudioEngine.playClueSFX) {
    AudioEngine.playClueSFX();
  }
};

/** Rebuilds the side evidence drawer to include 3D-collected items */
function rebuildEvidenceDrawer3D() {
  const list = document.getElementById('side-evidence-list');
  if (!list || !state.collectedEvidence.length) return;

  list.innerHTML = '';
  state.collectedEvidence.forEach((ev) => {
    const item = document.createElement('div');
    item.style.cssText = `
      display:flex; align-items:flex-start; gap:10px; padding:8px 10px;
      background:rgba(255,183,3,0.07); border-radius:10px;
      border:1px solid rgba(255,183,3,0.18); margin-bottom:6px;
    `;
    item.innerHTML = `
      <span style="font-size:1.4rem;flex-shrink:0;">${ev.icon}</span>
      <div style="flex:1;">
        <div style="font-size:0.82rem;font-weight:800;color:var(--gold);">${ev.title}</div>
        <div style="font-size:0.73rem;color:var(--muted);margin-top:2px;line-height:1.3;">${ev.desc}</div>
        ${ev.hotspot !== undefined ? `<div style="font-size:0.68rem;color:#a78bfa;margin-top:4px;">🌐 مجمع من مسرح الجريمة 3D</div>` : ''}
      </div>
    `;
    list.appendChild(item);
  });
}

/* ── Expose launchCrimeScene3D for external use ─────────────── */
window.launchCrimeScene3D = launchCrimeScene3D;

/* ═══════════════════════════════════════════════════════════
   🗺️ CHAPTERS & LEVEL SELECTOR (100 CASES GRID)
   ═══════════════════════════════════════════════════════════ */
function openChaptersModal() {
  renderChaptersGrid('all');
  showModal('chapters-modal');
  playClick();
}

function renderChaptersGrid(filter) {
  const container = document.getElementById('chapters-grid-container');
  if (!container) return;
  container.innerHTML = '';

  const totalLevels = (typeof LEVELS_DATA !== 'undefined' && LEVELS_DATA.length) ? LEVELS_DATA.length : 100;
  const currentUnlocked = Math.max(state.level || 1, (state.completed ? state.completed.size + 1 : 1));

  for (let i = 1; i <= totalLevels; i++) {
    const c = (typeof LEVELS_DATA !== 'undefined' && LEVELS_DATA[i - 1]) ? LEVELS_DATA[i - 1] : null;
    const title = c ? c.title : `القضية رقم #${i}`;
    const category = c ? (c.category || 'جنائي') : 'تحقيق';
    const isCompleted = state.completed && state.completed.has(i);
    const isUnlocked = i <= currentUnlocked;
    const isCurrent = i === state.level;

    // Filter check
    if (filter === 'unlocked' && !isUnlocked) continue;
    if (filter === 'completed' && !isCompleted) continue;
    if (filter === 'murder' && !category.includes('قتل')) continue;
    if (filter === 'theft' && !category.includes('سرق')) continue;
    if (filter === 'fraud' && !category.includes('احتيال') && !category.includes('مال')) continue;

    const card = document.createElement('div');
    card.className = `level-card ${isCurrent ? 'current' : ''} ${isCompleted ? 'completed' : ''} ${!isUnlocked ? 'locked' : ''}`;
    
    let badgeEmoji = '🔪';
    if (category.includes('سرق')) badgeEmoji = '💎';
    else if (category.includes('احتيال') || category.includes('مال')) badgeEmoji = '💼';
    else if (category.includes('تسمم')) badgeEmoji = '🧪';

    let starsHtml = isCompleted ? '⭐⭐⭐' : (isUnlocked ? '☆☆☆' : '🔒');

    card.innerHTML = `
      <div class="level-card-number">#${i}</div>
      <div class="level-card-title">${title}</div>
      <div class="level-card-stars">${starsHtml}</div>
      <div class="level-card-badge">${badgeEmoji} ${category}</div>
    `;

    if (isUnlocked) {
      card.addEventListener('click', () => {
        hideModal('chapters-modal');
        showGameInterstitial();
        loadLevel(i);
        showScreen('case-dashboard-screen');
        showToast(`📂 تم فتح القضية رقم #${i}: ${title}`);
        playWin();
      });
    } else {
      card.addEventListener('click', () => {
        showToast(`🔒 القضية رقم #${i} مقفلة! أكمل القضية #${i - 1} أولاً.`);
        playClick();
      });
    }

    container.appendChild(card);
  }
}

/* ═══════════════════════════════════════════════════════════
   🎖️ DETECTIVE RANKS & PROFILE SYSTEM
   ═══════════════════════════════════════════════════════════ */
const DETECTIVE_RANKS = [
  { minXP: 0, title: 'مساعد محقق متدرب', badge: '🥉', desc: 'محقق مبتدئ يتعلم أساسيات جمع الأدلة' },
  { minXP: 100, title: 'مفتش مباحث ميداني', badge: '🥈', desc: 'يمتلك مهارات استجواب دقيقة وقدرة على كشف الأكاذيب' },
  { minXP: 300, title: 'رئيس فريق التحقيقات', badge: '🥇', desc: 'خبير جنائي بارع في ربط الخيوط المعقدة وحل الجرائم' },
  { minXP: 700, title: 'كبير المحققين الجنائيين', badge: '💎', desc: 'أسطورة في فك الألغاز وكشف أخطر الشبكات الإجرامية' },
  { minXP: 1500, title: 'شارلوك هولمز العصر', badge: '👑', desc: 'المحقق الأعظم، لا توجد جريمة يستعصي حلها عليه' }
];

function getDetectiveRank(xp) {
  let rank = DETECTIVE_RANKS[0];
  for (let r of DETECTIVE_RANKS) {
    if (xp >= r.minXP) rank = r;
  }
  return rank;
}

function openRankProfileModal() {
  const xp = state.xp || 0;
  const rank = getDetectiveRank(xp);
  
  const rankBadgeEl = document.getElementById('modal-rank-badge');
  const rankNameEl = document.getElementById('modal-rank-name');
  const rankDescEl = document.getElementById('modal-rank-desc');
  const currentXpEl = document.getElementById('modal-rank-current-xp');
  const nextXpEl = document.getElementById('modal-rank-next-xp');
  const xpBarEl = document.getElementById('modal-rank-xp-bar');
  
  if (rankBadgeEl) rankBadgeEl.textContent = rank.badge;
  if (rankNameEl) rankNameEl.textContent = rank.title;
  if (rankDescEl) rankDescEl.textContent = rank.desc;
  if (currentXpEl) currentXpEl.textContent = `${xp} XP`;

  let nextRank = DETECTIVE_RANKS.find(r => r.minXP > xp);
  if (nextRank) {
    if (nextXpEl) nextXpEl.textContent = `الرتبة القادمة: ${nextRank.minXP} XP`;
    const pct = Math.min(100, Math.round(((xp - rank.minXP) / (nextRank.minXP - rank.minXP)) * 100));
    if (xpBarEl) xpBarEl.style.width = `${pct}%`;
  } else {
    if (nextXpEl) nextXpEl.textContent = `أعلى رتبة مكتملة 👑`;
    if (xpBarEl) xpBarEl.style.width = `100%`;
  }

  const solvedEl = document.getElementById('stat-solved-count');
  const coinsEl = document.getElementById('stat-total-coins');
  const cluesEl = document.getElementById('stat-clues-found');
  
  if (solvedEl) solvedEl.textContent = `${state.completed ? state.completed.size : 0} / 100`;
  if (coinsEl) coinsEl.textContent = `${state.coins || 0} 🪙`;
  if (cluesEl) cluesEl.textContent = `${(state.collectedEvidence || []).length}`;

  showModal('rank-profile-modal');
  playClick();
}

/* ═══════════════════════════════════════════════════════════
   💡 SMART HINT SYSTEM (ALL HINTS VIA REWARDED ADS)
   ═══════════════════════════════════════════════════════════ */
function useSmartHint() {
  useHint();
}

/* ═══════════════════════════════════════════════════════════
   🎵 REAL BACKGROUND MUSIC AUDIO CONTROLLER
   ═══════════════════════════════════════════════════════════ */
let bgmAudio = null;
let isMusicPlaying = false;

function initBGM() {
  if (!bgmAudio) {
    bgmAudio = document.getElementById('game-bgm');
    if (bgmAudio) {
      bgmAudio.volume = 0.5;
    }
  }
}

function playBGM() {
  initBGM();
  if (bgmAudio) {
    bgmAudio.play().then(() => {
      isMusicPlaying = true;
      updateBGMStatus();
    }).catch(e => {
      console.log('HTML5 play blocked or unsupported, starting ambient synth audio:', e);
      if (typeof AudioEngine !== 'undefined') {
        AudioEngine.startAmbientMusic();
        isMusicPlaying = true;
        updateBGMStatus();
      }
    });
  } else if (typeof AudioEngine !== 'undefined') {
    AudioEngine.startAmbientMusic();
    isMusicPlaying = true;
    updateBGMStatus();
  }
}

function toggleBGM() {
  initBGM();
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  if (isMusicPlaying || (bgmAudio && !bgmAudio.paused)) {
    if (bgmAudio) bgmAudio.pause();
    if (typeof AudioEngine !== 'undefined') AudioEngine.stopAmbientMusic();
    isMusicPlaying = false;
    updateBGMStatus();
    showToast(isEn ? '🔇 Ambient Soundtrack Muted' : '🔇 تم كتم الموسيقى التصويرية');
  } else {
    playBGM();
    isMusicPlaying = true;
    updateBGMStatus();
    showToast(isEn ? '🎵 Ambient Soundtrack Playing 🔊' : '🎵 تم تشغيل الموسيقى التصويرية 🔊');
  }
}

function updateBGMStatus() {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const statusEl = document.getElementById('bgm-status');
  if (statusEl) {
    statusEl.textContent = isMusicPlaying ? (isEn ? 'Music 🔊' : 'موسيقى 🔊') : (isEn ? 'Mute 🔇' : 'صامت 🔇');
  }
}

/* ═══════════════════════════════════════════════════════════
   🎬 CINEMATIC CASE INTRO SEQUENCE
   ═══════════════════════════════════════════════════════════ */
let typewriterTimer = null;

function runCaseIntroTypewriter(text) {
  const textEl = document.getElementById('intro-narrative-text');
  if (!textEl) return;
  if (typewriterTimer) clearInterval(typewriterTimer);

  textEl.textContent = '';
  let i = 0;
  typewriterTimer = setInterval(() => {
    if (i < text.length) {
      textEl.textContent += text.charAt(i);
      i++;
    } else {
      clearInterval(typewriterTimer);
      typewriterTimer = null;
    }
  }, 22);
}

function showCaseIntroScreen(caseData) {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const introId = document.getElementById('intro-case-id');
  const introName = document.getElementById('intro-case-name');
  const introLoc = document.getElementById('intro-location-name');
  const introLocLbl = document.getElementById('intro-location-label');
  const introVictim = document.getElementById('intro-victim-name');
  const introVictimLbl = document.getElementById('intro-victim-label');
  const introCrimeType = document.getElementById('intro-crime-type-badge');
  const introIq = document.getElementById('intro-iq-badge');
  
  if (introId) introId.textContent = String(caseData.level || state.level).padStart(3, '0');
  if (introName) introName.textContent = caseData.title || (isEn ? `Case #${caseData.level}` : `القضية رقم #${caseData.level}`);
  if (introLoc) introLoc.textContent = caseData.sceneLocation || (isEn ? 'Crime Scene Location' : 'موقع الحادث الجنائي');
  if (introLocLbl) introLocLbl.textContent = isEn ? 'Location:' : 'موقع الحادث:';
  if (introVictim) introVictim.textContent = caseData.victimName || (isEn ? 'The Victim' : 'المجني عليه');
  if (introVictimLbl) introVictimLbl.textContent = isEn ? 'Victim:' : 'الضحية:';

  if (introCrimeType) {
    introCrimeType.textContent = caseData.crimeType || (isEn ? '🔪 Homicide' : '🔪 جريمة قتل');
  }

  if (introIq) {
    const iq = caseData.iqLevel || 80;
    const iqMapAr = {
      80: { cls: 'iq-80', label: '🟢 IQ 80 — سهل' },
      100: { cls: 'iq-100', label: '🔵 IQ 100 — متوسط' },
      120: { cls: 'iq-120', label: '🟠 IQ 120 — صعب' },
      140: { cls: 'iq-140', label: '🔴 IQ 140 — خبير' },
      160: { cls: 'iq-160', label: '⚫ IQ 160 — أسطوري' }
    };
    const iqMapEn = {
      80: { cls: 'iq-80', label: '🟢 IQ 80 — Easy' },
      100: { cls: 'iq-100', label: '🔵 IQ 100 — Moderate' },
      120: { cls: 'iq-120', label: '🟠 IQ 120 — Hard' },
      140: { cls: 'iq-140', label: '🔴 IQ 140 — Mastermind' },
      160: { cls: 'iq-160', label: '⚫ IQ 160 — Legendary' }
    };
    const iqMap = isEn ? iqMapEn : iqMapAr;
    const info = iqMap[iq] || iqMap[80];
    introIq.className = `iq-badge ${info.cls}`;
    introIq.textContent = info.label;
  }

  const narrative = isEn
    ? `${caseData.description || 'Emergency incident dispatch incoming...'}\n\n🚨 Victim: ${caseData.victimName || 'The Victim'}.\nYou are the lead investigator on scene. Time is ticking—gather physical evidence, interrogate the prime suspects, and issue the arrest warrant!`
    : `${caseData.description || 'تفاصيل البلاغ الجنائي الوارد...'}\n\n🚨 الضحية: ${caseData.victimName || 'المجني عليه'}.\nأنت الآن المحقق المسؤول.. أمامك وقت محدد لجمع الأدلة واستجواب المشتبه بهم وتقديم لائحة الاتهام!`;
  
  runCaseIntroTypewriter(narrative);

  showScreen('case-intro-screen', 'forward');
  playBGM();
}

function proceedFromIntroToDashboard() {
  if (typewriterTimer) {
    clearInterval(typewriterTimer);
    typewriterTimer = null;
  }
  renderDashboard();
  showScreen('case-dashboard-screen', 'forward');
  startTimer();
  TutorialManager.checkLevelStart(state.level);
  playWin();
}
window.proceedFromIntroToDashboard = proceedFromIntroToDashboard;

window.startInvestigationDirect = function () {
  playBGM();
  playClick();
  showGameInterstitial();
  loadLevel(state.level || 1, true);
};

/* ─── AD REWARD CALLBACKS (called from Flutter via runJavaScript) ─── */
window.onAdRewardEarned = function (amount) {
  // Show the hint content immediately after ad is watched
  if (state.currentCase) {
    setTimeout(() => _showHintContent(), 400);
  }
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  showToast(isEn ? '📢 Reward granted! Displaying investigation hint...' : '📢 شكراً على مشاهدة الإعلان! جاري عرض التلميح...');
};

window.onAdRewardFailed = function (msg) {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  showToast(isEn ? `⚠️ ${msg || 'Sponsored dispatch unavailable right now. Try again shortly.'}` : `⚠️ ${msg || 'الإعلان غير متاح الآن، حاول لاحقاً.'}`);
};

function _showHintContent() {
  const c = state.currentCase;
  if (!c) return;
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const iq = c.iqLevel || 80;
  const totalTime = getLevelTimeSec(iq);
  const m = Math.floor(totalTime / 60);
  const s = totalTime % 60;
  const timeLabel = `${m}:${s.toString().padStart(2, '0')}`;

  const hintText = isEn
    ? `💡 Lead Detective Consultation\n` +
      `─────────────────\n` +
      `📍 Incident Scene: ${c.sceneLocation}\n` +
      `🔑 Decisive Physical Evidence: ${c.evidence}\n` +
      `⏱️ Investigation Allotted Time: ${timeLabel} mins\n\n` +
      `🧠 Pro Tip: Cross-reference witness statements against timestamps and surveillance logs!`
    : `💡 تلميح المحقق\n` +
      `─────────────────\n` +
      `📍 مكان الجريمة: ${c.sceneLocation}\n` +
      `🎯 الدافع المحتمل: ${c.motive ? c.motive.slice(0, 30) + '...' : 'غير محدد'}\n` +
      `🔑 الدليل القاطع: ${c.evidence}\n` +
      `⏱️ وقت المستوى: ${timeLabel} دقيقة`;

  setText('hint-text', hintText);
  showModal('hint-modal');
  playWin();
}

/* ═══════════════════════════════════════════════════════════
   🕵️ NOIR DETECTIVE MAIN MENU CONTROLLERS
   ═══════════════════════════════════════════════════════════ */

window.openNoirSettingsModal = function () {
  playClick();
  updateNoirSettingsUI();
  showModal('noir-settings-modal');
};

window.openNoirExitModal = function () {
  playClick();
  showModal('noir-exit-modal');
};

window.openNoirRateModal = function () {
  playClick();
  showModal('noir-rate-modal');
};

window.handleNoirShare = function () {
  playClick();
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const shareTitle = isEn ? 'UNKNOWN CULPRIT - Mystery Detective' : 'المخبر الذكي - الجاني مجهول';
  const shareText = isEn
    ? 'Can you solve 100 mysterious criminal cases and uncover the culprit? Play now!'
    : 'هل تستطيع حل 100 قضية جنائية غامضة وكشف الجاني الحقيقي؟ العب الآن!';
  const shareUrl = window.location.href;

  if (navigator.share) {
    navigator.share({ title: shareTitle, text: shareText, url: shareUrl }).catch(() => {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(`${shareTitle}\n${shareText}\n${shareUrl}`).then(() => {
      showToast(isEn ? '🔗 Share link copied to clipboard!' : '🔗 تم نسخ رابط اللعبة بنجاح!');
    }).catch(() => {
      showToast(isEn ? 'Share link ready!' : 'شارك اللعبة مع أصدقائك!');
    });
  } else {
    showToast(isEn ? 'Share with your fellow detectives!' : 'شارك اللعبة مع أصدقائك المحققين!');
  }
};

window.handleNoirMoreGames = function () {
  playClick();
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  showToast(isEn ? '🎮 More crime & detective games coming soon to the store!' : '🎮 ترقبوا المزيد من ألعاب التحقيق قريباً على المتجر!');
};

window.toggleNoirMusic = function () {
  const bgm = document.getElementById('game-bgm');
  const btn = document.getElementById('btn-noir-toggle-music');
  if (!bgm) return;
  if (bgm.paused) {
    bgm.play().catch(() => {});
    if (btn) btn.textContent = '🔊';
  } else {
    bgm.pause();
    if (btn) btn.textContent = '🔇';
  }
};

window.toggleNoirSFX = function () {
  playClick();
  const btn = document.getElementById('btn-noir-toggle-sfx');
  const isMuted = localStorage.getItem('unknown_culprit_sfx_muted') === 'true';
  const newMuted = !isMuted;
  localStorage.setItem('unknown_culprit_sfx_muted', newMuted ? 'true' : 'false');
  if (btn) btn.textContent = newMuted ? '🔇' : '🔊';
};

function updateNoirSettingsUI() {
  const bgm = document.getElementById('game-bgm');
  const btnMusic = document.getElementById('btn-noir-toggle-music');
  if (btnMusic && bgm) {
    btnMusic.textContent = bgm.paused ? '🔇' : '🔊';
  }
  const btnSfx = document.getElementById('btn-noir-toggle-sfx');
  const isMuted = localStorage.getItem('unknown_culprit_sfx_muted') === 'true';
  if (btnSfx) {
    btnSfx.textContent = isMuted ? '🔇' : '🔊';
  }
}

window.confirmResetProgress = function () {
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  const promptMsg = isEn
    ? 'Are you sure you want to reset all 100 cases progress and start from scratch?'
    : 'هل أنت متأكد تماماً من رغبتك في مسح كل القضايا والبدء من القضية الأولى؟';
  if (confirm(promptMsg)) {
    localStorage.removeItem('unknown_culprit_state');
    localStorage.removeItem('unknown_culprit_solved');
    localStorage.removeItem('unknown_culprit_xp');
    showToast(isEn ? '🔄 Progress reset successfully.' : '🔄 تم إعادة تعيين التقدم بنجاح.');
    setTimeout(() => location.reload(), 600);
  }
};

window.confirmExitGame = function () {
  hideModal('noir-exit-modal');
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  showToast(isEn ? '👋 Progress saved! See you on the next case.' : '👋 تم حفظ تقدمك بنجاح! إلى اللقاء في القضية القادمة.');
  if (window.navigator && window.navigator.app && window.navigator.app.exitApp) {
    window.navigator.app.exitApp();
  }
};

let currentRatingStars = 5;
window.setRatingStar = function (num) {
  playClick();
  currentRatingStars = num;
  const starsContainer = document.querySelector('.noir-stars-rating');
  if (starsContainer) {
    const stars = starsContainer.querySelectorAll('span');
    stars.forEach((star, idx) => {
      star.style.opacity = idx < num ? '1' : '0.35';
      star.style.transform = idx < num ? 'scale(1.15)' : 'scale(0.95)';
    });
  }
};

window.submitRating = function () {
  hideModal('noir-rate-modal');
  const isEn = typeof I18nManager !== 'undefined' && I18nManager.getLang() === 'en';
  showToast(isEn ? `⭐ Thank you for giving us ${currentRatingStars} stars!` : `⭐ شكراً جزيلاً لتقييمك بـ ${currentRatingStars} نجوم! رأيك يسعدنا.`);
};

// ════════════════════════════════════════════════════════════════
//  YouTube Playables SDK Integration (Required)
//  هذه الدوال يجب أن تكون موجودة لاعتماد اللعبة على Playables
// ════════════════════════════════════════════════════════════════

// التحقق إذا اللعبة شغالة داخل بيئة يوتيوب
window.IN_PLAYABLES_ENV = typeof ytgame !== 'undefined' && !!ytgame.game;

// إبلاغ يوتيوب أن الإطار الأول تم تحميله
if (typeof ytgame !== 'undefined' && ytgame.game) {
  try { ytgame.game.firstFrameReady(); } catch (e) { console.warn('firstFrameReady error', e); }
}

// حالة الصوت الحالية
function getCurrentAudioEnabled() {
  const bgm = document.getElementById('game-bgm');
  return bgm && !bgm.paused;
}

// دوال الصوت المطلوبة
window.ytgame_system_isAudioEnabled = function () {
  return getCurrentAudioEnabled();
};

window.ytgame_system_onAudioEnabledChange = function (callback) {
  const bgm = document.getElementById('game-bgm');
  if (!bgm) return;
  const handler = () => {
    try { callback(getCurrentAudioEnabled()); } catch (e) {}
  };
  bgm.addEventListener('play', handler);
  bgm.addEventListener('pause', handler);
};

// دالة الإيقاف المؤقت (Pause)
window.ytgame_system_onPause = function (callback) {
  const originalPause = window.confirmExitGame;
  window.confirmExitGame = function () {
    try { callback(); } catch (e) {}
    if (typeof originalPause === 'function') originalPause();
  };
};

// دالة الاستئناف (Resume)
window.ytgame_system_onResume = function (callback) {
  const originalReload = window.confirmResetProgress;
  window.confirmResetProgress = function () {
    try { callback(); } catch (e) {}
    if (typeof originalReload === 'function') originalReload();
  };
};

// تحميل وحفظ بيانات المستخدم (localStorage)
window.ytgame_game_loadData = function () {
  try {
    const state = localStorage.getItem('unknown_culprit_state');
    const solved = localStorage.getItem('unknown_culprit_solved');
    const xp = localStorage.getItem('unknown_culprit_xp');
    return JSON.stringify({ state, solved, xp });
  } catch (e) { return '{}'; }
};

window.ytgame_game_saveData = function (data) {
  try {
    const parsed = JSON.parse(data);
    if (parsed.state) localStorage.setItem('unknown_culprit_state', parsed.state);
    if (parsed.solved) localStorage.setItem('unknown_culprit_solved', parsed.solved);
    if (parsed.xp) localStorage.setItem('unknown_culprit_xp', parsed.xp);
  } catch (e) { console.warn('saveData error', e); }
};

// إبلاغ يوتيوب أن اللعبة جاهزة بعد التحميل
window.addEventListener('load', () => {
  setTimeout(() => {
    if (typeof ytgame !== 'undefined' && ytgame.game) {
      try { ytgame.game.gameReady(); } catch (e) { console.warn('gameReady error', e); }
    }
  }, 1000);
});
