const fs = require('fs');
const path = require('path');

const levelsPath = path.join(__dirname, 'levels.json');
const levelsDataPath = path.join(__dirname, 'levels_data.js');

let raw = fs.readFileSync(levelsPath, 'utf8');
if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
const levels = JSON.parse(raw);

// Known Arabic male names ending with 'ة' or 'ى' or 'اء'
const MALE_EXCEPTIONS = new Set([
  'مصطفى', 'يحيى', 'عيسى', 'موسى', 'مرتضى', 'رضا', 'علاء', 'بهاء', 'ضياء',
  'حمزة', 'أسامة', 'طلحة', 'عبيدة', 'قتادة', 'سلامة', 'جمعة', 'عكرمة', 'عطية'
]);

// Comprehensive list of female first names
const FEMALE_NAMES = new Set([
  'عبير', 'آية', 'نور', 'ريم', 'سارة', 'هناء', 'رانيا', 'ندى', 'لمى', 'إيمان',
  'دينا', 'هدى', 'منى', 'سمر', 'رشا', 'غادة', 'مريم', 'أميرة', 'ياسمين', 'روان',
  'لينا', 'هبة', 'شيرين', 'نيفين', 'فاطمة', 'زينب', 'أسماء', 'خديجة', 'عائشة',
  'حنان', 'سحر', 'ابتسام', 'إبتسام', 'وفاء', 'سهام', 'هالة', 'أمل', 'شيماء',
  'ناهد', 'فايزة', 'فريدة', 'إلهام', 'راندا', 'إنجي', 'ميرنا', 'شادية', 'نيللي',
  'نيلي', 'لوسي', 'دعاء', 'رحاب', 'أروى', 'ألاء', 'علا', 'ولاء', 'نجلاء',
  'سلمى', 'ليلى', 'نهى', 'ميار', 'ميس', 'رنا', 'تالا', 'جنى', 'لارا', 'لارة',
  'دلال', 'أفنان', 'رغد', 'ريف', 'ريهام', 'شهد', 'كوثر', 'بسمة', 'بسمه',
  'هيا', 'هيام', 'أهداف', 'نادية', 'نرمين', 'منال', 'مروة', 'مها', 'نادين',
  'كريمة', 'حليمة', 'حسناء', 'فاتن', 'فاتنة', 'صفاء', 'سناء', 'سمية', 'سميرة',
  'صباح', 'لبنى', 'لمار', 'رهف', 'لانا', 'تغريد', 'خلود', 'سلوى', 'مي', 'شهد'
]);

function isFemale(name) {
  if (!name) return false;
  const first = name.trim().split(/\s+/)[0];
  if (MALE_EXCEPTIONS.has(first)) return false;
  if (FEMALE_NAMES.has(first)) return true;
  if (first.endsWith('ة') || first.endsWith('اء')) return true;
  return false;
}

// Strictly segregated image pools
const FEMALE_POOLS = {
  maid: ['images/char_maid.png'],
  secretary_assistant: ['images/char_2f.png', 'images/char_7f.png'],
  expert_reception: ['images/char_11f.png', 'images/char_9f.png'],
  executive_insurance_tech: ['images/char_14f.png', 'images/char_9f.png', 'images/char_2f.png'],
  friend_partner: ['images/char_13f.png', 'images/char_7f.png', 'images/char_2f.png'],
  all_female: [
    'images/char_2f.png', 'images/char_7f.png', 'images/char_9f.png',
    'images/char_11f.png', 'images/char_13f.png', 'images/char_14f.png', 'images/char_maid.png'
  ]
};

const MALE_POOLS = {
  guard_security: ['images/char_guard.png', 'images/char_12.png', 'images/char_20.png', 'images/char_15.png'],
  driver: ['images/char_17.png', 'images/char_cleaner.png', 'images/char_6.png'],
  cleaner: ['images/char_cleaner.png', 'images/char_17.png', 'images/char_19.png'],
  chef: ['images/char_chef.png', 'images/char_cleaner.png'],
  accountant: ['images/char_accountant.png', 'images/char_5.png', 'images/char_1.png', 'images/char_19.png'],
  tech_developer: ['images/char_16.png', 'images/char_10.png', 'images/char_19.png', 'images/char_15.png'],
  doctor_forensic: ['images/char_18.png', 'images/char_19.png', 'images/char_5.png'],
  archive_records: ['images/char_19.png', 'images/char_18.png', 'images/char_10.png'],
  executive_deputy_partner: ['images/char_1.png', 'images/char_3.png', 'images/char_8.png', 'images/char_5.png'],
  merchant_client_wealthy: ['images/char_4.png', 'images/char_6.png', 'images/char_1.png', 'images/char_3.png'],
  competitor_shady_dismissed: ['images/char_20.png', 'images/char_8.png', 'images/char_15.png', 'images/char_4.png'],
  investigator_journalist: ['images/char_10.png', 'images/char_15.png', 'images/char_5.png'],
  all_male: [
    'images/char_1.png', 'images/char_3.png', 'images/char_4.png', 'images/char_5.png',
    'images/char_6.png', 'images/char_8.png', 'images/char_10.png', 'images/char_12.png',
    'images/char_15.png', 'images/char_16.png', 'images/char_17.png', 'images/char_18.png',
    'images/char_19.png', 'images/char_20.png', 'images/char_guard.png', 'images/char_accountant.png',
    'images/char_cleaner.png', 'images/char_chef.png'
  ]
};

function getCandidates(role, isFem) {
  const r = (role || '').toLowerCase();

  if (isFem) {
    if (r.includes('خادمة') || r.includes('مدبرة')) return FEMALE_POOLS.maid;
    if (r.includes('سكرتير') || r.includes('مساعد') || r.includes('مديرة مكتب')) return FEMALE_POOLS.secretary_assistant;
    if (r.includes('آثار') || r.includes('سياحة') || r.includes('استقبال')) return FEMALE_POOLS.expert_reception;
    if (r.includes('أمن') || r.includes('مشتريات') || r.includes('تأمين') || r.includes('تقني')) return FEMALE_POOLS.executive_insurance_tech;
    if (r.includes('صديقة') || r.includes('شريكة')) return FEMALE_POOLS.friend_partner;
    return FEMALE_POOLS.all_female;
  } else {
    if (r.includes('حارس') || r.includes('أمن') || r.includes('حراسة')) return MALE_POOLS.guard_security;
    if (r.includes('سائق')) return MALE_POOLS.driver;
    if (r.includes('نظافة') || r.includes('فراش') || r.includes('بواب')) return MALE_POOLS.cleaner;
    if (r.includes('طباخ') || r.includes('شيف')) return MALE_POOLS.chef;
    if (r.includes('محاسب') || r.includes('مالي') || r.includes('حسابات') || r.includes('خزينة')) return MALE_POOLS.accountant;
    if (r.includes('كمبيوتر') || r.includes('تقني') || r.includes('معلومات') || r.includes('مطوّر') || r.includes('مبرمج') || r.includes('هاكر')) return MALE_POOLS.tech_developer;
    if (r.includes('طبيب') || r.includes('دكتور') || r.includes('صيدل') || r.includes('شرعي')) return MALE_POOLS.doctor_forensic;
    if (r.includes('أرشيف') || r.includes('مكتبة') || r.includes('سجلات')) return MALE_POOLS.archive_records;
    if (r.includes('صحفي') || r.includes('محقق')) return MALE_POOLS.investigator_journalist;
    if (r.includes('عميل') || r.includes('مجوهرات') || r.includes('موزع')) return MALE_POOLS.merchant_client_wealthy;
    if (r.includes('منافس') || r.includes('مشبوه') || r.includes('مفصول') || r.includes('قاتل')) return MALE_POOLS.competitor_shady_dismissed;
    if (r.includes('نائب') || r.includes('شريك') || r.includes('مدير') || r.includes('رئيس')) return MALE_POOLS.executive_deputy_partner;
    return MALE_POOLS.all_male;
  }
}

levels.forEach(lvl => {
  const levelNum = lvl.level || lvl.Level;
  if (!lvl.suspects || !Array.isArray(lvl.suspects)) return;

  const usedInCase = new Set();

  lvl.suspects.forEach((suspect, idx) => {
    const fem = isFemale(suspect.name);
    const primaryCandidates = getCandidates(suspect.role, fem);
    const generalPool = fem ? FEMALE_POOLS.all_female : MALE_POOLS.all_male;

    let selected = null;
    const shift = (levelNum * 3 + idx) % primaryCandidates.length;

    // 1. Try primary candidates
    for (let i = 0; i < primaryCandidates.length; i++) {
      const img = primaryCandidates[(shift + i) % primaryCandidates.length];
      if (!usedInCase.has(img)) {
        selected = img;
        break;
      }
    }

    // 2. Fallback to same-gender general pool if needed
    if (!selected) {
      const generalShift = (levelNum + idx) % generalPool.length;
      for (let i = 0; i < generalPool.length; i++) {
        const img = generalPool[(generalShift + i) % generalPool.length];
        if (!usedInCase.has(img)) {
          selected = img;
          break;
        }
      }
    }

    if (!selected) {
      selected = primaryCandidates[0];
    }

    usedInCase.add(selected);
    suspect.image = selected;
  });
});

const jsonOutput = JSON.stringify(levels, null, 2);
fs.writeFileSync(levelsPath, jsonOutput, 'utf8');
fs.writeFileSync(levelsDataPath, `window.PRELOADED_LEVELS = ${jsonOutput};`, 'utf8');

console.log('Successfully applied 100% strict gender-accurate and diverse realistic character distribution!');
