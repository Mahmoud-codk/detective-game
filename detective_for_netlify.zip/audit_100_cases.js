const fs = require('fs');
const path = require('path');

const rootDir = __dirname;
const levelsPath = path.join(rootDir, 'levels.json');
const levelsDataPath = path.join(rootDir, 'levels_data.js');

let raw = fs.readFileSync(levelsPath, 'utf8');
if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
const levels = JSON.parse(raw);

console.log(`========================================`);
console.log(`🕵️‍♂️ فحص ومراجعة شاملة لجميع الـ 100 قضية`);
console.log(`========================================\n`);

let errors = [];
let warnings = [];

// 1. Check total level count
if (levels.length !== 100) {
  errors.push(`عدد القضايا غير متطابق: مطلوب 100 ووجد ${levels.length}`);
} else {
  console.log(`✔ عدد القضايا: 100 قضية بالتمام والكمال.`);
}

const seenLevels = new Set();

levels.forEach((lvl, idx) => {
  const levelNum = lvl.level || lvl.Level;
  const caseId = `القضية ${levelNum || (idx + 1)}`;

  // 2. Check Level Index Sequence
  if (!levelNum) {
    errors.push(`[${caseId}] حقل رقم المستوى (level) مفقود.`);
  } else if (levelNum !== idx + 1) {
    errors.push(`[${caseId}] تسلسل المستوى غير مرتب: متوقع ${idx + 1} ووجد ${levelNum}`);
  }
  seenLevels.add(levelNum);

  // 3. Required Fields
  const requiredFields = ['title', 'crimeType', 'victimName', 'sceneLocation', 'description', 'culpritName', 'culpritRole', 'evidence', 'solutionExplanation', 'suspects'];
  requiredFields.forEach(f => {
    if (!lvl[f] || (typeof lvl[f] === 'string' && lvl[f].trim() === '')) {
      errors.push(`[${caseId}] حقل مفقود أو فارغ: '${f}'`);
    }
  });

  // 4. Suspects Array Check
  if (!Array.isArray(lvl.suspects)) {
    errors.push(`[${caseId}] قائمة المشتبه بهم ليست مصفوفة صالحة.`);
    return;
  }

  if (lvl.suspects.length !== 3) {
    errors.push(`[${caseId}] عدد المشتبه بهم يجب أن يكون 3، ووجد ${lvl.suspects.length}`);
  }

  // 5. Culprit Match in Suspects
  let culpritFound = false;
  const suspectNames = [];

  lvl.suspects.forEach((s, sIdx) => {
    if (!s.name || s.name.trim() === '') {
      errors.push(`[${caseId}] المشتبه به رقم ${sIdx + 1} اسمه فارغ!`);
    } else {
      suspectNames.push(s.name.trim());
      if (s.name.trim() === (lvl.culpritName || '').trim()) {
        culpritFound = true;
      }
    }

    if (!s.role || s.role.trim() === '') {
      errors.push(`[${caseId}] المشتبه به '${s.name}' وظيفته فارغة!`);
    }

    if (!s.statement || s.statement.trim() === '') {
      errors.push(`[${caseId}] المشتبه به '${s.name}' إفادته فارغة!`);
    }

    // 6. Image existence check
    if (!s.image) {
      errors.push(`[${caseId}] المشتبه به '${s.name}' ليس لديه مسار صورة!`);
    } else {
      const imgDiskPath = path.join(rootDir, s.image);
      if (!fs.existsSync(imgDiskPath)) {
        errors.push(`[${caseId}] صورة المشتبه به '${s.name}' غير موجودة على القرص: ${s.image}`);
      }
    }
  });

  if (!culpritFound) {
    errors.push(`[${caseId}] الجاني الحقيقي '${lvl.culpritName}' غير موجود ضمن قائمة المشتبهين (${suspectNames.join('، ')})!`);
  }
});

// 7. Check levels_data.js synchronization
try {
  const dataJsContent = fs.readFileSync(levelsDataPath, 'utf8');
  if (!dataJsContent.startsWith('window.PRELOADED_LEVELS =')) {
    warnings.push(`ملف levels_data.js لا يبدأ بالصيغة القياسية window.PRELOADED_LEVELS`);
  }
} catch (e) {
  errors.push(`خطأ في قراءة ملف levels_data.js: ${e.message}`);
}

console.log('\n--- نتائج الفحص ---');
if (errors.length === 0) {
  console.log('✅ ممتاز! لا توجد أي أخطاء على الإطلاق في جميع الـ 100 قضية.');
  console.log('✔ جميع القضايا (1-100) متسلسلة وصحيحة بنسبة 100%.');
  console.log('✔ جميع المشتبهين (300 مشتبه به) يملكون أسماء ووظائف وأقوال وصوراً موجودة فعلياً.');
  console.log('✔ جميع الجناة الحقيقيين متطابقون تماماً مع قوائم المشتبهين.');
} else {
  console.log(`❌ تم العثور على ${errors.length} خطأ:`);
  errors.forEach((err, i) => console.log(`${i + 1}. ${err}`));
}

if (warnings.length > 0) {
  console.log(`\n⚠️ تنبيهات (${warnings.length}):`);
  warnings.forEach((w, i) => console.log(`${i + 1}. ${w}`));
}
