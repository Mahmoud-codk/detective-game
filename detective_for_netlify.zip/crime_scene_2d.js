/* ═══════════════════════════════════════════════════════════════════
   🔦  CRIME SCENE 2D ENGINE  — HTML5 Canvas + Dynamic Flashlight
   ═══════════════════════════════════════════════════════════════════
   Features:
   • Dynamic 2D flashlight (follows touch/mouse) with soft edge bloom
   • UV mode (purple tint + hidden clues revealed)
   • Fingerprint powder mode (blue glow particles)
   • Parallax depth (3 layers: bg / mid / fg)
   • Animated evidence hotspots (pulsing ring + rotation)
   • Particle system (dust in light cone, fingerprint sparkles)
   • Smooth ambient lighting transitions
   • Integrates with existing game.js: collectEvidence() + showToast()
   ═══════════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ──────────────────────────────────────────────────────────────
     CONFIG
  ────────────────────────────────────────────────────────────── */
  const CFG = {
    ambientLight: 0.07,         // 0 = pitch black, 1 = full bright
    torchRadius: 160,           // px at 1× scale
    torchSoftness: 0.55,        // 0 = hard edge, 1 = very soft
    torchColor: 'rgba(255,230,150,',
    uvColor: 'rgba(168,85,247,',
    uvRadius: 200,
    dustParticles: 28,
    parallaxStrength: 0.03,     // max layer shift as fraction of w
    sceneImages: [
      'bg_crime_scene.png',
      'crime_scene_bedroom.png',
      'crime_scene_kitchen.png',
      'crime_scene_office.png',
    ],
  };

  /* ──────────────────────────────────────────────────────────────
     STATE
  ────────────────────────────────────────────────────────────── */
  const S = {
    torch: true,      // flashlight active
    uv: false,        // UV mode
    powder: false,    // fingerprint powder mode
    mx: 0.5, my: 0.5, // mouse/touch position (0–1)
    tmx: 0.5, tmy: 0.5, // target (for smooth lerp)
    ambientT: 0,      // 0–1 smooth ambient transition
    frame: 0,
    tick: 0,
    bgImg: null,
    bgLoaded: false,
    hotspots: [],     // { x,y (0-1), label, icon, id, found, ring }
    particles: [],
    uvClues: [],      // hidden UV clues
    powderPrints: [], // fingerprint locations
    canvas: null,
    ctx: null,
    W: 0, H: 0,
    rafId: null,
    evidenceKey: '',
    collectPopupActive: false,
    activeHotspot: null,
  };

  /* ──────────────────────────────────────────────────────────────
     INIT
  ────────────────────────────────────────────────────────────── */
  function init() {
    S.canvas = document.getElementById('crime-scene-canvas');
    if (!S.canvas) return;
    S.ctx = S.canvas.getContext('2d');

    resize();
    window.addEventListener('resize', resize);
    bindEvents();
    spawnParticles();
    loop();
  }

  function resize() {
    const wrap = document.getElementById('crime-canvas-wrap');
    if (!wrap) return;
    S.W = wrap.offsetWidth || window.innerWidth;
    S.H = wrap.offsetHeight || Math.floor(window.innerHeight * 0.55);
    S.canvas.width = S.W;
    S.canvas.height = S.H;
  }

  /* ──────────────────────────────────────────────────────────────
     LOAD SCENE (called from game.js goToCrimeScene)
  ────────────────────────────────────────────────────────────── */
  window.CrimeScene2D = {
    loadScene(levelNum, evidenceTitle, sceneType) {
      S.evidenceKey = evidenceTitle || '';
      S.hotspots = [];
      S.uvClues = [];
      S.powderPrints = [];
      S.collectPopupActive = false;
      S.activeHotspot = null;
      hidePopup();

      // Pick background by level
      const imgs = CFG.sceneImages;
      const src = imgs[(levelNum || 1) % imgs.length];
      loadBg(src, levelNum, evidenceTitle);
    },
    setTorch(on) { S.torch = on; updateToolIndicator(); },
    setUV(on) { S.uv = on; if (on) { S.torch = false; S.powder = false; } updateToolIndicator(); },
    setPowder(on) { S.powder = on; if (on) { S.torch = false; S.uv = false; } updateToolIndicator(); },
  };

  function loadBg(src, levelNum, evidenceTitle) {
    S.bgLoaded = false;
    S.bgImg = new Image();
    S.bgImg.onload = () => {
      S.bgLoaded = true;
      placeHotspots(levelNum, evidenceTitle);
      placeUVClues(levelNum);
      placePowderPrints(levelNum);
    };
    S.bgImg.onerror = () => {
      // fallback: draw noir gradient
      S.bgLoaded = true;
      S.bgImg = null;
      placeHotspots(levelNum, evidenceTitle);
    };
    S.bgImg.src = src;
  }

  /* ──────────────────────────────────────────────────────────────
     HOTSPOT PLACEMENT (dynamic by level)
  ────────────────────────────────────────────────────────────── */
  function placeHotspots(levelNum, evidenceTitle) {
    // Primary evidence hotspot — position varies by level
    const positions = [
      { x: 0.62, y: 0.45 }, { x: 0.35, y: 0.55 },
      { x: 0.72, y: 0.60 }, { x: 0.25, y: 0.40 },
      { x: 0.50, y: 0.50 }, { x: 0.80, y: 0.35 },
      { x: 0.40, y: 0.65 }, { x: 0.65, y: 0.30 },
    ];
    const pos = positions[(levelNum || 1) % positions.length];

    S.hotspots = [
      {
        x: pos.x, y: pos.y,
        label: evidenceTitle || 'دليل رئيسي',
        icon: getEvidenceIcon2D(evidenceTitle),
        id: 'primary',
        found: false,
        ring: 0,
        isPrimary: true,
      },
    ];

    // Decoy hotspots (distractor items)
    const decoys = [
      { x: 0.20, y: 0.70, label: 'كوب قهوة', icon: '☕', id: 'd1' },
      { x: 0.85, y: 0.55, label: 'إطار صورة', icon: '🖼️', id: 'd2' },
      { x: 0.48, y: 0.78, label: 'ورقة ملاحظات', icon: '📄', id: 'd3' },
    ].filter((_, i) => (i + levelNum) % 3 !== 0); // vary by level

    decoys.forEach(d => S.hotspots.push({ ...d, found: false, ring: 0, isPrimary: false }));
  }

  function placeUVClues(levelNum) {
    S.uvClues = [
      { x: 0.30, y: 0.60, text: '🩸 آثار دماء مخفية' },
      { x: 0.70, y: 0.40, text: '✍️ كتابة مخفية بالحبر الفوسفوري' },
      { x: 0.55, y: 0.72, text: '👣 آثار أقدام' },
    ].filter((_, i) => (i + levelNum) % 2 === 0);
  }

  function placePowderPrints(levelNum) {
    S.powderPrints = [
      { x: 0.40, y: 0.50, label: 'بصمة إبهام يسار' },
      { x: 0.65, y: 0.55, label: 'بصمة إصبع سبابة' },
    ].filter((_, i) => (i + levelNum) % 2 !== 1);
  }

  function getEvidenceIcon2D(title) {
    if (!title) return '🔍';
    const t = title;
    if (t.includes('سكين') || t.includes('خنجر') || t.includes('مطواة')) return '🔪';
    if (t.includes('مسدس') || t.includes('رصاصة') || t.includes('سلاح')) return '🔫';
    if (t.includes('كاميرا') || t.includes('تسجيل') || t.includes('فيديو')) return '📹';
    if (t.includes('رسالة') || t.includes('ورقة') || t.includes('مستند') || t.includes('وثيقة')) return '📄';
    if (t.includes('هاتف') || t.includes('جوال') || t.includes('موبايل')) return '📱';
    if (t.includes('بصمة') || t.includes('DNA')) return '🧬';
    if (t.includes('سم') || t.includes('عقار') || t.includes('دواء')) return '🧪';
    if (t.includes('مفتاح')) return '🔑';
    if (t.includes('دم') || t.includes('بقعة')) return '🩸';
    if (t.includes('laptop') || t.includes('كمبيوتر') || t.includes('جهاز')) return '💻';
    if (t.includes('watch') || t.includes('ساعة')) return '⌚';
    return '🔍';
  }

  /* ──────────────────────────────────────────────────────────────
     PARTICLE SYSTEM
  ────────────────────────────────────────────────────────────── */
  function spawnParticles() {
    S.particles = [];
    for (let i = 0; i < CFG.dustParticles; i++) {
      S.particles.push(newParticle(true));
    }
  }

  function newParticle(randomStart) {
    return {
      x: Math.random(),
      y: randomStart ? Math.random() : 1.05,
      vx: (Math.random() - 0.5) * 0.0003,
      vy: -(Math.random() * 0.0006 + 0.0001),
      life: randomStart ? Math.random() : 0,
      maxLife: 0.6 + Math.random() * 0.4,
      size: 1 + Math.random() * 2,
      drift: (Math.random() - 0.5) * 0.0004,
    };
  }

  /* ──────────────────────────────────────────────────────────────
     EVENTS
  ────────────────────────────────────────────────────────────── */
  function bindEvents() {
    const c = S.canvas;

    function pointerPos(e) {
      const rect = c.getBoundingClientRect();
      const src = e.touches ? e.touches[0] : e;
      return {
        x: (src.clientX - rect.left) / rect.width,
        y: (src.clientY - rect.top) / rect.height,
      };
    }

    function onMove(e) {
      e.preventDefault();
      const p = pointerPos(e);
      S.tmx = p.x; S.tmy = p.y;
    }

    function onTap(e) {
      e.preventDefault();
      const p = pointerPos(e);
      S.tmx = p.x; S.tmy = p.y;
      checkHotspotTap(p.x, p.y);
    }

    c.addEventListener('mousemove', onMove, { passive: false });
    c.addEventListener('touchmove', onMove, { passive: false });
    c.addEventListener('click', onTap);
    c.addEventListener('touchend', onTap, { passive: false });

    // Torch toggle button
    document.getElementById('btn-toggle-torch')?.addEventListener('click', () => {
      if (!S.torch) { S.torch = true; S.uv = false; S.powder = false; }
      else { S.torch = false; }
      updateToolIndicator();
      updateBtnStates();
    });
    document.getElementById('btn-toggle-uv')?.addEventListener('click', () => {
      S.uv = !S.uv; if (S.uv) { S.torch = false; S.powder = false; }
      updateToolIndicator(); updateBtnStates();
    });
    document.getElementById('btn-toggle-powder')?.addEventListener('click', () => {
      S.powder = !S.powder; if (S.powder) { S.torch = false; S.uv = false; }
      updateToolIndicator(); updateBtnStates();
    });

    // Collect button
    document.getElementById('btn-collect-evidence')?.addEventListener('click', (e) => {
      e.stopPropagation();
      if (S.activeHotspot && S.activeHotspot.isPrimary) {
        S.activeHotspot.found = true;
        hidePopup();
        if (typeof collectEvidence === 'function') collectEvidence();
        if (typeof showToast === 'function') showToast(`✅ تم جمع: ${S.activeHotspot.label}`);
        if (typeof playWin === 'function') playWin();
        S.activeHotspot = null;
        // Spawn collect burst particles
        spawnBurst(S.mx, S.my, 20);
      }
    });
  }

  function checkHotspotTap(nx, ny) {
    for (const h of S.hotspots) {
      if (h.found) continue;
      const dx = (nx - h.x) * S.W;
      const dy = (ny - h.y) * S.H;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const hitRadius = 44;
      if (dist < hitRadius) {
        if (h.isPrimary) {
          // Show collect popup
          S.activeHotspot = h;
          showCollectPopup(h);
        } else {
          // Decoy — show flavour toast
          if (typeof showToast === 'function') showToast(`🔎 ${h.icon} ${h.label}: لا صلة واضحة بالجريمة.`);
          spawnBurst(nx, ny, 8);
        }
        break;
      }
    }
  }

  function showCollectPopup(h) {
    const popup = document.getElementById('evidence-collect-popup');
    if (!popup) return;
    document.getElementById('evidence-popup-icon').textContent = h.icon;
    document.getElementById('evidence-popup-title').textContent = h.label;
    popup.style.display = 'block';
    S.collectPopupActive = true;
  }

  function hidePopup() {
    const popup = document.getElementById('evidence-collect-popup');
    if (popup) popup.style.display = 'none';
    S.collectPopupActive = false;
  }

  function spawnBurst(nx, ny, count) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 0.002 + Math.random() * 0.004;
      S.particles.push({
        x: nx, y: ny,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 0.002,
        life: 0,
        maxLife: 0.3 + Math.random() * 0.3,
        size: 2 + Math.random() * 3,
        drift: 0,
        burst: true,
        color: `hsl(${40 + Math.random() * 30},100%,70%)`,
      });
    }
  }

  function updateToolIndicator() {
    const el = document.getElementById('active-tool-indicator');
    if (!el) return;
    if (S.torch) { el.style.display = 'block'; el.textContent = '🔦 كشاف فعّال'; el.style.borderColor = 'var(--gold)'; el.style.color = 'var(--gold)'; }
    else if (S.uv) { el.style.display = 'block'; el.textContent = '🟣 UV فعّال'; el.style.borderColor = '#A855F7'; el.style.color = '#A855F7'; }
    else if (S.powder) { el.style.display = 'block'; el.textContent = '🧤 بودرة البصمات'; el.style.borderColor = 'var(--cyan)'; el.style.color = 'var(--cyan)'; }
    else { el.style.display = 'none'; }
  }

  function updateBtnStates() {
    const bt = document.getElementById('btn-toggle-torch');
    const buv = document.getElementById('btn-toggle-uv');
    const bp = document.getElementById('btn-toggle-powder');
    if (bt) bt.style.background = S.torch ? 'rgba(255,183,3,0.4)' : 'rgba(255,183,3,0.15)';
    if (buv) buv.style.background = S.uv ? 'rgba(168,85,247,0.4)' : 'rgba(168,85,247,0.15)';
    if (bp) bp.style.background = S.powder ? 'rgba(0,242,254,0.35)' : 'rgba(0,242,254,0.12)';
  }

  /* ──────────────────────────────────────────────────────────────
     MAIN RENDER LOOP
  ────────────────────────────────────────────────────────────── */
  function loop() {
    S.tick++;
    S.frame++;

    // Smooth mouse lerp
    S.mx += (S.tmx - S.mx) * 0.12;
    S.my += (S.tmy - S.my) * 0.12;

    // Ambient transition
    const targetAmbient = (S.torch || S.uv || S.powder) ? CFG.ambientLight : 0.35;
    S.ambientT += (targetAmbient - S.ambientT) * 0.05;

    draw();
    S.rafId = requestAnimationFrame(loop);
  }

  /* ──────────────────────────────────────────────────────────────
     DRAW
  ────────────────────────────────────────────────────────────── */
  function draw() {
    const { ctx, W, H, mx, my, tick } = S;
    ctx.clearRect(0, 0, W, H);

    // ── 1. Draw background with parallax ──
    drawBackground(ctx, W, H, mx, my, tick);

    // ── 2. Dark ambient layer ──
    ctx.fillStyle = `rgba(0,0,0,${1 - S.ambientT})`;
    ctx.fillRect(0, 0, W, H);

    // ── 3. Tool light cone ──
    if (S.torch) drawTorch(ctx, W, H, mx, my, tick);
    if (S.uv) drawUV(ctx, W, H, mx, my, tick);
    if (S.powder) drawPowder(ctx, W, H, mx, my, tick);

    // ── 4. Dust particles (visible in torch beam) ──
    drawParticles(ctx, W, H, mx, my);

    // ── 5. Hotspots ──
    drawHotspots(ctx, W, H, tick);

    // ── 6. UV clues overlay ──
    if (S.uv) drawUVClues(ctx, W, H, mx, my, tick);

    // ── 7. Powder fingerprints ──
    if (S.powder) drawPowderPrints(ctx, W, H, mx, my, tick);

    // ── 8. Noir film grain ──
    drawFilmGrain(ctx, W, H, tick);

    // ── 9. Vignette border ──
    drawVignette(ctx, W, H);
  }

  /* ── Background with Parallax ── */
  function drawBackground(ctx, W, H, mx, my, tick) {
    const px = (mx - 0.5) * W * CFG.parallaxStrength;
    const py = (my - 0.5) * H * CFG.parallaxStrength;

    if (S.bgLoaded && S.bgImg) {
      // Layer 0: far background (least parallax)
      ctx.save();
      ctx.translate(-px * 0.3, -py * 0.3);
      const scale = 1.08;
      const sw = W * scale;
      const sh = H * scale;
      const sx = -(sw - W) / 2;
      const sy = -(sh - H) / 2;
      ctx.drawImage(S.bgImg, sx, sy, sw, sh);
      ctx.restore();
    } else {
      // Fallback noir gradient background
      const grd = ctx.createLinearGradient(0, 0, 0, H);
      grd.addColorStop(0, '#0a0a14');
      grd.addColorStop(0.5, '#111825');
      grd.addColorStop(1, '#07080a');
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, W, H);

      // Draw noir office elements procedurally
      drawNoirOffice(ctx, W, H, tick);
    }
  }

  /* Procedural noir office (when no bg image) */
  function drawNoirOffice(ctx, W, H, tick) {
    // Desk
    ctx.fillStyle = '#2a1f0e';
    ctx.fillRect(W * 0.1, H * 0.6, W * 0.8, H * 0.05);

    // Lamp light cone
    const lx = W * 0.75, ly = H * 0.1;
    const coneGrd = ctx.createRadialGradient(lx, ly, 10, lx, ly, H * 0.5);
    coneGrd.addColorStop(0, 'rgba(255,220,100,0.18)');
    coneGrd.addColorStop(1, 'rgba(255,200,60,0)');
    ctx.fillStyle = coneGrd;
    ctx.beginPath();
    ctx.moveTo(lx - 8, ly);
    ctx.lineTo(W * 0.95, H * 0.7);
    ctx.lineTo(W * 0.5, H * 0.7);
    ctx.closePath();
    ctx.fill();

    // Lamp body
    ctx.fillStyle = '#888';
    ctx.fillRect(lx - 4, ly - 20, 8, 22);
    ctx.fillStyle = '#FFD070';
    ctx.beginPath();
    ctx.ellipse(lx, ly, 22, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Papers on desk (subtle)
    ctx.fillStyle = 'rgba(220,210,180,0.08)';
    ctx.fillRect(W * 0.3, H * 0.55, W * 0.2, H * 0.06);
    ctx.fillRect(W * 0.55, H * 0.53, W * 0.18, H * 0.07);

    // Periodic flicker
    if (tick % 180 < 4) {
      ctx.fillStyle = 'rgba(255,200,80,0.06)';
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* ── Torch (Flashlight) ── */
  function drawTorch(ctx, W, H, mx, my, tick) {
    const tx = mx * W, ty = my * H;
    const r = CFG.torchRadius * (W / 375); // scale with screen
    const softness = CFG.torchSoftness;

    // Cut out: composite mode "destination-out" then redraw doesn't work well in single layer
    // Instead: subtract darkness with radial gradient
    const grd = ctx.createRadialGradient(tx, ty, 0, tx, ty, r);
    grd.addColorStop(0, CFG.torchColor + '0.92)');
    grd.addColorStop(softness, CFG.torchColor + '0.55)');
    grd.addColorStop(1, CFG.torchColor + '0)');

    // Use destination-out to create actual "hole" in dark layer
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(tx, ty, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Add warm torch colour tint (overlay)
    ctx.save();
    ctx.globalCompositeOperation = 'source-atop';
    const warmGrd = ctx.createRadialGradient(tx, ty, 0, tx, ty, r * 0.6);
    warmGrd.addColorStop(0, 'rgba(255,210,100,0.18)');
    warmGrd.addColorStop(1, 'rgba(255,180,60,0)');
    ctx.fillStyle = warmGrd;
    ctx.beginPath();
    ctx.arc(tx, ty, r * 0.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Bloom corona
    const bloom = ctx.createRadialGradient(tx, ty, r * 0.7, tx, ty, r * 1.1);
    bloom.addColorStop(0, 'rgba(255,200,80,0.08)');
    bloom.addColorStop(1, 'rgba(255,180,40,0)');
    ctx.fillStyle = bloom;
    ctx.beginPath();
    ctx.arc(tx, ty, r * 1.1, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ── UV Light ── */
  function drawUV(ctx, W, H, mx, my, tick) {
    const tx = mx * W, ty = my * H;
    const r = CFG.uvRadius * (W / 375);

    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    const grd = ctx.createRadialGradient(tx, ty, 0, tx, ty, r);
    grd.addColorStop(0, 'rgba(200,100,255,0.85)');
    grd.addColorStop(0.6, 'rgba(150,50,220,0.5)');
    grd.addColorStop(1, 'rgba(100,0,180,0)');
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(tx, ty, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // UV purple tint overlay
    const uvTint = ctx.createRadialGradient(tx, ty, 0, tx, ty, r);
    uvTint.addColorStop(0, 'rgba(180,80,255,0.22)');
    uvTint.addColorStop(0.5, 'rgba(140,40,220,0.10)');
    uvTint.addColorStop(1, 'rgba(100,0,180,0)');
    ctx.fillStyle = uvTint;
    ctx.beginPath();
    ctx.arc(tx, ty, r, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ── Fingerprint Powder ── */
  function drawPowder(ctx, W, H, mx, my, tick) {
    const tx = mx * W, ty = my * H;
    const r = 140 * (W / 375);

    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    const grd = ctx.createRadialGradient(tx, ty, 0, tx, ty, r);
    grd.addColorStop(0, 'rgba(0,220,255,0.8)');
    grd.addColorStop(0.5, 'rgba(0,180,220,0.4)');
    grd.addColorStop(1, 'rgba(0,150,200,0)');
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(tx, ty, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Cyan shimmer
    const shimmer = ctx.createRadialGradient(tx, ty, 0, tx, ty, r * 0.5);
    shimmer.addColorStop(0, 'rgba(0,242,254,0.15)');
    shimmer.addColorStop(1, 'rgba(0,242,254,0)');
    ctx.fillStyle = shimmer;
    ctx.beginPath();
    ctx.arc(tx, ty, r * 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ── Particles ── */
  function drawParticles(ctx, W, H, mx, my) {
    const dt = 1 / 60;
    S.particles = S.particles.filter(p => p.life < p.maxLife);

    for (const p of S.particles) {
      p.life += dt;
      p.x += p.vx + p.drift;
      p.y += p.vy;
      p.drift += (Math.random() - 0.5) * 0.0001;

      const progress = p.life / p.maxLife;
      const alpha = p.burst
        ? Math.sin(progress * Math.PI) * 0.9
        : Math.sin(progress * Math.PI) * 0.5;

      const px = p.x * W, py = p.y * H;

      // Only draw dust particles if they're inside the torch beam
      if (!p.burst) {
        const tx = mx * W, ty = my * H;
        const dx = px - tx, dy = py - ty;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const radius = S.torch ? CFG.torchRadius * (W / 375)
          : (S.uv ? CFG.uvRadius * (W / 375) : 0);
        if (dist > radius * 0.9) continue;
      }

      ctx.beginPath();
      ctx.arc(px, py, p.size, 0, Math.PI * 2);
      ctx.fillStyle = p.burst
        ? p.color.replace(')', `,${alpha})`)
        : `rgba(255,220,150,${alpha})`;
      ctx.fill();
    }

    // Replenish normal particles
    while (S.particles.filter(p => !p.burst).length < CFG.dustParticles) {
      S.particles.push(newParticle(false));
    }
  }

  /* ── Evidence Hotspots ── */
  function drawHotspots(ctx, W, H, tick) {
    for (const h of S.hotspots) {
      if (h.found) continue;
      const hx = h.x * W, hy = h.y * H;
      const t = tick / 60;
      const pulse = 0.6 + 0.4 * Math.sin(t * 3);

      // Only reveal primary hotspot if torch/UV is nearby
      if (h.isPrimary) {
        const mx = S.mx * W, my = S.my * H;
        const d = Math.sqrt((hx - mx) ** 2 + (hy - my) ** 2);
        const toolR = S.torch ? CFG.torchRadius * (W / 375) * 1.1 :
          S.uv ? CFG.uvRadius * (W / 375) * 1.1 : W * 0.5;
        const visible = d < toolR;
        if (!visible && (S.torch || S.uv || S.powder)) continue;
      }

      // Outer pulsing ring
      ctx.beginPath();
      ctx.arc(hx, hy, 28 * pulse, 0, Math.PI * 2);
      ctx.strokeStyle = h.isPrimary
        ? `rgba(255,183,3,${0.6 * pulse})`
        : `rgba(100,180,255,${0.3 * pulse})`;
      ctx.lineWidth = 2;
      ctx.stroke();

      // Inner ring
      ctx.beginPath();
      ctx.arc(hx, hy, 16, 0, Math.PI * 2);
      ctx.strokeStyle = h.isPrimary ? 'rgba(255,183,3,0.9)' : 'rgba(100,180,255,0.6)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Rotating dashes
      ctx.save();
      ctx.translate(hx, hy);
      ctx.rotate(t * (h.isPrimary ? 2 : -1.2));
      ctx.beginPath();
      ctx.arc(0, 0, 20, 0, Math.PI * 0.5);
      ctx.strokeStyle = h.isPrimary ? 'rgba(255,183,3,0.7)' : 'rgba(100,180,255,0.4)';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();

      // Icon
      ctx.font = `${18}px serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(h.icon, hx, hy);

      // Label (shown without torch or when very close)
      const showLabel = !S.torch || Math.sqrt((hx - S.mx * W) ** 2 + (hy - S.my * H) ** 2) < 80;
      if (showLabel) {
        ctx.font = `bold ${11}px Cairo, sans-serif`;
        ctx.fillStyle = h.isPrimary ? 'rgba(255,220,80,0.95)' : 'rgba(150,200,255,0.7)';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        // Label background
        const lw = ctx.measureText(h.label).width + 12;
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(hx - lw / 2, hy + 22, lw, 16);
        ctx.fillStyle = h.isPrimary ? 'rgba(255,220,80,0.95)' : 'rgba(150,200,255,0.8)';
        ctx.fillText(h.label, hx, hy + 24);
      }
    }
  }

  /* ── UV Clues ── */
  function drawUVClues(ctx, W, H, mx, my, tick) {
    const tx = mx * W, ty = my * H;
    const r = CFG.uvRadius * (W / 375);

    for (const clue of S.uvClues) {
      const cx2 = clue.x * W, cy2 = clue.y * H;
      const d = Math.sqrt((cx2 - tx) ** 2 + (cy2 - ty) ** 2);
      if (d > r * 0.85) continue;

      const alpha = 1 - d / r;
      const pulse = 0.7 + 0.3 * Math.sin(tick / 30);

      ctx.font = `bold 12px Cairo, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = `rgba(220,160,255,${alpha * pulse})`;
      ctx.fillText(clue.text, cx2, cy2);

      // Glow
      ctx.shadowColor = 'rgba(200,100,255,0.8)';
      ctx.shadowBlur = 12;
      ctx.fillText(clue.text, cx2, cy2);
      ctx.shadowBlur = 0;
    }
  }

  /* ── Powder Fingerprints ── */
  function drawPowderPrints(ctx, W, H, mx, my, tick) {
    const tx = mx * W, ty = my * H;
    const r = 140 * (W / 375);

    for (const fp of S.powderPrints) {
      const fx = fp.x * W, fy = fp.y * H;
      const d = Math.sqrt((fx - tx) ** 2 + (fy - ty) ** 2);
      if (d > r) continue;

      const alpha = (1 - d / r) * 0.9;
      const pulse = 0.8 + 0.2 * Math.sin(tick / 25);

      // Draw simplified fingerprint loops
      ctx.save();
      ctx.globalAlpha = alpha * pulse;
      ctx.strokeStyle = 'rgba(0,242,254,0.9)';
      ctx.lineWidth = 0.8;
      ctx.shadowColor = 'rgba(0,242,254,0.6)';
      ctx.shadowBlur = 8;
      for (let loop = 0; loop < 5; loop++) {
        ctx.beginPath();
        ctx.ellipse(fx, fy, 8 + loop * 4, 12 + loop * 4, 0.15, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
      ctx.restore();

      // Label
      ctx.font = 'bold 10px Cairo, sans-serif';
      ctx.fillStyle = `rgba(0,242,254,${alpha})`;
      ctx.textAlign = 'center';
      ctx.fillText(fp.label, fx, fy + 38);
    }
  }

  /* ── Film Grain ── */
  function drawFilmGrain(ctx, W, H, tick) {
    if (tick % 2 !== 0) return; // only every other frame
    const imgData = ctx.createImageData(W, H);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const g = (Math.random() * 2 - 1) * 18;
      data[i] = data[i + 1] = data[i + 2] = 128 + g;
      data[i + 3] = 8;
    }
    ctx.putImageData(imgData, 0, 0);
  }

  /* ── Vignette ── */
  function drawVignette(ctx, W, H) {
    const grd = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.85);
    grd.addColorStop(0, 'rgba(0,0,0,0)');
    grd.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, W, H);
  }

  /* ──────────────────────────────────────────────────────────────
     EXPOSE: Called when crime-scene-screen becomes active
  ────────────────────────────────────────────────────────────── */
  window.initCrimeScene2D = function (levelNum, evidenceTitle) {
    if (!S.canvas) init();
    resize();
    window.CrimeScene2D.loadScene(levelNum, evidenceTitle);
    S.torch = true;
    S.uv = false;
    S.powder = false;
    updateToolIndicator();
    updateBtnStates();
    spawnParticles();
    if (!S.rafId) loop();
  };

  /* Stop loop when screen hidden (performance) */
  window.stopCrimeScene2D = function () {
    if (S.rafId) { cancelAnimationFrame(S.rafId); S.rafId = null; }
  };

  /* ──────────────────────────────────────────────────────────────
     CSS keyframe for popup animation (injected once)
  ────────────────────────────────────────────────────────────── */
  const style = document.createElement('style');
  style.textContent = `
    @keyframes popupFadeIn {
      from { opacity:0; transform:translateX(-50%) translateY(10px) scale(0.9); }
      to   { opacity:1; transform:translateX(-50%) translateY(0)    scale(1);   }
    }
    #crime-canvas-wrap { background:#07080A; }
    #crime-scene-canvas { display:block; }
  `;
  document.head.appendChild(style);

  /* Auto-init if DOM ready */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();

