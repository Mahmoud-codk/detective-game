/* ═══════════════════════════════════════════════════════════
   🌐 UNKNOWN CULPRIT - INTERNATIONALIZATION (i18n) ENGINE
   ═══════════════════════════════════════════════════════════ */

const I18N_DATA = {
  ar: {
    // App & Brand
    appTitle: "الجاني مجهول - UNKNOWN CULPRIT",
    appName: "الجاني مجهول",
    tagline: "UNKNOWN CULPRIT · حقق • حلل • اكشف",
    subTagline: "100 قضية جنائية · استجواب ذكي · فحص تفاعلي ثلاثي الأبعاد · ربط خيوط الجريمة",
    langName: "English",
    langSwitchTooltip: "Switch language to English",

    // HUD
    coins: "عملات",
    rank: "رتبة المحقق",
    notebook: "المفكرة",
    hint: "تلميح 📺",
    freeHint: "تلميح 📺",
    timer: "الوقت",

    // Splash Screen
    startInvestigation: "ابدأ التحقيق 🔍",
    continueInvestigation: "متابعة التحقيق 🔍",
    caseMap: "🗺️ خريطة القضايا (100 قضية)",
    charactersGallery: "🎭 معرض الـ 300 شخصية (دليل المشتبه بهم)",
    progressText: "🏆 نسبة الإنجاز: {percent}% ({solved}/100 قضية)",
    detectiveRank: "رتبة المحقق: {rank} ({xp} XP)",
    audioMuted: "الصوت: كتم 🔇",
    audioUnmuted: "الصوت: تشغيل 🔊",

    // Noir Detective Main Menu
    menuContinue: "يكمل",
    menuChapters: "فصول",
    menuSettings: "إعدادات",
    menuExit: "مخرج",
    badgeShare: "مشاركة",
    badgeMoreGames: "المزيد",
    badgeRateUs: "تقييم",
    neonTitle: "المخبر الذكي",
    neonSubtitle: "قسم التحقيقات الجنائية · 100 قضية غامضة",
    settingsTitle: "إعدادات مكتب التحقيق",
    soundFx: "المؤثرات الصوتية",
    musicBgm: "الموسيقى التصويرية",
    languageSetting: "لغة اللعبة",
    resetProgress: "إعادة تعيين التقدم",
    resetConfirm: "هل أنت متأكد من مسح جميع بيانات القضايا والبدء من الصفر؟",
    exitTitle: "مغادرة التحقيق",
    exitPrompt: "هل ترغب في حفظ تقدمك ومغادرة مكتب التحقيق الآن؟",
    btnConfirmExit: "تأكيد الخروج",
    btnCancel: "إلغاء",
    rateTitle: "تقييم المحقق",
    ratePrompt: "رأيك يساعدنا في إضافة قضايا وألغاز جديدة!",
    rateSubmit: "إرسال التقييم ⭐",

    // Hint Modal
    hintModalTitle: "تلميح المحقق",
    hintGotIt: "فهمت ✓",
    backBtn: "← رجوع",

    // Guided Tutorial & Banners
    guideTitle: "إشارة المحقق التعليمية",
    guideText: "اضغط على مسرح الجريمة لجمع الدليل الأول!",
    pointerText: "اضغط هنا لجمع الدليل 🔍",

    // Case Cinematic Intro
    policeLine: "POLICE LINE • DO NOT CROSS • CRIME SCENE • خط الشرطة",
    evidenceSecured: "EVIDENCE SECURED • FORENSICS DEPT • الأدلة الجنائية",
    emergencyDispatch: "🚨 بلاغ عمليات طارئ #{id}",
    incidentLocation: "📍 موقع الحادث: {location}",
    narrativeReceiving: "جاري استقبال إشارة اللاسلكي وتفريغ ملخص البلاغ من الدوريات الأمنية...",
    skipIntro: "تخطي ⏭",
    enterCrimeScene: "دخول مسرح الجريمة 🔍",

    // Dashboard
    timelineTicker: "⏱️ التطور الزمني:",
    timelineInitial: "وقوع الجريمة واكتشاف الموقع",
    worldEvent: "🌍 حدث طارئ في البيئة:",
    levelBadge: "المستوى {level}",
    iqEasy: "🟢 IQ 80 — سهل",
    iqMedium: "🟡 IQ 110 — متوسط",
    iqHard: "🔴 IQ 140 — عبقري",
    discoveredEvidence: "🔍 الأدلة المكتشفة: {count} / 3",
    contradictionsFound: "💬 التناقضات: {count} مكتشفة",
    suspectsTitle: "👥 المشتبه بهم (اضغط على البطاقة للبدء في الاستجواب)",
    evidenceTitle: "🔍 مسرح الجريمة والأدلة المادية",
    inspect3dBtn: "🏢 فحص مسرح الجريمة (ثلاثي الأبعاد 3D)",
    forensicsLabTitle: "🔬 المعمل الجنائي المتطور",
    btnFingerprint: "👆 فحص البصمات",
    btnBallistics: "🎯 تحليل المقذوفات",
    btnUV: "🟣 كاشف الأشعة فوق البنفسجية UV",
    btnChemical: "🧪 التحليل الكيميائي",
    btnDecryption: "💻 فك تشفير الرسائل",
    btnWiretap: "🎙️ تحليل التسجيلات الصوتية",
    accuseBtn: "⚖️ اتهام الجاني وإصدار مذكرة ضبط",

    // Suspect Interrogation
    interrogationTitle: "غرفة التحقيق والاستجواب",
    suspectBio: "الملف التعريفي:",
    statementTitle: "أقوال المشتبه به الأولية:",
    stressLevel: "مستوى التوتر والنبض:",
    stressCalm: "هادئ وطبيعي",
    stressNervous: "متوتر ومتردد",
    stressPanicked: "مرتبك ويتلعثم بالحديث!",
    askAlibi: "🕒 أين كنت وقت وقوع الجريمة بالتحديد؟",
    askMotive: "💰 ما هي علاقتك بالضحية وما مصلحتك؟",
    askRelationship: "🤝 كيف تصف تعاملك الأخير معه؟",
    confrontEvidence: "🔍 مواجهة بالأدلة والمضبوطات",
    pointContradiction: "⚡ مواجهة بتناقض الأقوال",
    interrogateNext: "المشتبه به التالي ➡️",
    interrogatePrev: "⬅️ المشتبه به السابق",
    closeInterrogation: "إغلاق الاستجواب ✕",

    // 3D Scene Controls
    scene3dTitle: "مسرح الجريمة التفاعلي",
    mode3d: "نمط 3D تفاعلي",
    mode2d: "نمط 2D كلاسيكي",
    toggleTorch: "🔦 تشغيل الكشاف",
    torchOn: "🔦 إطفاء الكشاف",
    rotateHint: "اسحب للتدوير • انقر على الأدلة اللامعة للفحص",
    clueDiscovered: "تم العثور على دليل: {name}!",

    // Forensic Minigames
    fingerprintScanTitle: "👆 مطابقة البصمات الجنائية",
    fingerprintInstr: "حرك العدسة المكبرة وحدد نقاط التطابق مع البصمة المرفوعة من المسرح",
    ballisticsTitle: "🎯 تحليل المسار البالستي والمقذوفات",
    ballisticsInstr: "طابق الأخاديد الحلزونية للرصاصة المستخرجة مع سلاح الجريمة",
    uvTitle: "🟣 فحص الأشعة فوق البنفسجية (UV)",
    uvInstr: "سلط ضوء الـ UV لكشف بقع السوائل المخفية والآثار البيولوجية",
    chemicalTitle: "🧪 فحص الكواشف الكيميائية",
    chemicalInstr: "اختر الكاشف المناسب (لومينول / حمض النيتريك) للكشف عن السموم والدم",
    decryptionTitle: "💻 فك التشفير السيبراني",
    decryptionInstr: "رتب الشيفرات واستنتج المفتاح السري لفك رسائل الواتساب المحذوفة",
    wiretapTitle: "🎙️ تنقية وتحليل الترددات الصوتية",
    wiretapInstr: "قم بإزالة الضوضاء المحيطة واستخرج نبرة الصوت المطابقة للجاني",
    forensicSuccess: "✔ تم إثبات التطابق الجنائي بنجاح! أُضيف الدليل إلى المفكرة.",
    forensicFail: "✖ لم يتطابق النموذج، حاول مجدداً بدقة أكبر.",

    // Notebook
    notebookTitle: "📓 دفتر ملاحظات المحقق",
    tabClues: "الأدلة المادية ({count})",
    tabDiscrepancies: "التناقضات ({count})",
    tabTimeline: "التسلسل الزمني",
    noCluesYet: "لم يتم جمع أي أدلة حتى الآن. افحص مسرح الجريمة والمعمل الجنائي.",
    noDiscrepanciesYet: "لم تُسجل أي تناقضات. استجوب المشتبه بهم وواجههم بالأدلة.",
    timelineHeader: "تسلسل الأحداث المثبتة رسمياً:",

    // Accusation & Verdict
    accusationTitle: "⚖️ إصدار مذكرة التوقيف الرسمية",
    verdictModalTitle: "⚖️ لائحة الاتهام والمحاكمة النهائية",
    verdictStep1Title: "الخطوة 1 من 5 — اختر المتهم الرئيسي",
    verdictStep2Title: "الخطوة 2 من 5 — حدد الدافع الإجرامي",
    verdictStep3Title: "الخطوة 3 من 5 — حدد أداة/أسلوب الجريمة",
    verdictStep4Title: "الخطوة 4 من 5 — ترتيب تسلسل الأحداث الزمني",
    verdictStep4Subtitle: "اختر الترتيب الصحيح لبدء الجريمة وتنفيذها وسحب الأدلة:",
    verdictStep5Title: "الخطوة 5 من 5 — قدّم الدليل القاطع للمحكمة",
    submitFinalVerdictBtn: "تقديم لائحة الاتهام النهائية ⚖️",
    submitAccusationBtn: "⚖️ تأكيد الاتهام النهائي",
    btnNextStep: "التالي ➔",
    btnPrevStep: "← العودة",
    selectCulpritPrompt: "من هو الجاني الحقيقي في هذه القضية؟",
    selectEvidencePrompt: "اختر الدليل القاطع الذي يثبت إدانته بما لا يدع مجالاً للشك:",
    confirmArrestBtn: "تأكيد الاتهام والقبض 🚨",
    cancelBtn: "تراجع ومواصلة التحقيق",
    noSuspectSelected: "يرجى تحديد المشتبه به أولاً!",
    noEvidenceSelected: "يرجى تحديد الدليل القاطع لمواجهة الجاني!",
    courtroomModalTitle: "🏛️ جلسة المحاكمة ومناقشة القاضي",
    judgePrompt: "⚖️ القاضي:",
    judgeSpeech: "سيادة المحقق، لقد اعتمدت نظرية الاتهام وتطالب بإدانة المتهم. ما هو الدليل المادي القاطع الذي تقدمه لإثبات التهمة أمام هيئة المحكمة؟",
    theoryBuilderTitle: "⚖️ بناء نظرية القضية",
    theoryBuilderSubtitle: "ابنِ نظريتك الخاصة بالجريمة عبر تسلسل الربط المنطقي قبل نقل القضية للمحكمة:",
    confrontEvidenceTitle: "💼 مواجهة المشتبه به بدليل مادي",
    confrontEvidenceSubtitle: "اختر الدليل المادي لمواجهة المتهم به وكشف الكذب:",

    // Solved Screen (Victory)
    caseSolvedTitle: "🎉 تم حل القضية بنجاح!",
    verdictLabel: "✅ الجاني",
    rewardLabel: "مكافأة:",
    btnReplayCase: "إعادة اللعب",
    caseRecordTitle: "سجل القضايا (100 قضية)",
    cancel: "إلغاء",
    congratsTitle: "إنجاز مبهر أيها المحقق!",
    culpritRevealed: "الجاني الحقيقي: {name} ({role})",
    caseSummary: "ملخص كشف الجريمة:",
    rewardsEarned: "المكافآت المكتسبة:",
    xpGain: "+{xp} نقطة خبرة XP",
    coinsGain: "+{coins} عملة ذهبية 🪙",
    btnNextCase: "القضية التالية ➡️",
    btnReviewCase: "مراجعة ملف القضية 📜",
    btnBackToMap: "العودة لخريطة القضايا 🗺️",

    // Defeat Screen
    caseFailedTitle: "❌ اتهام باطل! أفلت الجاني الحقيقي",
    wrongCulpritMsg: "المشتبه به {name} بريء، الأدلة المقدمة غير كافية وأدت لإخلاء سبيله.",
    whyWrong: "سبب الخطأ:",
    btnRetryCase: "إعادة التحقيق 🔄",
    btnUseHint: "طلب تلميح ذكي 💡",

    // Rank & Progression
    ranksTitle: "🎖️ سلم رتب المحققين",
    currentXp: "الخبرة الحالية: {xp} XP",
    nextRankAt: "الرتبة القادمة عند {xp} XP",
    rankRookie: "محقق متدرب (Rookie Detective)",
    rankJunior: "مساعد محقق (Junior Detective)",
    rankSenior: "محقق جنائي (Senior Detective)",
    rankLead: "كبير المحققين (Lead Investigator)",
    rankChief: "رئيس المباحث (Chief of Detectives)",
    rankLegend: "المحقق الأسطوري (Legendary Master)",

    // Hint Dialog
    hintTitle: "💡 تلميح المحقق الذكي",
    hintCostPrompt: "هل تريد استخدام تلميح مقابل 20 عملة 🪙؟",
    notEnoughCoins: "ليس لديك عملات كافية! يمكنك مشاهدة إعلان قصير للحصول على تلميح مجاني.",
    watchAdForCoins: "مشاهدة إعلان (+50🪙)",
    watchAdForHint: "مشاهدة إعلان لتلميح فوري 💡",
    btnGetHint: "شراء التلميح",

    // Chapters Map
    chapterTitle: "🗺️ خريطة القضايا الجنائية",
    chapterFilterAll: "الكل (100)",
    chapterFilterSolved: "المحلولة",
    chapterFilterLocked: "المغلقة",
    levelLockedMsg: "هذه القضية مغلقة! يجب إنجاز القضايا السابقة أولاً.",

    // General Toasts & Messages
    toastCopied: "تم النسخ بنجاح!",
    toastAdLoaded: "جاري عرض الإعلان المكافئ...",
    toastRewardSuccess: "تمت إضافة {amount} عملة ذهبية بنجاح! 🪙",
    toastHintUnlocked: "تم تفعيل التلميح الذكي بنجاح!",
    toastSaveSuccess: "تم حفظ تقدم التحقيق تلقائياً.",
    backToDashboard: "العودة للوحة القضية",

    // Dashboard Buttons & Badges
    evidenceCollected: "الأدلة المادية",
    contradictions: "التناقضات",
    crimeSceneBtn: "مسرح الجريمة 🔬",
    accuseBtn: "لائحة الاتهام ⚖️",
    evidence: "الأدلة",
    toolsTitle: "أدوات التحقيق والمعمل الجنائي",
    phoneBtn: "هاتف الضحية",
    corkboardBtn: "لوحة الفلين",
    theoryBtn: "نظرية القضية",
    deductionBtn: "الاستنتاج",
    casesBtn: "القضايا (100)",

    // Interrogation Strings
    pulseLabel: "النبض:",
    interrogateReady: "أنا جاهز للإجابة عن أسئلتك يا سيادة المحقق.",
    bodyLanguageTitle: "🎭 ملاحظات لغة الجسد والانفعال الجنائي:",
    expressionFaceCalm: "👀 تعابير الوجه: هادئ ويحافظ على التواصل البصري.",
    expressionBodyRelaxed: "🤚 لغة الجسد: مسترخٍ وإيقاع التنفس طبيعي.",
    lawyerWarning: "🚫 المشتبه به طلب محامياً وامتنع عن مواصلة الحديث!",

    // 3D Inspector Modal
    inspector3dTitle: "🔬 فحص الدليل ثلاثي الأبعاد 360°",
    inspector3dDesc: "اسحب بإصبعك لتدوير الدليل 360 درجة واكتشاف الآثار الخفية:",
    inspector3dFingerprint: "🔍 تم كشف بصمة جنائية كامنة على المقبض الخلفي!",
    inspector3dActive: "تدوير تفاعلي ثلاثي الأبعاد — الزاوية الحالية: 0°",
    closeInspector: "إغلاق الفحص ✕",

    // Telemetry Analytics Modal
    telemetryTitle: "📊 إحصائيات الأداء والتحليل الجنائي",
    telSuccessRate: "نسبة القضايا المحلولة:",
    telAvgTime: "متوسط وقت الحل:",
    telFalseAcc: "الاتهامات الخاطئة:",
    telVersion: "إصدار المحرك:",

    // Deduction Board Modal
    deductionBoardTitle: "🔗 لوحة مصفوفة الاستنتاج والربط المنطقي",
    deductionBoardDesc: "قم بربط خيوط التحقيق للتأكد من تسلسل الاستنتاج المنطقي قبل المحاكمة.",
    dedPrimeSuspect: "👤 المشتبه به الرئيسي:",
    dedMotive: "🎯 الدافع الخفي:",
    dedWeapon: "🔪 أداة / وسيلة الجريمة:",
    dedProof: "🔬 الدليل الجنائي القاطع:",
    dedTest: "اختبار الاستنتاج المنطقي 🧠",

    // Two-Step Case Navigation
    goToSuspectsBtn: "الانتقال إلى المشتبه بهم والأدلة (3 مشتبهين) ➔",
    backToCaseDossierBtn: "← ملف البلاغ الأولي",
    caseDossierTitle: "📄 ملف البلاغ الأمني وتفاصيل الحادثة",
    suspectsHubTitle: "👥 غرفة المشتبه بهم والأدلة الجنائية",

    // Tutorial Modal
    tutorialBadge: "🔍 دليل المحقق الإرشادي",
    welcomeDetective: "مرحباً بك أيها المحقق!",
    tutSlide1Title: "مهمتك الجنائية الخاصة",
    tutSlide1Desc: "أنت المحقق النخبة المكلف بحل الجرائم وفك الألغاز عبر 100 قضية جنائية مشوقة. مهمتك: جمع الأدلة، استجواب المتهمين، وكشف الجاني الحقيقي دون الوقوع في الفخاخ!",
    tutSlide1Chip1: "🔬 معاينة مسرح الجريمة",
    tutSlide1Chip2: "💬 استجواب المتهمين",
    tutSlide1Chip3: "⚖️ إصدار الاتهام النهائي",
    tutSlide2Title: "1. دراسة ملف البلاغ ومسرح الجريمة",
    tutSlide2Desc: "في بداية كل قضية، اقرأ تفاصيل الجريمة وموقع الحادث بعناية. راجع بطاقات المشتبه بهم الثلاثة واقرأ أقوالهم الأولية لرصد التناقضات المبكرة.",
    tutSlide2Tip: "💡 ملاحظة: لكل قضية جانٍ حقيقي واحد بدافع وسلاح محددين بدقة!",
    tutSlide3Title: "2. مسرح الجريمة والمعمل الجنائي",
    tutSlide3Desc: "اضغط على مسرح الجريمة 🔬 لمعاينة المكان. حدد موقع مكبر البحث 🔍 لجمع الأدلة، ثم استخدم المعمل الجنائي لتحليل البصمات والعينات.",
    tutSlide3Tip: "💼 كل دليل تجمعه يحفظ تلقائياً في حقيبة الأدلة الجنائية!",
    tutSlide4Title: "3. استجواب المشتبه بهم ومراقبة التوتر",
    tutSlide4Desc: "اضغط على أي مشتبه به لبدء الاستجواب المباشر. وجه الأسئلة وراقب مؤشر التوتر النفسي 🧠. انتبه: إذا بلغ التوتر 100% يطلب المتهم محامياً ويمتنع عن الكلام!",
    tutSlide4Tip: "⚠️ ركز في إجابات المتهم وطابقها مع الأدلة المادية المرفوعة!",
    tutSlide5Title: "4. تقديم لائحة الاتهام النهائية",
    tutSlide5Desc: "عند التأكد من هوية الجاني، اضغط على تقديم لائحة الاتهام ⚖️ وحدد الأركان الأربعة: (1) المتهم (2) الدافع (3) وسيلة الجريمة (4) الدليل القاطع.",
    tutSlide5Tip: "🎉 الاتهام الصحيح 100% يمنحك أعلى رصيد من العملات والنجوم الذهبية!",
    btnPrev: "← السابق",
    btnNext: "التالي ➔",
    btnStartInvestigatingNow: "ابدأ التحقيق الآن 🔍"
  },

  en: {
    // App & Brand
    appTitle: "UNKNOWN CULPRIT - Mystery Detective",
    appName: "UNKNOWN CULPRIT",
    tagline: "UNKNOWN CULPRIT · Investigate • Analyze • Reveal",
    subTagline: "100 Criminal Cases · Smart Interrogation · Interactive 3D Scenes · Deductive Logic",
    langName: "العربية",
    langSwitchTooltip: "تغيير اللغة إلى العربية",

    // HUD
    coins: "Coins",
    rank: "Rank",
    notebook: "Notebook",
    hint: "Hint 📺",
    freeHint: "Hint 📺",
    timer: "Timer",

    // Splash Screen
    startInvestigation: "Start Investigation 🔍",
    continueInvestigation: "Continue Case 🔍",
    caseMap: "🗺️ Case Map (100 Cases)",
    charactersGallery: "🎭 300 Suspects Dossier",
    progressText: "🏆 Progress: {percent}% ({solved}/100 Cases Solved)",
    detectiveRank: "Detective Rank: {rank} ({xp} XP)",
    audioMuted: "Audio: Muted 🔇",
    audioUnmuted: "Audio: On 🔊",

    // Noir Detective Main Menu
    menuContinue: "CONTINUE",
    menuChapters: "CHAPTERS",
    menuSettings: "SETTINGS",
    menuExit: "EXIT",
    badgeShare: "Share",
    badgeMoreGames: "More Games",
    badgeRateUs: "Rate Us",
    neonTitle: "DETECTIVE",
    neonSubtitle: "CRIMINAL INVESTIGATION DEPT · 100 MYSTERIES",
    settingsTitle: "Investigation Settings",
    soundFx: "Sound Effects",
    musicBgm: "Background Music",
    languageSetting: "Game Language",
    resetProgress: "Reset Progress",
    resetConfirm: "Are you sure you want to reset all solved cases and start anew?",
    exitTitle: "Leave Office",
    exitPrompt: "Would you like to save your progress and exit the detective office?",
    btnConfirmExit: "Exit Game",
    btnCancel: "Cancel",
    rateTitle: "Rate Detective",
    ratePrompt: "Your rating helps us craft more intriguing crime mysteries!",
    rateSubmit: "Submit Rating ⭐",

    // Hint Modal
    hintModalTitle: "Detective's Clue",
    hintGotIt: "Got It ✓",
    backBtn: "← Back",

    // Guided Tutorial & Banners
    guideTitle: "Detective Field Dispatch",
    guideText: "Tap on the Crime Scene to gather your first crucial piece of evidence!",
    pointerText: "Tap here to inspect evidence 🔍",

    // Case Cinematic Intro
    policeLine: "POLICE LINE • DO NOT CROSS • CRIME SCENE",
    evidenceSecured: "EVIDENCE SECURED • FORENSICS DEPT • CRIME DIVISION",
    emergencyDispatch: "🚨 Emergency Police Dispatch #{id}",
    incidentLocation: "📍 Incident Location: {location}",
    narrativeReceiving: "Receiving police radio transmission and decrypting emergency incident report...",
    skipIntro: "Skip ⏭",
    enterCrimeScene: "Enter Crime Scene 🔍",

    // Dashboard
    timelineTicker: "⏱️ Incident Timeline:",
    timelineInitial: "Crime occurred & crime scene cordoned off",
    worldEvent: "🌍 Environmental Flash Alert:",
    levelBadge: "Case {level}",
    iqEasy: "🟢 IQ 80 — Easy",
    iqMedium: "🟡 IQ 110 — Moderate",
    iqHard: "🔴 IQ 140 — Mastermind",
    discoveredEvidence: "🔍 Evidence Collected: {count} / 3",
    contradictionsFound: "💬 Contradictions: {count} Exposed",
    suspectsTitle: "👥 Suspects (Tap a dossier card to interrogate)",
    evidenceTitle: "🔍 Crime Scene & Physical Evidence",
    inspect3dBtn: "🏢 Inspect Crime Scene (3D / 2D Explorer)",
    forensicsLabTitle: "🔬 Advanced Forensic Laboratory",
    btnFingerprint: "👆 Fingerprint Scan",
    btnBallistics: "🎯 Ballistics Analysis",
    btnUV: "🟣 UV Light Detector",
    btnChemical: "🧪 Chemical Reagent",
    btnDecryption: "💻 Cyber Decryption",
    btnWiretap: "🎙️ Wiretap Audio",
    accuseBtn: "⚖️ Accuse Culprit & Issue Arrest Warrant",

    // Suspect Interrogation
    interrogationTitle: "Interrogation Chamber",
    suspectBio: "Suspect Dossier:",
    statementTitle: "Initial Witness Statement:",
    stressLevel: "Stress & Heartbeat Level:",
    stressCalm: "Calm & Composed",
    stressNervous: "Nervous & Hesitant",
    stressPanicked: "Panicking & Contradicting!",
    askAlibi: "🕒 Where exactly were you when the crime occurred?",
    askMotive: "💰 What was your exact relationship with the victim?",
    askRelationship: "🤝 When was the last time you spoke with them?",
    confrontEvidence: "🔍 Confront with Physical Evidence",
    pointContradiction: "⚡ Point Out Statement Contradiction",
    interrogateNext: "Next Suspect ➡️",
    interrogatePrev: "⬅️ Previous Suspect",
    closeInterrogation: "Close Dossier ✕",

    // 3D Scene Controls
    scene3dTitle: "Interactive Crime Scene",
    mode3d: "3D Interactive Mode",
    mode2d: "2D Classic Mode",
    toggleTorch: "🔦 Turn On Flashlight",
    torchOn: "🔦 Turn Off Flashlight",
    rotateHint: "Drag to rotate scene • Tap glowing markers to inspect clues",
    clueDiscovered: "Crucial Clue Discovered: {name}!",

    // Forensic Minigames
    fingerprintScanTitle: "👆 Latent Fingerprint Matching",
    fingerprintInstr: "Adjust magnifying lens and locate minutiae matching the crime scene print",
    ballisticsTitle: "🎯 Ballistics & Rifling Comparison",
    ballisticsInstr: "Align barrel rifling grooves with the recovered projectile",
    uvTitle: "🟣 Forensic UV Luminescence Scan",
    uvInstr: "Direct ultraviolet light beam to reveal concealed biological and chemical traces",
    chemicalTitle: "🧪 Chemical & Toxicological Reagent",
    chemicalInstr: "Select the appropriate reagent (Luminol / Nitric Acid) to identify toxins or blood",
    decryptionTitle: "💻 Cryptographic Cipher Decryption",
    decryptionInstr: "Decrypt algorithmic shift keys to reconstruct deleted messaging threads",
    wiretapTitle: "🎙️ Wiretap Frequency & Voiceprint Analysis",
    wiretapInstr: "Filter ambient background noise to isolate suspect's unique vocal frequencies",
    forensicSuccess: "✔ Forensic match verified! Evidence logged into your Case Notebook.",
    forensicFail: "✖ Pattern mismatch. Re-examine the sample and try again.",

    // Notebook
    notebookTitle: "📓 Lead Detective's Notebook",
    tabClues: "Physical Evidence ({count})",
    tabDiscrepancies: "Contradictions ({count})",
    tabTimeline: "Timeline of Events",
    noCluesYet: "No physical evidence gathered yet. Search the crime scene and forensic lab.",
    noDiscrepanciesYet: "No contradictions recorded. Interrogate suspects and challenge alibis.",
    timelineHeader: "Officially Verified Chronology:",

    // Accusation & Verdict
    accusationTitle: "⚖️ Formal Arrest Warrant Issuance",
    verdictModalTitle: "⚖️ Final Indictment & Court Trial",
    verdictStep1Title: "Step 1 of 5 — Select Prime Suspect",
    verdictStep2Title: "Step 2 of 5 — Determine Criminal Motive",
    verdictStep3Title: "Step 3 of 5 — Identify Weapon / Method",
    verdictStep4Title: "Step 4 of 5 — Reconstruct Event Timeline",
    verdictStep4Subtitle: "Choose the correct sequence of crime execution and evidence concealment:",
    verdictStep5Title: "Step 5 of 5 — Present Decisive Evidence to Court",
    submitFinalVerdictBtn: "Submit Final Indictment ⚖️",
    submitAccusationBtn: "⚖️ Submit Final Accusation",
    btnNextStep: "Next ➔",
    btnPrevStep: "← Back",
    selectCulpritPrompt: "Who is the true perpetrator behind this crime?",
    selectEvidencePrompt: "Select the decisive piece of evidence proving their guilt beyond reasonable doubt:",
    confirmArrestBtn: "Execute Arrest Warrant 🚨",
    cancelBtn: "Resume Investigation",
    noSuspectSelected: "Please select a suspect before proceeding!",
    noEvidenceSelected: "Please choose the conclusive evidence to confront the culprit!",
    courtroomModalTitle: "🏛️ Courtroom Hearing & Judicial Cross-Examination",
    judgePrompt: "⚖️ The Judge:",
    judgeSpeech: "Detective, you have formulated an indictment and request a conviction. What decisive physical evidence do you present before the court to prove their guilt beyond reasonable doubt?",
    theoryBuilderTitle: "⚖️ Case Theory Builder",
    theoryBuilderSubtitle: "Construct your crime theory through logical deduction before taking the case to court:",
    confrontEvidenceTitle: "💼 Confront Suspect with Physical Evidence",
    confrontEvidenceSubtitle: "Select physical evidence to confront the suspect and expose inconsistencies:",

    // Solved Screen (Victory)
    caseSolvedTitle: "🎉 Case Solved! Case Closed",
    verdictLabel: "✅ Culprit",
    rewardLabel: "Reward:",
    btnReplayCase: "Replay Case",
    caseRecordTitle: "Case Registry (100 Cases)",
    cancel: "Cancel",
    congratsTitle: "Outstanding Deductive Work, Detective!",
    culpritRevealed: "True Culprit: {name} ({role})",
    caseSummary: "Case Resolution & Motive Breakdown:",
    rewardsEarned: "Investigation Honors & Rewards:",
    xpGain: "+{xp} Experience XP",
    coinsGain: "+{coins} Gold Coins 🪙",
    btnNextCase: "Next Case ➡️",
    btnReviewCase: "Review Case Dossier 📜",
    btnBackToMap: "Case Selection Map 🗺️",

    // Defeat Screen
    caseFailedTitle: "❌ False Accusation! The Culprit Escaped",
    wrongCulpritMsg: "Suspect {name} is innocent. Insufficient evidence led to their immediate release.",
    whyWrong: "Investigation Flaw:",
    btnRetryCase: "Reopen Case 🔄",
    btnUseHint: "Consult Smart Hint 💡",

    // Rank & Progression
    ranksTitle: "🎖️ Detective Bureau Hierarchy",
    currentXp: "Current Experience: {xp} XP",
    nextRankAt: "Next Promotion at {xp} XP",
    rankRookie: "Rookie Detective",
    rankJunior: "Junior Detective",
    rankSenior: "Senior Detective",
    rankLead: "Lead Investigator",
    rankChief: "Chief of Detectives",
    rankLegend: "Legendary Master Sleuth",

    // Hint Dialog
    hintTitle: "💡 Senior Detective Consultation",
    hintCostPrompt: "Unlock a breakthrough investigation clue for 20 coins 🪙?",
    notEnoughCoins: "Insufficient coins! Watch a short sponsored dispatch to receive a free clue.",
    watchAdForCoins: "Watch Dispatch (+50🪙)",
    watchAdForHint: "Watch Dispatch for Free Hint 💡",
    btnGetHint: "Purchase Hint",

    // Chapters Map
    chapterTitle: "🗺️ Criminal Case Files Directory",
    chapterFilterAll: "All Cases (100)",
    chapterFilterSolved: "Solved",
    chapterFilterLocked: "Locked",
    levelLockedMsg: "This case is classified! Solve preceding investigations to unlock.",

    // General Toasts & Messages
    toastCopied: "Dossier copied to clipboard!",
    toastAdLoaded: "Loading sponsored reward dispatch...",
    toastRewardSuccess: "Added {amount} Gold Coins to your detective treasury! 🪙",
    toastHintUnlocked: "Investigation hint unlocked and added to your notebook!",
    toastSaveSuccess: "Investigation progress saved.",
    backToDashboard: "Return to Dashboard",

    // Dashboard Buttons & Badges
    evidenceCollected: "Evidence",
    contradictions: "Contradictions",
    crimeSceneBtn: "Crime Scene 🔬",
    accuseBtn: "Accuse Culprit ⚖️",
    evidence: "Evidence",
    toolsTitle: "Detective Tools & Forensic Analysis",
    phoneBtn: "Victim Phone",
    corkboardBtn: "Corkboard",
    theoryBtn: "Case Theory",
    deductionBtn: "Deduction",
    casesBtn: "Cases (100)",

    // Interrogation Strings
    pulseLabel: "Pulse:",
    interrogateReady: "I am ready to answer your questions, Detective.",
    bodyLanguageTitle: "🎭 Forensic Observations & Body Language:",
    expressionFaceCalm: "👀 Facial Expression: Calm and maintaining direct eye contact.",
    expressionBodyRelaxed: "🤚 Body Language: Relaxed with normal breathing rhythm.",
    lawyerWarning: "🚫 Suspect requested legal counsel and refused further answers!",

    // 3D Inspector Modal
    inspector3dTitle: "🔬 360° 3D Evidence Inspector",
    inspector3dDesc: "Drag with your finger/mouse to rotate the evidence 360° and discover hidden traces:",
    inspector3dFingerprint: "🔍 Latent forensic fingerprint revealed on rear handle!",
    inspector3dActive: "3D Rotation Active — Current Angle: 0°",
    closeInspector: "Close Inspector ✕",

    // Telemetry Analytics Modal
    telemetryTitle: "📊 Forensic Telemetry Engine Analytics",
    telSuccessRate: "Overall Solved Rate:",
    telAvgTime: "Average Solve Time:",
    telFalseAcc: "False Accusations:",
    telVersion: "Engine Version:",

    // Deduction Board Modal
    deductionBoardTitle: "🔗 Deduction & Clue Matrix Board",
    deductionBoardDesc: "Connect investigation leads to verify deductive logic before advancing to court trial.",
    dedPrimeSuspect: "👤 Prime Suspected Culprit:",
    dedMotive: "🎯 Concealed Motive:",
    dedWeapon: "🔪 Direct Weapon / Instrument:",
    dedProof: "🔬 Decisive Forensic Proof:",
    dedTest: "Test Logical Deduction 🧠",

    // Two-Step Case Navigation
    goToSuspectsBtn: "Proceed to Suspects & Evidence Hub (3) ➔",
    backToCaseDossierBtn: "← Case Incident Dossier",
    caseDossierTitle: "📄 Case Incident Dossier & Police Report",
    suspectsHubTitle: "👥 Suspects & Forensic Evidence Hub",

    // Tutorial Modal
    tutorialBadge: "🔍 Detective Starter Guide",
    welcomeDetective: "Welcome, Detective!",
    tutSlide1Title: "Your Undercover Mission",
    tutSlide1Desc: "You are the elite detective assigned to crack crimes and mysteries across 100 criminal cases. Your mission: gather evidence, interrogate suspects, and expose the true culprit without falling into traps!",
    tutSlide1Chip1: "🔬 Crime Scene Inspection",
    tutSlide1Chip2: "💬 Suspect Interrogation",
    tutSlide1Chip3: "⚖️ Final Indictment",
    tutSlide2Title: "1. Study the Case Dossier",
    tutSlide2Desc: "At the start of each case, carefully read the crime details and incident location. Review the three suspect dossier cards and read their initial statements to spot early contradictions.",
    tutSlide2Tip: "💡 Note: Each case has exactly one real culprit with specific motive and weapon!",
    tutSlide3Title: "2. Crime Scene & Forensic Lab",
    tutSlide3Desc: "Tap Crime Scene to inspect the location. Locate the evidence magnifier to collect physical evidence, then use the Forensic Lab to analyze samples.",
    tutSlide3Tip: "💼 All collected evidence is stored in your personal Evidence Briefcase!",
    tutSlide4Title: "3. Interrogate Suspects & Apply Pressure",
    tutSlide4Desc: "Tap any suspect to begin direct interrogation. Ask pointed questions and monitor the psychological pressure gauge. Beware: at 100% pressure, the suspect demands a lawyer!",
    tutSlide4Tip: "⚠️ Focus on the suspect's answers and cross-reference them against collected evidence!",
    tutSlide5Title: "4. Submit the Decisive Indictment",
    tutSlide5Desc: "Once certain of the culprit, press Accuse Culprit and input the four critical elements: (1) Suspect (2) Motive (3) Weapon / Method (4) Decisive Evidence.",
    tutSlide5Tip: "🎉 A 100% accurate indictment earns maximum coin reward and gold stars!",
    btnPrev: "← Previous",
    btnNext: "Next ➔",
    btnStartInvestigatingNow: "Start Investigating Now 🔍"
  }
};

const I18nManager = {
  currentLang: 'en',

  init() {
    // Check saved preference or default to English
    const saved = localStorage.getItem('unknown_culprit_lang');
    if (saved === 'en' || saved === 'ar') {
      this.currentLang = saved;
    } else {
      this.currentLang = 'en';
      localStorage.setItem('unknown_culprit_lang', 'en');
    }
    this.applyLanguage(this.currentLang, false);
  },

  getLang() {
    return this.currentLang;
  },

  isRTL() {
    return this.currentLang === 'ar';
  },

  t(key, params = {}) {
    const dict = I18N_DATA[this.currentLang] || I18N_DATA.en;
    let text = dict[key] || I18N_DATA.en[key] || I18N_DATA.ar[key] || key;
    if (typeof text === 'string') {
      for (const [paramKey, paramVal] of Object.entries(params)) {
        text = text.replace(new RegExp(`\\{${paramKey}\\}`, 'g'), paramVal);
      }
    }
    return text;
  },

  setLanguage(lang) {
    if (lang !== 'ar' && lang !== 'en') return;
    if (this.currentLang === lang) return;
    this.currentLang = lang;
    localStorage.setItem('unknown_culprit_lang', lang);
    this.applyLanguage(lang, true);
  },

  toggleLanguage() {
    const nextLang = this.currentLang === 'ar' ? 'en' : 'ar';
    this.setLanguage(nextLang);
    return nextLang;
  },

  applyLanguage(lang, triggerRerender = true) {
    const isEn = lang === 'en';
    const htmlEl = document.documentElement;
    const bodyEl = document.body;

    // Update document attributes
    htmlEl.setAttribute('lang', lang);
    htmlEl.setAttribute('dir', isEn ? 'ltr' : 'rtl');

    if (isEn) {
      bodyEl.classList.add('lang-en');
      bodyEl.classList.remove('lang-ar');
    } else {
      bodyEl.classList.add('lang-ar');
      bodyEl.classList.remove('lang-en');
    }

    // Update static DOM elements with data-i18n attributes
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (key) {
        el.textContent = this.t(key);
      }
    });

    // Update placeholders with data-i18n-placeholder
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (key) {
        el.setAttribute('placeholder', this.t(key));
      }
    });

    // Update titles / tooltips with data-i18n-title
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
      const key = el.getAttribute('data-i18n-title');
      if (key) {
        el.setAttribute('title', this.t(key));
      }
    });

    // Update Language Toggle Button Displays
    document.querySelectorAll('.btn-lang-toggle-text, .noir-lang-title').forEach(el => {
      el.textContent = isEn ? 'العربية' : 'English';
    });
    document.querySelectorAll('.btn-lang-flag, .noir-lang-flag').forEach(el => {
      el.textContent = isEn ? '🇸🇦' : '🇬🇧';
    });

    // Update title
    document.title = isEn ? "UNKNOWN CULPRIT - Mystery Detective" : "الجاني مجهول - UNKNOWN CULPRIT";

    // Notify game engine to refresh dynamic case views
    if (triggerRerender && typeof window.onLanguageChanged === 'function') {
      window.onLanguageChanged(lang);
    }
  }
};

// Global helper alias
if (typeof window !== 'undefined') {
  window.t = (key, params) => I18nManager.t(key, params);
  window.I18nManager = I18nManager;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { I18nManager, I18N_DATA };
}
