const fs = require('fs');
const path = require('path');

const levelsPath = path.join(__dirname, 'levels.json');
const levelsDataPath = path.join(__dirname, 'levels_data.js');

let raw = fs.readFileSync(levelsPath, 'utf8');
if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
const levels = JSON.parse(raw);

// Female name detection
const FEMALE_HINTS = [
  'عبير', 'آية', 'نور', 'ريم', 'سارة', 'هناء', 'رانيا', 'ندى', 'لمى', 'إيمان', 'دينا', 'هدى', 'منى',
  'سمر', 'رشا', 'غادة', 'مريم', 'أميرة', 'ياسمين', 'روان', 'لينا', 'هبة', 'شيرين', 'نيفين', 'فاطمة',
  'زينب', 'أسماء', 'خديجة', 'عائشة', 'حنان', 'سحر', 'ابتسام', 'إبتسام', 'وفاء', 'سهام', 'هالة',
  'أمل', 'شيماء', 'ناهد', 'فايزة', 'فريدة', 'إلهام', 'راندا', 'إنجي', 'ميرنا', 'شادية', 'نيللي',
  'نيلي', 'لوسي', 'دعاء', 'رحاب', 'أروى', 'ألاء', 'علا', 'ولاء', 'نجلاء', 'سلمى', 'ليلى', 'نهى',
  'ميار', 'ميس', 'رنا', 'تالا', 'جنى', 'لارا', 'لارة', 'دلال', 'أفنان', 'رغد', 'ريف', 'ريهام',
  'شهد', 'كوثر', 'بسمة', 'بسمه', 'هيا', 'هيام', 'أهداف', 'نادية', 'نرمين', 'منال', 'مروة', 'مها',
  'نادين', 'كريمة', 'حليمة', 'حسناء', 'فاتن', 'فاتنة', 'صفاء', 'سناء', 'سمية', 'سميرة', 'صباح',
  'لبنى', 'لمار', 'رهف', 'لانا', 'تغريد', 'وفاء', 'خلود', 'سلوى', 'مي'
];

function isFemale(name) {
  if (!name) return false;
  const n = name.trim();
  const first = n.split(' ')[0];
  if (first.endsWith('ة') || first.endsWith('ى') || first.endsWith('اء')) return true;
  return FEMALE_HINTS.some(h => n.includes(h));
}

// Consistent realistic character mapping
const nameToImageMap = new Map();

function getRealisticImage(suspectName, suspectRole) {
  const nameKey = (suspectName || '').trim();
  if (nameToImageMap.has(nameKey)) {
    return nameToImageMap.get(nameKey);
  }

  const role = (suspectRole || '').trim();
  const female = isFemale(suspectName);

  let chosenImg = '';

  // 1. Precise Role Mapping
  if (role.includes('خادمة') || role.includes('مدبرة') || role.includes('مربية')) {
    chosenImg = 'images/char_maid.png';
  } else if (role.includes('نظافة') || role.includes('فراش') || role.includes('بواب')) {
    chosenImg = 'images/char_cleaner.png';
  } else if (role.includes('طباخ') || role.includes('شيف') || role.includes('نادل')) {
    chosenImg = 'images/char_chef.png';
  } else if (role.includes('محاسب') || role.includes('مالي') || role.includes('حسابات') || role.includes('خزينة')) {
    chosenImg = 'images/char_accountant.png';
  } else if (role.includes('سائق') || role.includes('أجرة') || role.includes('تاكسي')) {
    chosenImg = 'images/char_17.png';
  } else if (role.includes('كمبيوتر') || role.includes('تقني') || role.includes('معلومات') || role.includes('مطوّر') || role.includes('مبرمج') || role.includes('هاكر')) {
    if (female) {
      chosenImg = 'images/char_14f.png';
    } else {
      chosenImg = 'images/char_16.png';
    }
  } else if (role.includes('طبيب') || role.includes('دكتور') || role.includes('صيدل') || role.includes('شرعي')) {
    chosenImg = 'images/char_18.png';
  } else if (role.includes('أرشيف') || role.includes('مكتبة') || role.includes('سجلات')) {
    chosenImg = 'images/char_19.png';
  } else if (role.includes('آثار') || role.includes('سياحة') || role.includes('استقبال')) {
    chosenImg = 'images/char_11f.png';
  } else if (role.includes('حارس') || role.includes('أمن') || role.includes('حراسة') || role.includes('شخصي')) {
    if (role.includes('متحف') || role.includes('عقار')) {
      chosenImg = 'images/char_12.png';
    } else {
      chosenImg = 'images/char_guard.png';
    }
  } else if (role.includes('سكرتير') || role.includes('مساعد') || role.includes('مديرة مكتب')) {
    if (female) {
      chosenImg = 'images/char_2f.png';
    } else {
      chosenImg = 'images/char_1.png';
    }
  } else if (role.includes('تأمين') || role.includes('مشتريات') || role.includes('أمن معلوماتي')) {
    chosenImg = female ? 'images/char_9f.png' : 'images/char_16.png';
  } else if (role.includes('صديقة') || role.includes('شريكة')) {
    chosenImg = female ? 'images/char_13f.png' : 'images/char_3.png';
  } else if (role.includes('عميل ثري') || role.includes('مجوهرات') || role.includes('موزع')) {
    chosenImg = 'images/char_4.png';
  } else if (role.includes('محقق خاص')) {
    chosenImg = 'images/char_15.png';
  } else if (role.includes('منافس') || role.includes('قاتل') || role.includes('مشبوه')) {
    chosenImg = 'images/char_20.png';
  } else if (role.includes('نائب المدير') || role.includes('الشريك التجاري') || role.includes('الشريك في الصفقة') || role.includes('الشريك المقرّب')) {
    chosenImg = female ? 'images/char_7f.png' : 'images/char_3.png';
  } else {
    // Fallback pool by gender
    if (female) {
      const femalePool = ['images/char_2f.png', 'images/char_7f.png', 'images/char_9f.png', 'images/char_11f.png', 'images/char_13f.png', 'images/char_14f.png', 'images/char_maid.png'];
      let hash = 0;
      for (let i = 0; i < nameKey.length; i++) hash += nameKey.charCodeAt(i);
      chosenImg = femalePool[hash % femalePool.length];
    } else {
      const malePool = ['images/char_1.png', 'images/char_3.png', 'images/char_4.png', 'images/char_5.png', 'images/char_6.png', 'images/char_8.png', 'images/char_10.png', 'images/char_12.png', 'images/char_15.png', 'images/char_16.png', 'images/char_17.png', 'images/char_18.png', 'images/char_19.png', 'images/char_20.png', 'images/char_guard.png', 'images/char_accountant.png', 'images/char_cleaner.png', 'images/char_chef.png'];
      let hash = 0;
      for (let i = 0; i < nameKey.length; i++) hash += nameKey.charCodeAt(i);
      chosenImg = malePool[hash % malePool.length];
    }
  }

  nameToImageMap.set(nameKey, chosenImg);
  return chosenImg;
}

// Update all 100 cases
levels.forEach(lvl => {
  if (!lvl.suspects || !Array.isArray(lvl.suspects)) return;
  lvl.suspects.forEach(s => {
    s.image = getRealisticImage(s.name, s.role);
  });
});

// Save levels.json and levels_data.js
const jsonStr = JSON.stringify(levels, null, 2);
fs.writeFileSync(levelsPath, jsonStr, 'utf8');
fs.writeFileSync(levelsDataPath, `window.PRELOADED_LEVELS = ${jsonStr};`, 'utf8');

console.log('Successfully mapped all 300 suspects to realistic character photos across all 100 cases!');
