/* ═══════════════════════════════════════════════════════════
   🕵️ UNKNOWN CULPRIT - FULL ENGLISH CASE FILES (100 CASES)
   ═══════════════════════════════════════════════════════════ */

window.PRELOADED_LEVELS_EN = [
  {
    "level": 1,
    "title": "Case 1: The Poisoning at Mediterranean Shipping Co. Executive Office",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Wael Awad",
    "sceneLocation": "Mediterranean Shipping Co. Executive Office",
    "description": "Wael Awad was found dead inside Mediterranean Shipping Co. Executive Office from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "Abeer El-Hakim",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: Mediterranean Shipping Co. Executive Office corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary Abeer El-Hakim orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Abeer El-Hakim",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Mediterranean Shipping Co. Executive Office when the incident took place.",
        "image": "images/suspects/level_1_suspect_1.jpg"
      },
      {
        "name": "Hany Matar",
        "role": "Deputy Managing Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_1_suspect_2.jpg"
      },
      {
        "name": "Moustafa Rashwan",
        "role": "Financial Accountant",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_1_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 2,
    "title": "Case 2: The Heist at Nubian Museum in Aswan",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "Diamond Isis Necklace",
    "sceneLocation": "Nubian Museum in Aswan",
    "description": "A high-value asset was stolen from Nubian Museum in Aswan during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Fady Sarhan",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Fady Sarhan orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Aya El-Sharkawy",
        "role": "Antiquities & Tourism Expert",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_2_suspect_1.jpg"
      },
      {
        "name": "Adel El-Haddad",
        "role": "Sanitation Worker",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_2_suspect_2.jpg"
      },
      {
        "name": "Fady Sarhan",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nubian Museum in Aswan when the incident took place.",
        "image": "images/suspects/level_2_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 3,
    "title": "Case 3: The Abduction of Ghadir Awad",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Ghadir Awad",
    "sceneLocation": "International Airport VIP Lounge",
    "description": "Ghadir Awad was ambushed and abducted outside International Airport VIP Lounge. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Sameh El-Qady",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Sameh El-Qady orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Nasser El-Badry",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_3_suspect_1.jpg"
      },
      {
        "name": "Sameh El-Qady",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from International Airport VIP Lounge when the incident took place.",
        "image": "images/suspects/level_3_suspect_2.jpg"
      },
      {
        "name": "Mona El-Hakim",
        "role": "Office Manager",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_3_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 4,
    "title": "Case 4: The Heist at Nile Contracting Headquarters",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Moustafa El-Deeb",
    "sceneLocation": "Nile Contracting Headquarters",
    "description": "Millions in classified capital have vanished from corporate accounts at Nile Contracting Headquarters. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Saeed Selim",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Saeed Selim orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Saeed Selim",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nile Contracting Headquarters when the incident took place.",
        "image": "images/suspects/level_4_suspect_1.jpg"
      },
      {
        "name": "Youssef Abdelrahman",
        "role": "IT Department Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_4_suspect_2.jpg"
      },
      {
        "name": "Layla Ghoneim",
        "role": "Procurement Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_4_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 5,
    "title": "Case 5: The Arson Conspiracy at Grand Cargo Terminal & Warehouse",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "Sameh Mansour",
    "sceneLocation": "Grand Cargo Terminal & Warehouse",
    "description": "A catastrophic fire engulfed Grand Cargo Terminal & Warehouse. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Adel El-Tohamy",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Adel El-Tohamy orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Adel El-Tohamy",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Grand Cargo Terminal & Warehouse when the incident took place.",
        "image": "images/suspects/level_5_suspect_1.jpg"
      },
      {
        "name": "Ola Shaheen",
        "role": "Insurance Claims Officer",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_5_suspect_2.jpg"
      },
      {
        "name": "Tarek El-Garhy",
        "role": "حارس سابق مفصول",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_5_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 6,
    "title": "Case 6: The Mystery of Eman El-Sayed at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Eman El-Sayed",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Eman El-Sayed. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Saeed El-شرقاوي",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Saeed El-شرقاوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "رنا عبد El-رحمن",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_6_suspect_1.jpg"
      },
      {
        "name": "Saeed El-شرقاوي",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_6_suspect_2.jpg"
      },
      {
        "name": "Hossam حجاب",
        "role": "محقق خاص سابق",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_6_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 7,
    "title": "Case 7: The Heist at بوتيك El-Amira بالتجمع",
    "crimeType": "Grand Theft & Heist",
    "victimName": "بوتيك El-Amira بالتجمع",
    "sceneLocation": "بوتيك El-Amira بالتجمع",
    "description": "A high-value asset was stolen from بوتيك El-Amira بالتجمع during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Tarek El-خوري",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: بوتيك El-Amira بالتجمع corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Tarek El-خوري orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Hossam زهران",
        "role": "موزع بضائع المجوهرات",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_7_suspect_1.jpg"
      },
      {
        "name": "Layla شاهين",
        "role": "موظفة الاستقبال",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_7_suspect_2.jpg"
      },
      {
        "name": "Tarek El-خوري",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from بوتيك El-Amira بالتجمع when the incident took place.",
        "image": "images/suspects/level_7_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 8,
    "title": "Case 8: The Heist at مقر شركة El-بحر El-متوسط للشحن",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Karim El-شرقاوي",
    "sceneLocation": "مقر شركة El-بحر El-متوسط للشحن",
    "description": "A high-value asset was stolen from مقر شركة El-بحر El-متوسط للشحن during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Tarek عبد El-له",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Tarek عبد El-له orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Mohamed El-خوري",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_8_suspect_1.jpg"
      },
      {
        "name": "رنا El-شناوي",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_8_suspect_2.jpg"
      },
      {
        "name": "Tarek عبد El-له",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر شركة El-بحر El-متوسط للشحن when the incident took place.",
        "image": "images/suspects/level_8_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 9,
    "title": "Case 9: The Mystery of Ehab رشوان at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Ehab رشوان",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Ehab رشوان. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Khaled El-حكيم",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Khaled El-حكيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Saeed El-جارحي",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_9_suspect_1.jpg"
      },
      {
        "name": "فاطمة El-شافعي",
        "role": "المساعدة الشخصية",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_9_suspect_2.jpg"
      },
      {
        "name": "Khaled El-حكيم",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_9_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 10,
    "title": "Case 10: The Heist at شاليه El-ساحل El-شمالي",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Tarek عوض",
    "sceneLocation": "شاليه El-ساحل El-شمالي",
    "description": "A high-value asset was stolen from شاليه El-ساحل El-شمالي during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Belal El-Sayed",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Belal El-Sayed orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "منير سرحان",
        "role": "حارس العقار",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_10_suspect_1.jpg"
      },
      {
        "name": "Belal El-Sayed",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شاليه El-ساحل El-شمالي when the incident took place.",
        "image": "images/suspects/level_10_suspect_2.jpg"
      },
      {
        "name": "ولاء حماد",
        "role": "الخادمة الخاصة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_10_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 11,
    "title": "Case 11: The Poisoning at مكتب رئيس بنك El-أفق El-دولي",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Maged El-شرقاوي",
    "sceneLocation": "مكتب رئيس بنك El-أفق El-دولي",
    "description": "Maged El-شرقاوي was found dead inside مكتب رئيس بنك El-أفق El-دولي from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "شيرين زهران",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس بنك El-أفق El-دولي corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary شيرين زهران orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Belal El-حكيم",
        "role": "Deputy Managing Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_11_suspect_1.jpg"
      },
      {
        "name": "عماد El-Sayed",
        "role": "Financial Accountant",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_11_suspect_2.jpg"
      },
      {
        "name": "شيرين زهران",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس بنك El-أفق El-دولي when the incident took place.",
        "image": "images/suspects/level_11_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 12,
    "title": "Case 12: The Heist at Nubian Museum in Aswan",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "تمثال نفرتيتي El-ذهبي",
    "sceneLocation": "Nubian Museum in Aswan",
    "description": "A high-value asset was stolen from Nubian Museum in Aswan during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Khaled حماد",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Khaled حماد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Khaled حماد",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nubian Museum in Aswan when the incident took place.",
        "image": "images/suspects/level_12_suspect_1.jpg"
      },
      {
        "name": "Sherif سرحان",
        "role": "Sanitation Worker",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_12_suspect_2.jpg"
      },
      {
        "name": "فاطمة درويش",
        "role": "Antiquities & Tourism Expert",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_12_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 13,
    "title": "Case 13: The Abduction of Dina El-قاضي",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Dina El-قاضي",
    "sceneLocation": "فندق El-نيل هيلتون",
    "description": "Dina El-قاضي was ambushed and abducted outside فندق El-نيل هيلتون. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Hany El-شرقاوي",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Hany El-شرقاوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Salma El-حكيم",
        "role": "Office Manager",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_13_suspect_1.jpg"
      },
      {
        "name": "Selim El-خوري",
        "role": "Personal Bodyguard",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_13_suspect_2.jpg"
      },
      {
        "name": "Hany El-شرقاوي",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from فندق El-نيل هيلتون when the incident took place.",
        "image": "images/suspects/level_13_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 14,
    "title": "Case 14: The Heist at Nile Contracting Headquarters",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Khaled El-حداد",
    "sceneLocation": "Nile Contracting Headquarters",
    "description": "Millions in classified capital have vanished from corporate accounts at Nile Contracting Headquarters. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Youssef راضي",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Youssef راضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Youssef راضي",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nile Contracting Headquarters when the incident took place.",
        "image": "images/suspects/level_14_suspect_1.jpg"
      },
      {
        "name": "Ramy El-رشيد",
        "role": "IT Department Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_14_suspect_2.jpg"
      },
      {
        "name": "لمار El-Amir",
        "role": "Procurement Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_14_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 15,
    "title": "Case 15: The Arson Conspiracy at Grand Cargo Terminal & Warehouse",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "منير Selim",
    "sceneLocation": "Grand Cargo Terminal & Warehouse",
    "description": "A catastrophic fire engulfed Grand Cargo Terminal & Warehouse. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Hany El-جارحي",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Hany El-جارحي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لمار El-Amir",
        "role": "Insurance Claims Officer",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_15_suspect_1.jpg"
      },
      {
        "name": "Hany El-جارحي",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Grand Cargo Terminal & Warehouse when the incident took place.",
        "image": "images/suspects/level_15_suspect_2.jpg"
      },
      {
        "name": "Adel حجاب",
        "role": "حارس سابق مفصول",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_15_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 16,
    "title": "Case 16: The Mystery of Sameh El-بدري at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Sameh El-بدري",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Sameh El-بدري. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "جمال مطر",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب جمال مطر orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Sherif El-شناوي",
        "role": "محقق خاص سابق",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_16_suspect_1.jpg"
      },
      {
        "name": "جمال مطر",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_16_suspect_2.jpg"
      },
      {
        "name": "Yasmine حماد",
        "role": "الصديقة المقرّبة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_16_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 17,
    "title": "Case 17: The Heist at محل El-جوهرجي بالخان",
    "crimeType": "Grand Theft & Heist",
    "victimName": "محل El-جوهرجي بالخان",
    "sceneLocation": "محل El-جوهرجي بالخان",
    "description": "A high-value asset was stolen from محل El-جوهرجي بالخان during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Ehab عوض",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: محل El-جوهرجي بالخان corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Ehab عوض orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Moustafa El-شناوي",
        "role": "موزع بضائع المجوهرات",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_17_suspect_1.jpg"
      },
      {
        "name": "Ehab عوض",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from محل El-جوهرجي بالخان when the incident took place.",
        "image": "images/suspects/level_17_suspect_2.jpg"
      },
      {
        "name": "مريم رشوان",
        "role": "موظفة الاستقبال",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_17_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 18,
    "title": "Case 18: The Heist at مقر شركة لوتس للاستيراد",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Selim رشوان",
    "sceneLocation": "مقر شركة لوتس للاستيراد",
    "description": "A high-value asset was stolen from مقر شركة لوتس للاستيراد during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "عماد درويش",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة عماد درويش orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "عماد درويش",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر شركة لوتس للاستيراد when the incident took place.",
        "image": "images/suspects/level_18_suspect_1.jpg"
      },
      {
        "name": "Belal El-خوري",
        "role": "المدير التقني",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_18_suspect_2.jpg"
      },
      {
        "name": "لبنى راضي",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_18_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 19,
    "title": "Case 19: The Mystery of لؤي El-جارحي at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "لؤي El-جارحي",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving لؤي El-جارحي. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Sherif El-حكيم",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Sherif El-حكيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Sherif El-حكيم",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_19_suspect_1.jpg"
      },
      {
        "name": "Sameh حجاب",
        "role": "Personal Bodyguard",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_19_suspect_2.jpg"
      },
      {
        "name": "Nada El-Amir",
        "role": "المساعدة الشخصية",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_19_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 20,
    "title": "Case 20: The Heist at قصر El-مقطم",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Wael El-تهامي",
    "sceneLocation": "قصر El-مقطم",
    "description": "A high-value asset was stolen from قصر El-مقطم during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Hany عبد El-له",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Hany عبد El-له orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Hany عبد El-له",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from قصر El-مقطم when the incident took place.",
        "image": "images/suspects/level_20_suspect_1.jpg"
      },
      {
        "name": "Nour El-تهامي",
        "role": "الخادمة الخاصة",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_20_suspect_2.jpg"
      },
      {
        "name": "منير El-Sayed",
        "role": "حارس العقار",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_20_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 21,
    "title": "Case 21: The Poisoning at Mediterranean Shipping Co. Executive Office",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Ehab El-شناوي",
    "sceneLocation": "Mediterranean Shipping Co. Executive Office",
    "description": "Ehab El-شناوي was found dead inside Mediterranean Shipping Co. Executive Office from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "Nada El-شناوي",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: Mediterranean Shipping Co. Executive Office corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary Nada El-شناوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Ahmed عوض",
        "role": "Financial Accountant",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_21_suspect_1.jpg"
      },
      {
        "name": "Nada El-شناوي",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Mediterranean Shipping Co. Executive Office when the incident took place.",
        "image": "images/suspects/level_21_suspect_2.jpg"
      },
      {
        "name": "Omar مطر",
        "role": "Deputy Managing Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_21_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 22,
    "title": "Case 22: The Heist at Nubian Museum in Aswan",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "طبق El-فرعون El-أزرق",
    "sceneLocation": "Nubian Museum in Aswan",
    "description": "A high-value asset was stolen from Nubian Museum in Aswan during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Saeed حماد",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Saeed حماد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "شادي حماد",
        "role": "Sanitation Worker",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_22_suspect_1.jpg"
      },
      {
        "name": "Saeed حماد",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nubian Museum in Aswan when the incident took place.",
        "image": "images/suspects/level_22_suspect_2.jpg"
      },
      {
        "name": "Noha درويش",
        "role": "Antiquities & Tourism Expert",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_22_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 23,
    "title": "Case 23: The Abduction of Hany El-ديب",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Hany El-ديب",
    "sceneLocation": "منتجع سيناء El-سياحي",
    "description": "Hany El-ديب was ambushed and abducted outside منتجع سيناء El-سياحي. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "عماد El-فيومي",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur عماد El-فيومي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لبنى رشوان",
        "role": "Office Manager",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_23_suspect_1.jpg"
      },
      {
        "name": "عماد El-فيومي",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منتجع سيناء El-سياحي when the incident took place.",
        "image": "images/suspects/level_23_suspect_2.jpg"
      },
      {
        "name": "Saeed El-Amir",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_23_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 24,
    "title": "Case 24: The Heist at Nile Contracting Headquarters",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Karim El-رشيد",
    "sceneLocation": "Nile Contracting Headquarters",
    "description": "Millions in classified capital have vanished from corporate accounts at Nile Contracting Headquarters. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "عماد درويش",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant عماد درويش orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "عماد درويش",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nile Contracting Headquarters when the incident took place.",
        "image": "images/suspects/level_24_suspect_1.jpg"
      },
      {
        "name": "Ahmed حماد",
        "role": "IT Department Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_24_suspect_2.jpg"
      },
      {
        "name": "ولاء درويش",
        "role": "Procurement Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_24_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 25,
    "title": "Case 25: The Arson Conspiracy at مكتبة El-تراث El-قديمة",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "Maged شاهين",
    "sceneLocation": "مكتبة El-تراث El-قديمة",
    "description": "A catastrophic fire engulfed مكتبة El-تراث El-قديمة. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "عماد El-حكيم",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor عماد El-حكيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Moustafa El-Sayed",
        "role": "حارس سابق مفصول",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_25_suspect_1.jpg"
      },
      {
        "name": "Salma راضي",
        "role": "Insurance Claims Officer",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_25_suspect_2.jpg"
      },
      {
        "name": "عماد El-حكيم",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتبة El-تراث El-قديمة when the incident took place.",
        "image": "images/suspects/level_25_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 26,
    "title": "Case 26: The Mystery of Belal El-Sayed at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Belal El-Sayed",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Belal El-Sayed. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Hany El-بدري",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Hany El-بدري orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Reem مطر",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_26_suspect_1.jpg"
      },
      {
        "name": "Adel راضي",
        "role": "محقق خاص سابق",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_26_suspect_2.jpg"
      },
      {
        "name": "Hany El-بدري",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_26_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 27,
    "title": "Case 27: The Heist at مجوهرات El-ملك بالمهندسين",
    "crimeType": "Grand Theft & Heist",
    "victimName": "مجوهرات El-ملك بالمهندسين",
    "sceneLocation": "مجوهرات El-ملك بالمهندسين",
    "description": "A high-value asset was stolen from مجوهرات El-ملك بالمهندسين during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Moustafa عوض",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: مجوهرات El-ملك بالمهندسين corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Moustafa عوض orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Aya حجاب",
        "role": "موظفة الاستقبال",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_27_suspect_1.jpg"
      },
      {
        "name": "Moustafa عوض",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مجوهرات El-ملك بالمهندسين when the incident took place.",
        "image": "images/suspects/level_27_suspect_2.jpg"
      },
      {
        "name": "Hany حماد",
        "role": "موزع بضائع المجوهرات",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_27_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 28,
    "title": "Case 28: The Heist at مقر شركة لوتس للاستيراد",
    "crimeType": "Grand Theft & Heist",
    "victimName": "منير El-فيومي",
    "sceneLocation": "مقر شركة لوتس للاستيراد",
    "description": "A high-value asset was stolen from مقر شركة لوتس للاستيراد during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "باسل منصور",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة باسل منصور orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Ehab عوض",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_28_suspect_1.jpg"
      },
      {
        "name": "باسل منصور",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر شركة لوتس للاستيراد when the incident took place.",
        "image": "images/suspects/level_28_suspect_2.jpg"
      },
      {
        "name": "Nada El-حكيم",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_28_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 29,
    "title": "Case 29: The Mystery of شادي منصور at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "شادي منصور",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving شادي منصور. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Omar غنيم",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Omar غنيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Nada El-شناوي",
        "role": "المساعدة الشخصية",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_29_suspect_1.jpg"
      },
      {
        "name": "Omar غنيم",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_29_suspect_2.jpg"
      },
      {
        "name": "Ramy غنيم",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_29_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 30,
    "title": "Case 30: The Heist at منزل El-تجمع El-خامس",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Moustafa غنيم",
    "sceneLocation": "منزل El-تجمع El-خامس",
    "description": "A high-value asset was stolen from منزل El-تجمع El-خامس during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Ramy زهران",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Ramy زهران orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "علا El-خوري",
        "role": "الخادمة الخاصة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_30_suspect_1.jpg"
      },
      {
        "name": "Ramy زهران",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-تجمع El-خامس when the incident took place.",
        "image": "images/suspects/level_30_suspect_2.jpg"
      },
      {
        "name": "Ehab عبد El-رحمن",
        "role": "حارس العقار",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_30_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 31,
    "title": "Case 31: The Poisoning at مكتب رئيس شركة El-نيل للمقاولات",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Ehab El-شافعي",
    "sceneLocation": "مكتب رئيس شركة El-نيل للمقاولات",
    "description": "Ehab El-شافعي was found dead inside مكتب رئيس شركة El-نيل للمقاولات from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "Nada مطر",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس شركة El-نيل للمقاولات corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary Nada مطر orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Tarek غنيم",
        "role": "Financial Accountant",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_31_suspect_1.jpg"
      },
      {
        "name": "Nada مطر",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس شركة El-نيل للمقاولات when the incident took place.",
        "image": "images/suspects/level_31_suspect_2.jpg"
      },
      {
        "name": "Hany El-شرقاوي",
        "role": "Deputy Managing Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_31_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 32,
    "title": "Case 32: The Heist at El-متحف El-مصري El-كبير بالجيزة",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "Diamond Isis Necklace",
    "sceneLocation": "El-متحف El-مصري El-كبير بالجيزة",
    "description": "A high-value asset was stolen from El-متحف El-مصري El-كبير بالجيزة during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Sherif حماد",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Sherif حماد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Hany Selim",
        "role": "Sanitation Worker",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_32_suspect_1.jpg"
      },
      {
        "name": "Layla El-تهامي",
        "role": "Antiquities & Tourism Expert",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_32_suspect_2.jpg"
      },
      {
        "name": "Sherif حماد",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from El-متحف El-مصري El-كبير بالجيزة when the incident took place.",
        "image": "images/suspects/level_32_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 33,
    "title": "Case 33: The Abduction of Ziad سرحان",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Ziad سرحان",
    "sceneLocation": "منتجع سيناء El-سياحي",
    "description": "Ziad سرحان was ambushed and abducted outside منتجع سيناء El-سياحي. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Wael El-رشيد",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Wael El-رشيد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Saeed El-حداد",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_33_suspect_1.jpg"
      },
      {
        "name": "Noha عبد El-رحمن",
        "role": "Office Manager",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_33_suspect_2.jpg"
      },
      {
        "name": "Wael El-رشيد",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منتجع سيناء El-سياحي when the incident took place.",
        "image": "images/suspects/level_33_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 34,
    "title": "Case 34: The Heist at مقر مجموعة El-فجر El-عقارية",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Karim زهران",
    "sceneLocation": "مقر مجموعة El-فجر El-عقارية",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر مجموعة El-فجر El-عقارية. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Khaled رشوان",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Khaled رشوان orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Selim شاهين",
        "role": "IT Department Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_34_suspect_1.jpg"
      },
      {
        "name": "Abeer رشوان",
        "role": "Procurement Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_34_suspect_2.jpg"
      },
      {
        "name": "Khaled رشوان",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مجموعة El-فجر El-عقارية when the incident took place.",
        "image": "images/suspects/level_34_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 35,
    "title": "Case 35: The Arson Conspiracy at مقر El-شركة El-منافسة",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "شادي حماد",
    "sceneLocation": "مقر El-شركة El-منافسة",
    "description": "A catastrophic fire engulfed مقر El-شركة El-منافسة. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Youssef زهران",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Youssef زهران orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "مي El-جارحي",
        "role": "Insurance Claims Officer",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_35_suspect_1.jpg"
      },
      {
        "name": "Belal El-ديب",
        "role": "حارس سابق مفصول",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_35_suspect_2.jpg"
      },
      {
        "name": "Youssef زهران",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر El-شركة El-منافسة when the incident took place.",
        "image": "images/suspects/level_35_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 36,
    "title": "Case 36: The Mystery of Ehab El-شرقاوي at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Ehab El-شرقاوي",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Ehab El-شرقاوي. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "لؤي El-قاضي",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب لؤي El-قاضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "رهف El-حداد",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_36_suspect_1.jpg"
      },
      {
        "name": "لؤي El-قاضي",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_36_suspect_2.jpg"
      },
      {
        "name": "شادي El-Sayed",
        "role": "محقق خاص سابق",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_36_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 37,
    "title": "Case 37: The Heist at مجوهرات El-ملك بالمهندسين",
    "crimeType": "Grand Theft & Heist",
    "victimName": "مجوهرات El-ملك بالمهندسين",
    "sceneLocation": "مجوهرات El-ملك بالمهندسين",
    "description": "A high-value asset was stolen from مجوهرات El-ملك بالمهندسين during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Ziad حجاب",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: مجوهرات El-ملك بالمهندسين corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Ziad حجاب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "شادي حجاب",
        "role": "موزع بضائع المجوهرات",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_37_suspect_1.jpg"
      },
      {
        "name": "Yasmine درويش",
        "role": "موظفة الاستقبال",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_37_suspect_2.jpg"
      },
      {
        "name": "Ziad حجاب",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مجوهرات El-ملك بالمهندسين when the incident took place.",
        "image": "images/suspects/level_37_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 38,
    "title": "Case 38: The Heist at مقر شركة أمازون El-شرق للتقنية",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Khaled حماد",
    "sceneLocation": "مقر شركة أمازون El-شرق للتقنية",
    "description": "A high-value asset was stolen from مقر شركة أمازون El-شرق للتقنية during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Belal El-Amir",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Belal El-Amir orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "منير عبد El-له",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_38_suspect_1.jpg"
      },
      {
        "name": "Belal El-Amir",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر شركة أمازون El-شرق للتقنية when the incident took place.",
        "image": "images/suspects/level_38_suspect_2.jpg"
      },
      {
        "name": "لانا El-تهامي",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_38_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 39,
    "title": "Case 39: The Mystery of Selim مطر at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Selim مطر",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Selim مطر. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Khaled El-Amir",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Khaled El-Amir orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Sawsan El-بدري",
        "role": "المساعدة الشخصية",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_39_suspect_1.jpg"
      },
      {
        "name": "Khaled El-Amir",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_39_suspect_2.jpg"
      },
      {
        "name": "Karim El-قاضي",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_39_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 40,
    "title": "Case 40: The Heist at شقة El-زمالك El-فاخرة",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Wael عبد El-رحمن",
    "sceneLocation": "شقة El-زمالك El-فاخرة",
    "description": "A high-value asset was stolen from شقة El-زمالك El-فاخرة during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "لؤي حجاب",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner لؤي حجاب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لؤي حجاب",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شقة El-زمالك El-فاخرة when the incident took place.",
        "image": "images/suspects/level_40_suspect_1.jpg"
      },
      {
        "name": "Hany سرحان",
        "role": "حارس العقار",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_40_suspect_2.jpg"
      },
      {
        "name": "Noha عبد El-رحمن",
        "role": "الخادمة الخاصة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_40_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 41,
    "title": "Case 41: The Poisoning at مكتب رئيس مجموعة El-هرم El-قابضة",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Ahmed حجاب",
    "sceneLocation": "مكتب رئيس مجموعة El-هرم El-قابضة",
    "description": "Ahmed حجاب was found dead inside مكتب رئيس مجموعة El-هرم El-قابضة from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "مي El-قاضي",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس مجموعة El-هرم El-قابضة corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary مي El-قاضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "منير El-شرقاوي",
        "role": "Deputy Managing Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_41_suspect_1.jpg"
      },
      {
        "name": "Karim حجاب",
        "role": "Financial Accountant",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_41_suspect_2.jpg"
      },
      {
        "name": "مي El-قاضي",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس مجموعة El-هرم El-قابضة when the incident took place.",
        "image": "images/suspects/level_41_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 42,
    "title": "Case 42: The Heist at Nubian Museum in Aswan",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "تمثال نفرتيتي El-ذهبي",
    "sceneLocation": "Nubian Museum in Aswan",
    "description": "A high-value asset was stolen from Nubian Museum in Aswan during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Wael مطر",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Wael مطر orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Wael مطر",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nubian Museum in Aswan when the incident took place.",
        "image": "images/suspects/level_42_suspect_1.jpg"
      },
      {
        "name": "Ahmed El-جارحي",
        "role": "Sanitation Worker",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_42_suspect_2.jpg"
      },
      {
        "name": "Wafaa درويش",
        "role": "Antiquities & Tourism Expert",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_42_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 43,
    "title": "Case 43: The Abduction of رهف El-شافعي",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "رهف El-شافعي",
    "sceneLocation": "El-جامعة El-أهلية El-دولية",
    "description": "رهف El-شافعي was ambushed and abducted outside El-جامعة El-أهلية El-دولية. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Moustafa مطر",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Moustafa مطر orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Moustafa مطر",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from El-جامعة El-أهلية El-دولية when the incident took place.",
        "image": "images/suspects/level_43_suspect_1.jpg"
      },
      {
        "name": "Youssef Selim",
        "role": "Personal Bodyguard",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_43_suspect_2.jpg"
      },
      {
        "name": "Mona راضي",
        "role": "Office Manager",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_43_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 44,
    "title": "Case 44: The Heist at مقر بنك El-أفق El-دولي",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Tamer سرحان",
    "sceneLocation": "مقر بنك El-أفق El-دولي",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر بنك El-أفق El-دولي. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Selim سرحان",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Selim سرحان orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Selim سرحان",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر بنك El-أفق El-دولي when the incident took place.",
        "image": "images/suspects/level_44_suspect_1.jpg"
      },
      {
        "name": "Layla سرحان",
        "role": "Procurement Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_44_suspect_2.jpg"
      },
      {
        "name": "باسل El-حداد",
        "role": "IT Department Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_44_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 45,
    "title": "Case 45: The Arson Conspiracy at مقر El-شركة El-منافسة",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "جمال غنيم",
    "sceneLocation": "مقر El-شركة El-منافسة",
    "description": "A catastrophic fire engulfed مقر El-شركة El-منافسة. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Adel El-خوري",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Adel El-خوري orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "رهف El-شناوي",
        "role": "Insurance Claims Officer",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_45_suspect_1.jpg"
      },
      {
        "name": "Ehab El-بدري",
        "role": "حارس سابق مفصول",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_45_suspect_2.jpg"
      },
      {
        "name": "Adel El-خوري",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر El-شركة El-منافسة when the incident took place.",
        "image": "images/suspects/level_45_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 46,
    "title": "Case 46: The Mystery of Salma مطر at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Salma مطر",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Salma مطر. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Fady El-فيومي",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Fady El-فيومي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Amira El-Amir",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_46_suspect_1.jpg"
      },
      {
        "name": "Hossam El-جارحي",
        "role": "محقق خاص سابق",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_46_suspect_2.jpg"
      },
      {
        "name": "Fady El-فيومي",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_46_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 47,
    "title": "Case 47: The Heist at محل El-جوهرجي بالخان",
    "crimeType": "Grand Theft & Heist",
    "victimName": "محل El-جوهرجي بالخان",
    "sceneLocation": "محل El-جوهرجي بالخان",
    "description": "A high-value asset was stolen from محل El-جوهرجي بالخان during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Hany El-شناوي",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: محل El-جوهرجي بالخان corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Hany El-شناوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "مي راضي",
        "role": "موظفة الاستقبال",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_47_suspect_1.jpg"
      },
      {
        "name": "Hany El-شناوي",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from محل El-جوهرجي بالخان when the incident took place.",
        "image": "images/suspects/level_47_suspect_2.jpg"
      },
      {
        "name": "منير El-حكيم",
        "role": "موزع بضائع المجوهرات",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_47_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 48,
    "title": "Case 48: The Heist at Nile Contracting Headquarters",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Wael El-شناوي",
    "sceneLocation": "Nile Contracting Headquarters",
    "description": "A high-value asset was stolen from Nile Contracting Headquarters during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Ziad عبد El-له",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Ziad عبد El-له orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Omar Selim",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_48_suspect_1.jpg"
      },
      {
        "name": "Mona حجاب",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_48_suspect_2.jpg"
      },
      {
        "name": "Ziad عبد El-له",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nile Contracting Headquarters when the incident took place.",
        "image": "images/suspects/level_48_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 49,
    "title": "Case 49: The Mystery of عماد El-جارحي at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "عماد El-جارحي",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving عماد El-جارحي. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "منير حجاب",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة منير حجاب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "منير حجاب",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_49_suspect_1.jpg"
      },
      {
        "name": "Wael El-حداد",
        "role": "Personal Bodyguard",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_49_suspect_2.jpg"
      },
      {
        "name": "رنا El-رشيد",
        "role": "المساعدة الشخصية",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_49_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 50,
    "title": "Case 50: The Heist at شقة مصر El-جديدة El-كلاسيكية",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Fady El-شرقاوي",
    "sceneLocation": "شقة مصر El-جديدة El-كلاسيكية",
    "description": "A high-value asset was stolen from شقة مصر El-جديدة El-كلاسيكية during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "لؤي راضي",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner لؤي راضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لؤي راضي",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شقة مصر El-جديدة El-كلاسيكية when the incident took place.",
        "image": "images/suspects/level_50_suspect_1.jpg"
      },
      {
        "name": "Moustafa El-Amir",
        "role": "حارس العقار",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_50_suspect_2.jpg"
      },
      {
        "name": "Amira شاهين",
        "role": "الخادمة الخاصة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_50_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 51,
    "title": "Case 51: The Poisoning at مكتب رئيس شركة El-نيل للمقاولات",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "شادي El-حداد",
    "sceneLocation": "مكتب رئيس شركة El-نيل للمقاولات",
    "description": "شادي El-حداد was found dead inside مكتب رئيس شركة El-نيل للمقاولات from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "Mona El-جارحي",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس شركة El-نيل للمقاولات corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary Mona El-جارحي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Mona El-جارحي",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس شركة El-نيل للمقاولات when the incident took place.",
        "image": "images/suspects/level_51_suspect_1.jpg"
      },
      {
        "name": "Sameh راضي",
        "role": "Financial Accountant",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_51_suspect_2.jpg"
      },
      {
        "name": "شادي زهران",
        "role": "Deputy Managing Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_51_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 52,
    "title": "Case 52: The Heist at متحف El-حضارة بالفسطاط",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "Diamond Isis Necklace",
    "sceneLocation": "متحف El-حضارة بالفسطاط",
    "description": "A high-value asset was stolen from متحف El-حضارة بالفسطاط during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Ramy El-حداد",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Ramy El-حداد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "فاطمة El-بدري",
        "role": "Antiquities & Tourism Expert",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_52_suspect_1.jpg"
      },
      {
        "name": "Ehab عوض",
        "role": "Sanitation Worker",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_52_suspect_2.jpg"
      },
      {
        "name": "Ramy El-حداد",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from متحف El-حضارة بالفسطاط when the incident took place.",
        "image": "images/suspects/level_52_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 53,
    "title": "Case 53: The Abduction of Hany El-قاضي",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Hany El-قاضي",
    "sceneLocation": "El-جامعة El-أهلية El-دولية",
    "description": "Hany El-قاضي was ambushed and abducted outside El-جامعة El-أهلية El-دولية. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Omar El-حكيم",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Omar El-حكيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Ramy El-فيومي",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_53_suspect_1.jpg"
      },
      {
        "name": "Omar El-حكيم",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from El-جامعة El-أهلية El-دولية when the incident took place.",
        "image": "images/suspects/level_53_suspect_2.jpg"
      },
      {
        "name": "Dina منصور",
        "role": "Office Manager",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_53_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 54,
    "title": "Case 54: The Heist at مقر مصنع Salah El-دين للأدوية",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Youssef El-قاضي",
    "sceneLocation": "مقر مصنع Salah El-دين للأدوية",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر مصنع Salah El-دين للأدوية. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Ramy Selim",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Ramy Selim orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Adel Selim",
        "role": "IT Department Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_54_suspect_1.jpg"
      },
      {
        "name": "Mona زهران",
        "role": "Procurement Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_54_suspect_2.jpg"
      },
      {
        "name": "Ramy Selim",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مصنع Salah El-دين للأدوية when the incident took place.",
        "image": "images/suspects/level_54_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 55,
    "title": "Case 55: The Arson Conspiracy at Grand Cargo Terminal & Warehouse",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "لؤي El-Amir",
    "sceneLocation": "Grand Cargo Terminal & Warehouse",
    "description": "A catastrophic fire engulfed Grand Cargo Terminal & Warehouse. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Tamer El-حكيم",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Tamer El-حكيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Tamer El-حكيم",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Grand Cargo Terminal & Warehouse when the incident took place.",
        "image": "images/suspects/level_55_suspect_1.jpg"
      },
      {
        "name": "Nour El-Amir",
        "role": "Insurance Claims Officer",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_55_suspect_2.jpg"
      },
      {
        "name": "ناصر حجاب",
        "role": "حارس سابق مفصول",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_55_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 56,
    "title": "Case 56: The Mystery of Saeed El-Amir at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Saeed El-Amir",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Saeed El-Amir. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Mohamed El-جارحي",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Mohamed El-جارحي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Maged زهران",
        "role": "محقق خاص سابق",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_56_suspect_1.jpg"
      },
      {
        "name": "Mohamed El-جارحي",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_56_suspect_2.jpg"
      },
      {
        "name": "Dina El-حكيم",
        "role": "الصديقة المقرّبة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_56_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 57,
    "title": "Case 57: The Heist at بوتيك El-Amira بالتجمع",
    "crimeType": "Grand Theft & Heist",
    "victimName": "بوتيك El-Amira بالتجمع",
    "sceneLocation": "بوتيك El-Amira بالتجمع",
    "description": "A high-value asset was stolen from بوتيك El-Amira بالتجمع during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Tamer درويش",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: بوتيك El-Amira بالتجمع corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Tamer درويش orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Tamer درويش",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from بوتيك El-Amira بالتجمع when the incident took place.",
        "image": "images/suspects/level_57_suspect_1.jpg"
      },
      {
        "name": "لبنى El-حداد",
        "role": "موظفة الاستقبال",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_57_suspect_2.jpg"
      },
      {
        "name": "Moustafa El-قاضي",
        "role": "موزع بضائع المجوهرات",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_57_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 58,
    "title": "Case 58: The Heist at مقر مجموعة El-فجر El-عقارية",
    "crimeType": "Grand Theft & Heist",
    "victimName": "ناصر منصور",
    "sceneLocation": "مقر مجموعة El-فجر El-عقارية",
    "description": "A high-value asset was stolen from مقر مجموعة El-فجر El-عقارية during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Hossam درويش",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Hossam درويش orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Maged زهران",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_58_suspect_1.jpg"
      },
      {
        "name": "لبنى El-شافعي",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_58_suspect_2.jpg"
      },
      {
        "name": "Hossam درويش",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مجموعة El-فجر El-عقارية when the incident took place.",
        "image": "images/suspects/level_58_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 59,
    "title": "Case 59: The Mystery of Saeed El-قاضي at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Saeed El-قاضي",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Saeed El-قاضي. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Sameh درويش",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Sameh درويش orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Sameh درويش",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_59_suspect_1.jpg"
      },
      {
        "name": "Mohamed El-بدري",
        "role": "Personal Bodyguard",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_59_suspect_2.jpg"
      },
      {
        "name": "فاطمة حماد",
        "role": "المساعدة الشخصية",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_59_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 60,
    "title": "Case 60: The Heist at شاليه El-ساحل El-شمالي",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Ziad زهران",
    "sceneLocation": "شاليه El-ساحل El-شمالي",
    "description": "A high-value asset was stolen from شاليه El-ساحل El-شمالي during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "شادي عبد El-له",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner شادي عبد El-له orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لمار El-حداد",
        "role": "الخادمة الخاصة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_60_suspect_1.jpg"
      },
      {
        "name": "لؤي عبد El-رحمن",
        "role": "حارس العقار",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_60_suspect_2.jpg"
      },
      {
        "name": "شادي عبد El-له",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شاليه El-ساحل El-شمالي when the incident took place.",
        "image": "images/suspects/level_60_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 61,
    "title": "Case 61: The Poisoning at مكتب رئيس مجموعة El-هرم El-قابضة",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Tarek شاهين",
    "sceneLocation": "مكتب رئيس مجموعة El-هرم El-قابضة",
    "description": "Tarek شاهين was found dead inside مكتب رئيس مجموعة El-هرم El-قابضة from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "Mona عبد El-له",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس مجموعة El-هرم El-قابضة corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary Mona عبد El-له orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Sameh عبد El-له",
        "role": "Financial Accountant",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_61_suspect_1.jpg"
      },
      {
        "name": "Ziad منصور",
        "role": "Deputy Managing Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_61_suspect_2.jpg"
      },
      {
        "name": "Mona عبد El-له",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس مجموعة El-هرم El-قابضة when the incident took place.",
        "image": "images/suspects/level_61_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 62,
    "title": "Case 62: The Heist at El-متحف El-مصري El-كبير بالجيزة",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "تمثال نفرتيتي El-ذهبي",
    "sceneLocation": "El-متحف El-مصري El-كبير بالجيزة",
    "description": "A high-value asset was stolen from El-متحف El-مصري El-كبير بالجيزة during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Khaled El-Shennawy",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Khaled El-Shennawy orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لانا شاهين",
        "role": "Antiquities & Tourism Expert",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_62_suspect_1.jpg"
      },
      {
        "name": "Khaled El-Shennawy",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from El-متحف El-مصري El-كبير بالجيزة when the incident took place.",
        "image": "images/suspects/level_62_suspect_2.jpg"
      },
      {
        "name": "Saeed عوض",
        "role": "Sanitation Worker",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_62_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 63,
    "title": "Case 63: The Abduction of Hossam El-ديب",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Hossam El-ديب",
    "sceneLocation": "منتجع سيناء El-سياحي",
    "description": "Hossam El-ديب was ambushed and abducted outside منتجع سيناء El-سياحي. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Khaled El-شرقاوي",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Khaled El-شرقاوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Aya سرحان",
        "role": "Office Manager",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_63_suspect_1.jpg"
      },
      {
        "name": "Khaled El-شرقاوي",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منتجع سيناء El-سياحي when the incident took place.",
        "image": "images/suspects/level_63_suspect_2.jpg"
      },
      {
        "name": "Adel El-شناوي",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_63_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 64,
    "title": "Case 64: The Heist at مقر مصنع Salah El-دين للأدوية",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Mohamed El-رشيد",
    "sceneLocation": "مقر مصنع Salah El-دين للأدوية",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر مصنع Salah El-دين للأدوية. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "عماد زهران",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant عماد زهران orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "رهف عبد El-له",
        "role": "Procurement Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_64_suspect_1.jpg"
      },
      {
        "name": "Wael غنيم",
        "role": "IT Department Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_64_suspect_2.jpg"
      },
      {
        "name": "عماد زهران",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مصنع Salah El-دين للأدوية when the incident took place.",
        "image": "images/suspects/level_64_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 65,
    "title": "Case 65: The Arson Conspiracy at مقر El-شركة El-منافسة",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "لؤي El-فيومي",
    "sceneLocation": "مقر El-شركة El-منافسة",
    "description": "A catastrophic fire engulfed مقر El-شركة El-منافسة. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "منير رشوان",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor منير رشوان orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Sherif مطر",
        "role": "حارس سابق مفصول",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_65_suspect_1.jpg"
      },
      {
        "name": "Wafaa El-بدري",
        "role": "Insurance Claims Officer",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_65_suspect_2.jpg"
      },
      {
        "name": "منير رشوان",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر El-شركة El-منافسة when the incident took place.",
        "image": "images/suspects/level_65_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 66,
    "title": "Case 66: The Mystery of منير غنيم at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "منير غنيم",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving منير غنيم. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Karim El-ديب",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Karim El-ديب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Layla عوض",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_66_suspect_1.jpg"
      },
      {
        "name": "منير حماد",
        "role": "محقق خاص سابق",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_66_suspect_2.jpg"
      },
      {
        "name": "Karim El-ديب",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_66_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 67,
    "title": "Case 67: The Heist at محل El-جوهرجي بالخان",
    "crimeType": "Grand Theft & Heist",
    "victimName": "محل El-جوهرجي بالخان",
    "sceneLocation": "محل El-جوهرجي بالخان",
    "description": "A high-value asset was stolen from محل El-جوهرجي بالخان during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "منير راضي",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: محل El-جوهرجي بالخان corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه منير راضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Noha El-ديب",
        "role": "موظفة الاستقبال",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_67_suspect_1.jpg"
      },
      {
        "name": "منير راضي",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from محل El-جوهرجي بالخان when the incident took place.",
        "image": "images/suspects/level_67_suspect_2.jpg"
      },
      {
        "name": "ناصر El-حداد",
        "role": "موزع بضائع المجوهرات",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_67_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 68,
    "title": "Case 68: The Heist at Nile Contracting Headquarters",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Wael Zahran",
    "sceneLocation": "Nile Contracting Headquarters",
    "description": "A high-value asset was stolen from Nile Contracting Headquarters during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Tarek El-حداد",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Tarek El-حداد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Omar El-شافعي",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_68_suspect_1.jpg"
      },
      {
        "name": "شيرين منصور",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_68_suspect_2.jpg"
      },
      {
        "name": "Tarek El-حداد",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Nile Contracting Headquarters when the incident took place.",
        "image": "images/suspects/level_68_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 69,
    "title": "Case 69: The Mystery of Tamer Selim at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Tamer Selim",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Tamer Selim. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Hossam El-تهامي",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Hossam El-تهامي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Hossam El-تهامي",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_69_suspect_1.jpg"
      },
      {
        "name": "Nour حجاب",
        "role": "المساعدة الشخصية",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_69_suspect_2.jpg"
      },
      {
        "name": "باسل Selim",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_69_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 70,
    "title": "Case 70: The Heist at شقة مصر El-جديدة El-كلاسيكية",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Khaled El-خوري",
    "sceneLocation": "شقة مصر El-جديدة El-كلاسيكية",
    "description": "A high-value asset was stolen from شقة مصر El-جديدة El-كلاسيكية during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Adel El-Tohamy",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Adel El-Tohamy orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Adel El-Tohamy",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شقة مصر El-جديدة El-كلاسيكية when the incident took place.",
        "image": "images/suspects/level_70_suspect_1.jpg"
      },
      {
        "name": "منير عبد El-له",
        "role": "حارس العقار",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_70_suspect_2.jpg"
      },
      {
        "name": "Dina عبد El-له",
        "role": "الخادمة الخاصة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_70_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 71,
    "title": "Case 71: The Poisoning at مكتب رئيس مصنع Salah El-دين للأدوية",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "Khaled El-Amir",
    "sceneLocation": "مكتب رئيس مصنع Salah El-دين للأدوية",
    "description": "Khaled El-Amir was found dead inside مكتب رئيس مصنع Salah El-دين للأدوية from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "ولاء El-حداد",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس مصنع Salah El-دين للأدوية corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary ولاء El-حداد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Wael El-Sayed",
        "role": "Deputy Managing Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_71_suspect_1.jpg"
      },
      {
        "name": "ولاء El-حداد",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس مصنع Salah El-دين للأدوية when the incident took place.",
        "image": "images/suspects/level_71_suspect_2.jpg"
      },
      {
        "name": "Maged Selim",
        "role": "Financial Accountant",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_71_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 72,
    "title": "Case 72: The Heist at متحف El-حضارة بالفسطاط",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "سيف El-ملك أحمس",
    "sceneLocation": "متحف El-حضارة بالفسطاط",
    "description": "A high-value asset was stolen from متحف El-حضارة بالفسطاط during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Maged El-شناوي",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Maged El-شناوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Hossam El-Amir",
        "role": "Sanitation Worker",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_72_suspect_1.jpg"
      },
      {
        "name": "Maged El-شناوي",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from متحف El-حضارة بالفسطاط when the incident took place.",
        "image": "images/suspects/level_72_suspect_2.jpg"
      },
      {
        "name": "Ola El-Shennawy",
        "role": "Antiquities & Tourism Expert",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_72_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 73,
    "title": "Case 73: The Abduction of Dina حماد",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Dina حماد",
    "sceneLocation": "فندق El-نيل هيلتون",
    "description": "Dina حماد was ambushed and abducted outside فندق El-نيل هيلتون. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Ahmed غنيم",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Ahmed غنيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Ahmed غنيم",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from فندق El-نيل هيلتون when the incident took place.",
        "image": "images/suspects/level_73_suspect_1.jpg"
      },
      {
        "name": "Nada حماد",
        "role": "Office Manager",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_73_suspect_2.jpg"
      },
      {
        "name": "Khaled رشوان",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_73_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 74,
    "title": "Case 74: The Heist at مقر مجموعة El-هرم El-قابضة",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "باسل El-Amir",
    "sceneLocation": "مقر مجموعة El-هرم El-قابضة",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر مجموعة El-هرم El-قابضة. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Moustafa El-رشيد",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Moustafa El-رشيد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Moustafa El-رشيد",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مجموعة El-هرم El-قابضة when the incident took place.",
        "image": "images/suspects/level_74_suspect_1.jpg"
      },
      {
        "name": "Amira El-حكيم",
        "role": "Procurement Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_74_suspect_2.jpg"
      },
      {
        "name": "Selim El-خوري",
        "role": "IT Department Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_74_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 75,
    "title": "Case 75: The Arson Conspiracy at مكتبة El-تراث El-قديمة",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "Fady El-خوري",
    "sceneLocation": "مكتبة El-تراث El-قديمة",
    "description": "A catastrophic fire engulfed مكتبة El-تراث El-قديمة. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Hossam زهران",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Hossam زهران orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Ziad El-ديب",
        "role": "حارس سابق مفصول",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_75_suspect_1.jpg"
      },
      {
        "name": "Hossam زهران",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتبة El-تراث El-قديمة when the incident took place.",
        "image": "images/suspects/level_75_suspect_2.jpg"
      },
      {
        "name": "مريم El-تهامي",
        "role": "Insurance Claims Officer",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_75_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 76,
    "title": "Case 76: The Mystery of ولاء El-ديب at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "ولاء El-ديب",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving ولاء El-ديب. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Saeed El-شافعي",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Saeed El-شافعي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "فاطمة درويش",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_76_suspect_1.jpg"
      },
      {
        "name": "Adel درويش",
        "role": "محقق خاص سابق",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_76_suspect_2.jpg"
      },
      {
        "name": "Saeed El-شافعي",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_76_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 77,
    "title": "Case 77: The Heist at بوتيك El-Amira بالتجمع",
    "crimeType": "Grand Theft & Heist",
    "victimName": "بوتيك El-Amira بالتجمع",
    "sceneLocation": "بوتيك El-Amira بالتجمع",
    "description": "A high-value asset was stolen from بوتيك El-Amira بالتجمع during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Adel Selim",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: بوتيك El-Amira بالتجمع corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Adel Selim orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Eman راضي",
        "role": "موظفة الاستقبال",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_77_suspect_1.jpg"
      },
      {
        "name": "Hossam El-حكيم",
        "role": "موزع بضائع المجوهرات",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_77_suspect_2.jpg"
      },
      {
        "name": "Adel Selim",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from بوتيك El-Amira بالتجمع when the incident took place.",
        "image": "images/suspects/level_77_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 78,
    "title": "Case 78: The Heist at مقر شركة أمازون El-شرق للتقنية",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Youssef El-فيومي",
    "sceneLocation": "مقر شركة أمازون El-شرق للتقنية",
    "description": "A high-value asset was stolen from مقر شركة أمازون El-شرق للتقنية during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Adel Selim",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Adel Selim orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Adel Selim",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر شركة أمازون El-شرق للتقنية when the incident took place.",
        "image": "images/suspects/level_78_suspect_1.jpg"
      },
      {
        "name": "Fady منصور",
        "role": "المدير التقني",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_78_suspect_2.jpg"
      },
      {
        "name": "Layla El-Amir",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_78_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 79,
    "title": "Case 79: The Mystery of Hany راضي at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Hany راضي",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Hany راضي. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Sherif حجاب",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Sherif حجاب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Salma El-شناوي",
        "role": "المساعدة الشخصية",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_79_suspect_1.jpg"
      },
      {
        "name": "Maged عبد El-له",
        "role": "Personal Bodyguard",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_79_suspect_2.jpg"
      },
      {
        "name": "Sherif حجاب",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_79_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 80,
    "title": "Case 80: The Heist at شاليه El-ساحل El-شمالي",
    "crimeType": "Grand Theft & Heist",
    "victimName": "شادي راضي",
    "sceneLocation": "شاليه El-ساحل El-شمالي",
    "description": "A high-value asset was stolen from شاليه El-ساحل El-شمالي during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Tamer El-شرقاوي",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Tamer El-شرقاوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Tamer El-شرقاوي",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شاليه El-ساحل El-شمالي when the incident took place.",
        "image": "images/suspects/level_80_suspect_1.jpg"
      },
      {
        "name": "جمال El-فيومي",
        "role": "حارس العقار",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_80_suspect_2.jpg"
      },
      {
        "name": "مي El-حكيم",
        "role": "الخادمة الخاصة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_80_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 81,
    "title": "Case 81: The Poisoning at مكتب رئيس مجموعة El-هرم El-قابضة",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "عماد Selim",
    "sceneLocation": "مكتب رئيس مجموعة El-هرم El-قابضة",
    "description": "عماد Selim was found dead inside مكتب رئيس مجموعة El-هرم El-قابضة from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "مي El-قاضي",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس مجموعة El-هرم El-قابضة corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary مي El-قاضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "مي El-قاضي",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس مجموعة El-هرم El-قابضة when the incident took place.",
        "image": "images/suspects/level_81_suspect_1.jpg"
      },
      {
        "name": "Sherif El-ديب",
        "role": "Deputy Managing Director",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_81_suspect_2.jpg"
      },
      {
        "name": "Hossam El-تهامي",
        "role": "Financial Accountant",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_81_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 82,
    "title": "Case 82: The Heist at متحف El-حضارة بالفسطاط",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "Diamond Isis Necklace",
    "sceneLocation": "متحف El-حضارة بالفسطاط",
    "description": "A high-value asset was stolen from متحف El-حضارة بالفسطاط during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Saeed El-فيومي",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Saeed El-فيومي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Saeed El-فيومي",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from متحف El-حضارة بالفسطاط when the incident took place.",
        "image": "images/suspects/level_82_suspect_1.jpg"
      },
      {
        "name": "Dina El-ديب",
        "role": "Antiquities & Tourism Expert",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_82_suspect_2.jpg"
      },
      {
        "name": "Hany راضي",
        "role": "Sanitation Worker",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_82_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 83,
    "title": "Case 83: The Abduction of Hossam عوض",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Hossam عوض",
    "sceneLocation": "El-مرفأ El-بحري El-جنوبي",
    "description": "Hossam عوض was ambushed and abducted outside El-مرفأ El-بحري El-جنوبي. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Saeed El-ديب",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Saeed El-ديب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "شادي سرحان",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_83_suspect_1.jpg"
      },
      {
        "name": "Saeed El-ديب",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from El-مرفأ El-بحري El-جنوبي when the incident took place.",
        "image": "images/suspects/level_83_suspect_2.jpg"
      },
      {
        "name": "فاطمة حجاب",
        "role": "Office Manager",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_83_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 84,
    "title": "Case 84: The Heist at مقر مصنع Salah El-دين للأدوية",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "Wael El-خوري",
    "sceneLocation": "مقر مصنع Salah El-دين للأدوية",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر مصنع Salah El-دين للأدوية. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Ahmed El-ديب",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Ahmed El-ديب orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Maha غنيم",
        "role": "Procurement Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_84_suspect_1.jpg"
      },
      {
        "name": "Ahmed El-ديب",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مصنع Salah El-دين للأدوية when the incident took place.",
        "image": "images/suspects/level_84_suspect_2.jpg"
      },
      {
        "name": "Sameh مطر",
        "role": "IT Department Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_84_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 85,
    "title": "Case 85: The Arson Conspiracy at مصنع El-نسيج El-رئيسي",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "جمال El-فيومي",
    "sceneLocation": "مصنع El-نسيج El-رئيسي",
    "description": "A catastrophic fire engulfed مصنع El-نسيج El-رئيسي. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Adel El-فيومي",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Adel El-فيومي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Maged سرحان",
        "role": "حارس سابق مفصول",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_85_suspect_1.jpg"
      },
      {
        "name": "Sawsan مطر",
        "role": "Insurance Claims Officer",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_85_suspect_2.jpg"
      },
      {
        "name": "Adel El-فيومي",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مصنع El-نسيج El-رئيسي when the incident took place.",
        "image": "images/suspects/level_85_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 86,
    "title": "Case 86: The Mystery of Fady شاهين at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "Fady شاهين",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving Fady شاهين. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Sameh مطر",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Sameh مطر orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Wafaa El-جارحي",
        "role": "الصديقة المقرّبة",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_86_suspect_1.jpg"
      },
      {
        "name": "Karim El-خوري",
        "role": "محقق خاص سابق",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_86_suspect_2.jpg"
      },
      {
        "name": "Sameh مطر",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_86_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 87,
    "title": "Case 87: The Heist at محل El-جوهرجي بالخان",
    "crimeType": "Grand Theft & Heist",
    "victimName": "محل El-جوهرجي بالخان",
    "sceneLocation": "محل El-جوهرجي بالخان",
    "description": "A high-value asset was stolen from محل El-جوهرجي بالخان during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Mohamed El-قاضي",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: محل El-جوهرجي بالخان corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Mohamed El-قاضي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "لبنى El-قاضي",
        "role": "موظفة الاستقبال",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_87_suspect_1.jpg"
      },
      {
        "name": "Mohamed El-قاضي",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from محل El-جوهرجي بالخان when the incident took place.",
        "image": "images/suspects/level_87_suspect_2.jpg"
      },
      {
        "name": "Wael سرحان",
        "role": "موزع بضائع المجوهرات",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_87_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 88,
    "title": "Case 88: The Heist at مقر بنك El-أفق El-دولي",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Selim El-جارحي",
    "sceneLocation": "مقر بنك El-أفق El-دولي",
    "description": "A high-value asset was stolen from مقر بنك El-أفق El-دولي during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Hany El-حداد",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Hany El-حداد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Adel El-جارحي",
        "role": "المدير التقني",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_88_suspect_1.jpg"
      },
      {
        "name": "Hany El-حداد",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر بنك El-أفق El-دولي when the incident took place.",
        "image": "images/suspects/level_88_suspect_2.jpg"
      },
      {
        "name": "فاطمة عبد El-رحمن",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_88_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 89,
    "title": "Case 89: The Mystery of Saeed El-Sayed at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Saeed El-Sayed",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Saeed El-Sayed. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "باسل منصور",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة باسل منصور orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Ehab El-حداد",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_89_suspect_1.jpg"
      },
      {
        "name": "باسل منصور",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_89_suspect_2.jpg"
      },
      {
        "name": "فاطمة مطر",
        "role": "المساعدة الشخصية",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_89_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 90,
    "title": "Case 90: The Heist at شقة El-زمالك El-فاخرة",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Sherif El-شافعي",
    "sceneLocation": "شقة El-زمالك El-فاخرة",
    "description": "A high-value asset was stolen from شقة El-زمالك El-فاخرة during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Saeed El-شرقاوي",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Saeed El-شرقاوي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Saeed El-شرقاوي",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from شقة El-زمالك El-فاخرة when the incident took place.",
        "image": "images/suspects/level_90_suspect_1.jpg"
      },
      {
        "name": "Salma منصور",
        "role": "الخادمة الخاصة",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_90_suspect_2.jpg"
      },
      {
        "name": "Maged El-حكيم",
        "role": "حارس العقار",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_90_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 91,
    "title": "Case 91: The Poisoning at مكتب رئيس مجموعة El-فجر El-عقارية",
    "crimeType": "Premeditated Murder by Poisoning",
    "victimName": "ناصر El-خوري",
    "sceneLocation": "مكتب رئيس مجموعة El-فجر El-عقارية",
    "description": "ناصر El-خوري was found dead inside مكتب رئيس مجموعة El-فجر El-عقارية from a lethal dose of fast-acting poison. Uncover who slipped the toxin and exposed the fatal motive!",
    "culpritName": "Sawsan درويش",
    "culpritRole": "Personal Secretary",
    "evidence": "📹 Security Feed: مكتب رئيس مجموعة El-فجر El-عقارية corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "Personal Secretary Sawsan درويش orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "شادي El-شرقاوي",
        "role": "Financial Accountant",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_91_suspect_1.jpg"
      },
      {
        "name": "Sawsan درويش",
        "role": "Personal Secretary",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مكتب رئيس مجموعة El-فجر El-عقارية when the incident took place.",
        "image": "images/suspects/level_91_suspect_2.jpg"
      },
      {
        "name": "Omar El-شافعي",
        "role": "Deputy Managing Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_91_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 92,
    "title": "Case 92: The Heist at متحف El-حضارة بالفسطاط",
    "crimeType": "Antiquities Theft & Forgery",
    "victimName": "تمثال نفرتيتي El-ذهبي",
    "sceneLocation": "متحف El-حضارة بالفسطاط",
    "description": "A high-value asset was stolen from متحف El-حضارة بالفسطاط during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Omar El-خوري",
    "culpritRole": "Museum Security Director",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Museum Security Director Omar El-خوري orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "علا راضي",
        "role": "Antiquities & Tourism Expert",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_92_suspect_1.jpg"
      },
      {
        "name": "Omar El-خوري",
        "role": "Museum Security Director",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from متحف El-حضارة بالفسطاط when the incident took place.",
        "image": "images/suspects/level_92_suspect_2.jpg"
      },
      {
        "name": "Saeed شاهين",
        "role": "Sanitation Worker",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_92_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 93,
    "title": "Case 93: The Abduction of Sarah سرحان",
    "crimeType": "Kidnapping & Extortion",
    "victimName": "Sarah سرحان",
    "sceneLocation": "فندق El-نيل هيلتون",
    "description": "Sarah سرحان was ambushed and abducted outside فندق El-نيل هيلتون. Interrogate the inner circle, follow the wiretaps, and unmask the mastermind!",
    "culpritName": "Mohamed El-شافعي",
    "culpritRole": "Personal Chauffeur",
    "evidence": "🎙️ Wiretap Audio Recording: Background voice matching biometric frequencies recovered from the scene.",
    "solutionExplanation": "Personal Chauffeur Mohamed El-شافعي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Dina سرحان",
        "role": "Office Manager",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_93_suspect_1.jpg"
      },
      {
        "name": "Mohamed El-شافعي",
        "role": "Personal Chauffeur",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from فندق El-نيل هيلتون when the incident took place.",
        "image": "images/suspects/level_93_suspect_2.jpg"
      },
      {
        "name": "عماد El-بدري",
        "role": "Personal Bodyguard",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_93_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 94,
    "title": "Case 94: The Heist at مقر مجموعة El-هرم El-قابضة",
    "crimeType": "Financial Embezzlement & Forgery",
    "victimName": "منير رشوان",
    "sceneLocation": "مقر مجموعة El-هرم El-قابضة",
    "description": "Millions in classified capital have vanished from corporate accounts at مقر مجموعة El-هرم El-قابضة. Decode the financial audit trails and expose the embezzler!",
    "culpritName": "Adel El-حكيم",
    "culpritRole": "Chief Accountant",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Chief Accountant Adel El-حكيم orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Tarek El-Shennawy",
        "role": "IT Department Director",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_94_suspect_1.jpg"
      },
      {
        "name": "Adel El-حكيم",
        "role": "Chief Accountant",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر مجموعة El-هرم El-قابضة when the incident took place.",
        "image": "images/suspects/level_94_suspect_2.jpg"
      },
      {
        "name": "رهف منصور",
        "role": "Procurement Director",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_94_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 95,
    "title": "Case 95: The Arson Conspiracy at Grand Cargo Terminal & Warehouse",
    "crimeType": "Arson & Willful Property Destruction",
    "victimName": "شادي زهران",
    "sceneLocation": "Grand Cargo Terminal & Warehouse",
    "description": "A catastrophic fire engulfed Grand Cargo Terminal & Warehouse. Arson investigators recovered deliberate chemical accelerants. Trace the culprit before they flee!",
    "culpritName": "Wael El-حداد",
    "culpritRole": "Business Competitor",
    "evidence": "🔍 Latent Fingerprint Match: Physical minutiae lifted directly from the recovered instrument.",
    "solutionExplanation": "Business Competitor Wael El-حداد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Wael El-حداد",
        "role": "Business Competitor",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from Grand Cargo Terminal & Warehouse when the incident took place.",
        "image": "images/suspects/level_95_suspect_1.jpg"
      },
      {
        "name": "Ramy سرحان",
        "role": "حارس سابق مفصول",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_95_suspect_2.jpg"
      },
      {
        "name": "Dina El-فيومي",
        "role": "Insurance Claims Officer",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_95_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 96,
    "title": "Case 96: The Mystery of شادي راضي at غير محدد",
    "crimeType": "Blackmail & Extortion",
    "victimName": "شادي راضي",
    "sceneLocation": "غير محدد",
    "description": "An emergency dispatch reported a severe incident at غير محدد involving شادي راضي. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Moustafa El-فيومي",
    "culpritRole": "الشريك المقرّب",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك المقرّب Moustafa El-فيومي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Moustafa El-فيومي",
        "role": "الشريك المقرّب",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from غير محدد when the incident took place.",
        "image": "images/suspects/level_96_suspect_1.jpg"
      },
      {
        "name": "Hany El-رشيد",
        "role": "محقق خاص سابق",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_96_suspect_2.jpg"
      },
      {
        "name": "Aya El-حداد",
        "role": "الصديقة المقرّبة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_96_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 97,
    "title": "Case 97: The Heist at محل El-جوهرجي بالخان",
    "crimeType": "Grand Theft & Heist",
    "victimName": "محل El-جوهرجي بالخان",
    "sceneLocation": "محل El-جوهرجي بالخان",
    "description": "A high-value asset was stolen from محل El-جوهرجي بالخان during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Selim El-جارحي",
    "culpritRole": "عميل ثري مشبوه",
    "evidence": "📹 Security Feed: محل El-جوهرجي بالخان corridor log revealing timestamps contradicting witness statements.",
    "solutionExplanation": "عميل ثري مشبوه Selim El-جارحي orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "شادي عبد El-رحمن",
        "role": "موزع بضائع المجوهرات",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_97_suspect_1.jpg"
      },
      {
        "name": "لمار حجاب",
        "role": "موظفة الاستقبال",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_97_suspect_2.jpg"
      },
      {
        "name": "Selim El-جارحي",
        "role": "عميل ثري مشبوه",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from محل El-جوهرجي بالخان when the incident took place.",
        "image": "images/suspects/level_97_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 98,
    "title": "Case 98: The Heist at مقر بنك El-أفق El-دولي",
    "crimeType": "Grand Theft & Heist",
    "victimName": "جمال El-فيومي",
    "sceneLocation": "مقر بنك El-أفق El-دولي",
    "description": "A high-value asset was stolen from مقر بنك El-أفق El-دولي during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Belal عوض",
    "culpritRole": "مطوّر الأنظمة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "مطوّر الأنظمة Belal عوض orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Belal عوض",
        "role": "مطوّر الأنظمة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from مقر بنك El-أفق El-دولي when the incident took place.",
        "image": "images/suspects/level_98_suspect_1.jpg"
      },
      {
        "name": "Ramy El-Sayed",
        "role": "المدير التقني",
        "statement": "I was attending to routine operational duties on the lower floor and immediately notified security upon noticing anomalies.",
        "image": "images/suspects/level_98_suspect_2.jpg"
      },
      {
        "name": "Amira عبد El-له",
        "role": "مديرة الأمن المعلوماتي",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_98_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 99,
    "title": "Case 99: The Mystery of Karim El-Amir at منزل El-ضحية",
    "crimeType": "اغتيال عمد بتخطيط مسبق",
    "victimName": "Karim El-Amir",
    "sceneLocation": "منزل El-ضحية",
    "description": "An emergency dispatch reported a severe incident at منزل El-ضحية involving Karim El-Amir. Cross-reference witness statements with forensic evidence to close the case.",
    "culpritName": "Karim منصور",
    "culpritRole": "الشريك في الصفقة",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "الشريك في الصفقة Karim منصور orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Wael رشوان",
        "role": "Personal Bodyguard",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_99_suspect_1.jpg"
      },
      {
        "name": "Karim منصور",
        "role": "الشريك في الصفقة",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from منزل El-ضحية when the incident took place.",
        "image": "images/suspects/level_99_suspect_2.jpg"
      },
      {
        "name": "لبنى زهران",
        "role": "المساعدة الشخصية",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_99_suspect_3.jpg"
      }
    ]
  },
  {
    "level": 100,
    "title": "Case 100: The Heist at فيلا El-معادي El-خاصة",
    "crimeType": "Grand Theft & Heist",
    "victimName": "Tamer El-شناوي",
    "sceneLocation": "فيلا El-معادي El-خاصة",
    "description": "A high-value asset was stolen from فيلا El-معادي El-خاصة during a sudden disruption in security feeds. Trace the forensic anomalies to identify the thief!",
    "culpritName": "Belal حماد",
    "culpritRole": "Business Partner",
    "evidence": "💬 Decrypted Messaging Thread: Coordinate logs confirming covert communications with an accomplice.",
    "solutionExplanation": "Business Partner Belal حماد orchestrated the crime. Physical forensic traces and timestamped digital records fully disprove their fabricated alibi, establishing undisputed guilt.",
    "suspects": [
      {
        "name": "Khaled El-Amir",
        "role": "حارس العقار",
        "statement": "I left the location around 6:00 PM and spent the entire evening at home with verified witnesses.",
        "image": "images/suspects/level_100_suspect_1.jpg"
      },
      {
        "name": "Belal حماد",
        "role": "Business Partner",
        "statement": "I had absolutely no reason to harm anyone. I was completely away from فيلا El-معادي El-خاصة when the incident took place.",
        "image": "images/suspects/level_100_suspect_2.jpg"
      },
      {
        "name": "Amira El-خوري",
        "role": "الخادمة الخاصة",
        "statement": "I only handled official scheduled tasks and never stepped foot near the private quarters during that timeframe.",
        "image": "images/suspects/level_100_suspect_3.jpg"
      }
    ]
  }
];
