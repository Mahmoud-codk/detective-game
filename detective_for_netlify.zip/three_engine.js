/**
 * ═══════════════════════════════════════════════════════════════════
 * 🕵️ المخبر الذكي — 3D WebGL Detective Engine  v1.0
 * Powered by Three.js | Crime Scene · Evidence Inspector · Interrogation
 * ═══════════════════════════════════════════════════════════════════
 */

// ────────────────────────────────────────────
// 1.  THREE.JS DYNAMIC LOADER
// ────────────────────────────────────────────
const THREE_CDN = 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
const ORBIT_CDN = 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js';

let THREE = null;
let OrbitControls = null;

async function loadThreeJS() {
  if (THREE) return true;
  try {
    const threeModule = await import(THREE_CDN);
    THREE = threeModule;
    const orbitModule = await import(ORBIT_CDN);
    OrbitControls = orbitModule.OrbitControls;
    return true;
  } catch (e) {
    console.warn('[3D Engine] Three.js failed to load. Falling back to 2D mode.', e);
    return false;
  }
}

// ────────────────────────────────────────────
// 2.  ENGINE STATE
// ────────────────────────────────────────────
const D3Engine = {
  renderer: null,
  scene: null,
  camera: null,
  controls: null,
  flashlight: null,
  flashlightEnabled: false,
  raycaster: null,
  pointer: new (class Vec { constructor() { this.x = 0; this.y = 0; } })(),
  interactables: [],       // clickable 3D objects
  currentLevelData: null,
  animFrameId: null,
  isActive: false,
  // Interrogation 3D
  suspectMesh: null,
  suspectAnimMixer: null,
  nervousnessLevel: 0,     // 0-100
  // Evidence 360 inspector
  inspectorScene: null,
  inspectorRenderer: null,
  inspectorCamera: null,
  inspectorMesh: null,
  inspectorFrameId: null,
  inspectorDragging: false,
  inspectorLastX: 0,
  inspectorLastY: 0,
};

// ────────────────────────────────────────────
// 3.  INIT CRIME SCENE 3D
// ────────────────────────────────────────────
async function init3DCrimeScene(containerId, levelData) {
  const ok = await loadThreeJS();
  if (!ok) {
    document.getElementById(containerId).innerHTML = `
      <div style="color:#FF416C;font-size:0.9rem;padding:20px;text-align:center;">
        ⚠️ WebGL غير مدعوم في هذا المتصفح. يُرجى تحديث المتصفح لتجربة الوضع ثلاثي الأبعاد.
      </div>`;
    return;
  }
  D3Engine.currentLevelData = levelData;

  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';

  const W = container.clientWidth  || 360;
  const H = container.clientHeight || 320;

  // ── Renderer
  D3Engine.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  D3Engine.renderer.setSize(W, H);
  D3Engine.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  D3Engine.renderer.shadowMap.enabled = true;
  D3Engine.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  D3Engine.renderer.toneMapping = THREE.ReinhardToneMapping;
  D3Engine.renderer.toneMappingExposure = 1.2;
  container.appendChild(D3Engine.renderer.domElement);

  // ── Scene
  D3Engine.scene = new THREE.Scene();
  D3Engine.scene.background = new THREE.Color(0x0a0a0f);
  D3Engine.scene.fog = new THREE.FogExp2(0x0a0a0f, 0.04);

  // ── Camera
  D3Engine.camera = new THREE.PerspectiveCamera(65, W / H, 0.1, 100);
  D3Engine.camera.position.set(0, 1.8, 5);

  // ── Controls (orbit / touch drag)
  D3Engine.controls = new OrbitControls(D3Engine.camera, D3Engine.renderer.domElement);
  D3Engine.controls.enableDamping = true;
  D3Engine.controls.dampingFactor = 0.08;
  D3Engine.controls.maxPolarAngle = Math.PI * 0.75;
  D3Engine.controls.minDistance = 2;
  D3Engine.controls.maxDistance = 10;
  D3Engine.controls.target.set(0, 1, 0);

  // ── Raycaster
  D3Engine.raycaster = new THREE.Raycaster();
  D3Engine.interactables = [];

  // ── Ambient Light (very low for noir feel)
  const ambient = new THREE.AmbientLight(0x1a1a2e, 0.4);
  D3Engine.scene.add(ambient);

  // ── Ceiling lamp with warm glow
  const lamp = new THREE.PointLight(0xffd700, 0.8, 10);
  lamp.position.set(0, 4, 0);
  lamp.castShadow = true;
  D3Engine.scene.add(lamp);

  // ── Flashlight (SpotLight attached to camera)
  D3Engine.flashlight = new THREE.SpotLight(0xffffff, 0, 15, Math.PI * 0.12, 0.4, 1.5);
  D3Engine.flashlight.castShadow = true;
  D3Engine.camera.add(D3Engine.flashlight);
  D3Engine.flashlight.target.position.set(0, 0, -1);
  D3Engine.camera.add(D3Engine.flashlight.target);
  D3Engine.scene.add(D3Engine.camera);

  // ── Build scene for current level location
  buildCrimeSceneGeometry(levelData);

  // ── Event listeners
  D3Engine.renderer.domElement.addEventListener('click', on3DSceneClick);
  D3Engine.renderer.domElement.addEventListener('pointermove', on3DPointerMove);
  window.addEventListener('resize', on3DResize);

  D3Engine.isActive = true;
  animate3D();
}

// ────────────────────────────────────────────
// 4.  SCENE GEOMETRY BUILDER
// ────────────────────────────────────────────
function buildCrimeSceneGeometry(levelData) {
  const scene = D3Engine.scene;

  // Determine scene type from sceneLocation
  const loc = (levelData.sceneLocation || '').toLowerCase();
  let themeColor = 0x2c1810; // default wood/office
  if (loc.includes('متحف') || loc.includes('museum')) themeColor = 0x1a2040;
  else if (loc.includes('مطار') || loc.includes('airport')) themeColor = 0x1c2c1c;
  else if (loc.includes('فيلا') || loc.includes('منزل')) themeColor = 0x201a10;

  // ── Floor
  const floorGeo = new THREE.PlaneGeometry(14, 14);
  const floorMat = new THREE.MeshLambertMaterial({
    color: themeColor,
    side: THREE.DoubleSide
  });
  const floor = new THREE.Mesh(floorGeo, floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  // ── Floor grid pattern (tiles)
  const gridHelper = new THREE.GridHelper(14, 14, 0x333344, 0x222233);
  gridHelper.position.y = 0.005;
  scene.add(gridHelper);

  // ── Walls
  buildWalls();

  // ── Furniture based on location type
  if (loc.includes('مكتب') || loc.includes('office') || loc.includes('شركة')) {
    buildOfficeScene();
  } else if (loc.includes('غرفة') || loc.includes('منزل') || loc.includes('فيلا')) {
    buildBedroomScene();
  } else if (loc.includes('مطبخ') || loc.includes('kitchen')) {
    buildKitchenScene();
  } else {
    buildOfficeScene(); // default
  }

  // ── Evidence hotspots (glowing orbs)
  spawnEvidenceHotspots(levelData);
}

function buildWalls() {
  const scene = D3Engine.scene;
  const wallMat = new THREE.MeshLambertMaterial({ color: 0x1a1a28 });

  // Back wall
  const backWall = new THREE.Mesh(new THREE.PlaneGeometry(14, 6), wallMat);
  backWall.position.set(0, 3, -7);
  scene.add(backWall);

  // Left wall
  const leftWall = new THREE.Mesh(new THREE.PlaneGeometry(14, 6), wallMat);
  leftWall.rotation.y = Math.PI / 2;
  leftWall.position.set(-7, 3, 0);
  scene.add(leftWall);

  // Right wall
  const rightWall = new THREE.Mesh(new THREE.PlaneGeometry(14, 6), wallMat);
  rightWall.rotation.y = -Math.PI / 2;
  rightWall.position.set(7, 3, 0);
  scene.add(rightWall);

  // Ceiling
  const ceilMat = new THREE.MeshLambertMaterial({ color: 0x111118 });
  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), ceilMat);
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.set(0, 6, 0);
  scene.add(ceiling);
}

function buildOfficeScene() {
  const scene = D3Engine.scene;

  // ── Desk
  addBox(scene, { w:2.5, h:0.08, d:1.2 }, { x:0, y:0.8, z:-2 }, 0x3d2b1f, 'مكتب المدير', false);
  // Desk legs
  [-1.1,1.1].forEach(x => [-0.5,0.5].forEach(z => {
    addBox(scene, {w:0.07,h:0.8,d:0.07}, {x, y:0.4, z: z-2}, 0x2a1d12);
  }));

  // ── Office chair
  addBox(scene, {w:0.7,h:0.08,d:0.7}, {x:0,y:0.5,z:-0.5}, 0x1a1a2a);
  addBox(scene, {w:0.7,h:0.8,d:0.07}, {x:0,y:0.9,z:-0.85}, 0x1a1a2a);

  // ── Filing cabinet (interactable)
  const cabinet = addBox(scene, {w:0.5,h:1.2,d:0.4}, {x:-3,y:0.6,z:-6.5}, 0x4a6fa5, 'خزانة الملفات', true);
  cabinet.userData.interactType = 'cabinet';
  cabinet.userData.label = '🗄️ خزانة الملفات — اضغط لفتحها';
  cabinet.userData.openY = 1.3;
  addInteractGlow(scene, cabinet);

  // ── Safe hidden behind painting
  const safe = addBox(scene, {w:0.6,h:0.5,d:0.15}, {x:3,y:2.5,z:-6.85}, 0x888888, 'الخزينة السرية', true);
  safe.userData.interactType = 'safe';
  safe.userData.label = '🔒 الخزينة السرية — استخدم الرمز لفتحها';
  addInteractGlow(scene, safe);

  // ── Picture frame (painting hiding the safe)
  addBox(scene, {w:0.9,h:0.7,d:0.05}, {x:3,y:2.5,z:-6.8}, 0x8B4513, 'لوحة على الجدار', true)
    .userData.interactType = 'painting';

  // ── Coffee cup on desk (evidence item)
  const cup = addCylinder(scene, 0.07, 0.05, 0.1, {x:0.6,y:0.86,z:-2.2}, 0xffffff, 'فنجان القهوة', true);
  cup.userData.interactType = 'evidence';
  cup.userData.evidenceIcon = '☕';
  cup.userData.evidenceName = 'فنجان القهوة المسموم';
  addInteractGlow(scene, cup);

  // ── Book shelf
  addBox(scene, {w:2,h:2.5,d:0.3}, {x:-5.5,y:1.25,z:-6.7}, 0x5c3d1e);
  for(let i=0;i<5;i++) {
    addBox(scene, {w:0.15,h:0.3,d:0.22}, {x:-5.5+(i*0.3)-0.6,y:1.6,z:-6.55}, [0x8B0000,0x00008B,0x006400,0x8B8000,0x4B0082][i]);
  }

  // ── Monitor on desk
  addBox(scene, {w:0.6,h:0.4,d:0.04}, {x:-0.5,y:1.1,z:-2.3}, 0x222222);
  addBox(scene, {w:0.15,h:0.2,d:0.1}, {x:-0.5,y:0.84,z:-2.3}, 0x222222);
}

function buildBedroomScene() {
  const scene = D3Engine.scene;

  // ── Bed
  addBox(scene, {w:2,h:0.4,d:2.8}, {x:0,y:0.2,z:-4}, 0x2a1a2a);
  addBox(scene, {w:2,h:0.7,d:0.1}, {x:0,y:0.55,z:-5.3}, 0x3a2030);  // headboard
  // Pillows
  addBox(scene, {w:0.7,h:0.15,d:0.5}, {x:-0.5,y:0.45,z:-4.8}, 0xffffff);
  addBox(scene, {w:0.7,h:0.15,d:0.5}, {x:0.5,y:0.45,z:-4.8}, 0xeeeeee);
  // Mattress
  addBox(scene, {w:1.95,h:0.12,d:2.7}, {x:0,y:0.42,z:-4}, 0xddddcc);

  // ── Nightstand with drawer (interactable)
  const nstand = addBox(scene, {w:0.5,h:0.5,d:0.45}, {x:1.3,y:0.25,z:-4.5}, 0x5c3d1e, 'الدرج الجانبي', true);
  nstand.userData.interactType = 'drawer';
  nstand.userData.label = '🗄️ الدرج الجانبي — اضغط لفتحه';
  addInteractGlow(scene, nstand);

  // ── Wardrobe (safe-like)
  const wardrobe = addBox(scene, {w:1.2,h:2.2,d:0.5}, {x:-5.5,y:1.1,z:-5.5}, 0x4a3020, 'خزانة الملابس', true);
  wardrobe.userData.interactType = 'wardrobe';
  wardrobe.userData.label = '👗 خزانة الملابس — هل يوجد شيء مخبأ بداخلها؟';
  addInteractGlow(scene, wardrobe);

  // ── Lamp on nightstand
  addCylinder(scene, 0.02, 0.02, 0.4, {x:1.3,y:0.7,z:-4.5}, 0xaaaaaa);
  addCylinder(scene, 0.12, 0.06, 0.2, {x:1.3,y:0.95,z:-4.5}, 0xffffcc);

  // ── Carpet
  const rug = new THREE.Mesh(
    new THREE.PlaneGeometry(3, 2),
    new THREE.MeshLambertMaterial({ color: 0x8B0000, opacity:0.8, transparent:true })
  );
  rug.rotation.x = -Math.PI / 2;
  rug.position.set(0, 0.01, -2);
  scene.add(rug);
}

function buildKitchenScene() {
  const scene = D3Engine.scene;

  // ── Counter
  addBox(scene, {w:4,h:0.08,d:0.9}, {x:0,y:0.95,z:-6}, 0x708090);
  addBox(scene, {w:4,h:0.95,d:0.88}, {x:0,y:0.47,z:-6}, 0x607080);

  // ── Cabinets above
  addBox(scene, {w:3.5,h:0.9,d:0.5}, {x:0,y:2.5,z:-6.25}, 0x708090);

  // ── Stove
  addBox(scene, {w:0.8,h:0.05,d:0.6}, {x:-1.5,y:1,z:-6}, 0x333333);
  for(let i=0;i<2;i++) for(let j=0;j<2;j++) {
    addCylinder(scene, 0.12, 0.12, 0.02, {x:-1.5+(i*0.3)-0.15, y:1.03, z:-6+(j*0.25)-0.12}, 0x444444);
  }

  // ── Sink (interactable)
  const sink = addBox(scene, {w:0.5,h:0.06,d:0.4}, {x:1.5,y:0.97,z:-6}, 0x888888, 'حوض المطبخ', true);
  sink.userData.interactType = 'sink';
  sink.userData.label = '🚿 حوض المطبخ — ابحث عن آثار مخبأة';
  addInteractGlow(scene, sink);

  // ── Fridge (interactable)
  const fridge = addBox(scene, {w:0.8,h:1.8,d:0.7}, {x:3.5,y:0.9,z:-5.7}, 0xdddddd, 'الثلاجة', true);
  fridge.userData.interactType = 'fridge';
  fridge.userData.label = '🧊 الثلاجة — هل يوجد دليل بداخلها؟';
  addInteractGlow(scene, fridge);

  // ── Trash bin (evidence)
  const trash = addCylinder(scene, 0.15, 0.12, 0.4, {x:3,y:0.2,z:-3.5}, 0x444444, 'سلة المهملات', true);
  trash.userData.interactType = 'evidence';
  trash.userData.evidenceIcon = '🗑️';
  trash.userData.evidenceName = 'سلة المهملات';
  addInteractGlow(scene, trash);
}

// ────────────────────────────────────────────
// 5.  EVIDENCE HOTSPOT SPAWNER (glowing orbs)
// ────────────────────────────────────────────
function spawnEvidenceHotspots(levelData) {
  const scene = D3Engine.scene;
  const positions = [
    { x: -1, y: 0.5, z: -1.5 },
    { x: 2,  y: 1.2, z: -3   },
    { x: -2, y: 0.3, z: -2   },
  ];
  const icons = ['🔑','📄','🔍'];
  positions.forEach((pos, i) => {
    const geo = new THREE.SphereGeometry(0.12, 16, 16);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffd700, transparent: true, opacity: 0.85 });
    const orb = new THREE.Mesh(geo, mat);
    orb.position.set(pos.x, pos.y, pos.z);
    orb.userData.isInteractable = true;
    orb.userData.interactType = 'hotspot';
    orb.userData.label = `${icons[i]} دليل مخفي — اضغط لجمعه`;
    orb.userData.hotspotIndex = i;
    scene.add(orb);
    D3Engine.interactables.push(orb);

    // Pulsing ring around hotspot
    const ringGeo = new THREE.RingGeometry(0.18, 0.22, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffd700, side: THREE.DoubleSide, transparent: true, opacity: 0.5 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(pos.x, pos.y + 0.01, pos.z);
    ring.userData.isRing = true;
    scene.add(ring);
  });
}

// ────────────────────────────────────────────
// 6.  HELPER: ADD BOX / CYLINDER
// ────────────────────────────────────────────
function addBox(scene, size, pos, color, label, interactable = false) {
  const geo = new THREE.BoxGeometry(size.w, size.h, size.d);
  const mat = new THREE.MeshLambertMaterial({ color });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(pos.x, pos.y, pos.z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  if (interactable) {
    mesh.userData.isInteractable = true;
    mesh.userData.label = label || '🔍 تفاعل';
    D3Engine.interactables.push(mesh);
  }
  scene.add(mesh);
  return mesh;
}

function addCylinder(scene, rTop, rBottom, height, pos, color, label, interactable = false) {
  const geo = new THREE.CylinderGeometry(rTop, rBottom, height, 24);
  const mat = new THREE.MeshLambertMaterial({ color });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(pos.x, pos.y, pos.z);
  mesh.castShadow = true;
  if (interactable) {
    mesh.userData.isInteractable = true;
    mesh.userData.label = label || '🔍 تفاعل';
    D3Engine.interactables.push(mesh);
  }
  scene.add(mesh);
  return mesh;
}

function addInteractGlow(scene, mesh) {
  // Subtle emissive outline effect
  const outGeo = mesh.geometry.clone();
  const outMat = new THREE.MeshBasicMaterial({ color: 0xffd700, side: THREE.BackSide, transparent: true, opacity: 0.25 });
  const outline = new THREE.Mesh(outGeo, outMat);
  outline.scale.multiplyScalar(1.08);
  outline.userData.isGlow = true;
  mesh.add(outline);
}

// ────────────────────────────────────────────
// 7.  FLASHLIGHT TOGGLE
// ────────────────────────────────────────────
function toggle3DFlashlight(enable) {
  if (!D3Engine.flashlight) return;
  D3Engine.flashlightEnabled = enable;
  D3Engine.flashlight.intensity = enable ? 2.5 : 0;
  if (D3Engine.scene) {
    D3Engine.scene.fog.density = enable ? 0.08 : 0.04;
    // Dim ambient when flashlight is on for atmosphere
    D3Engine.scene.children.forEach(c => {
      if (c.isAmbientLight) c.intensity = enable ? 0.1 : 0.4;
    });
  }
  const torchOverlay = document.getElementById('torch-vignette-overlay-3d');
  if (torchOverlay) torchOverlay.style.display = enable ? 'block' : 'none';
}

// ────────────────────────────────────────────
// 8.  RAYCASTING — CLICK INTERACTION
// ────────────────────────────────────────────
function on3DSceneClick(event) {
  if (!D3Engine.raycaster || !D3Engine.scene) return;

  const canvas = D3Engine.renderer.domElement;
  const rect = canvas.getBoundingClientRect();
  const clientX = event.clientX ?? (event.touches ? event.touches[0].clientX : 0);
  const clientY = event.clientY ?? (event.touches ? event.touches[0].clientY : 0);

  D3Engine.pointer.x = ((clientX - rect.left) / rect.width)  * 2 - 1;
  D3Engine.pointer.y = -((clientY - rect.top)  / rect.height) * 2 + 1;

  D3Engine.raycaster.setFromCamera(D3Engine.pointer, D3Engine.camera);
  const hits = D3Engine.raycaster.intersectObjects(D3Engine.interactables, false);

  if (hits.length > 0) {
    const obj = hits[0].object;
    handle3DInteraction(obj);
  }
}

function on3DPointerMove(event) {
  // Hover highlight
  if (!D3Engine.raycaster) return;
  const canvas = D3Engine.renderer.domElement;
  const rect = canvas.getBoundingClientRect();
  D3Engine.pointer.x = ((event.clientX - rect.left) / rect.width)  * 2 - 1;
  D3Engine.pointer.y = -((event.clientY - rect.top)  / rect.height) * 2 + 1;

  D3Engine.raycaster.setFromCamera(D3Engine.pointer, D3Engine.camera);
  const hits = D3Engine.raycaster.intersectObjects(D3Engine.interactables, false);
  const tooltip = document.getElementById('scene3d-tooltip');

  if (hits.length > 0 && tooltip) {
    const obj = hits[0].object;
    tooltip.textContent = obj.userData.label || '🔍 تفاعل';
    tooltip.style.display = 'block';
    tooltip.style.left = (event.clientX - rect.left + 10) + 'px';
    tooltip.style.top  = (event.clientY - rect.top  - 30) + 'px';
    canvas.style.cursor = 'pointer';
  } else if (tooltip) {
    tooltip.style.display = 'none';
    canvas.style.cursor = 'grab';
  }
}

function handle3DInteraction(obj) {
  const type = obj.userData.interactType;
  if (!type) return;

  switch (type) {
    case 'hotspot':
      handle3DHotspotCollect(obj);
      break;
    case 'evidence':
      open3DEvidenceInspector(obj);
      break;
    case 'cabinet':
    case 'drawer':
    case 'wardrobe':
      animate3DDrawerOpen(obj);
      break;
    case 'safe':
      open3DSafeDialog(obj);
      break;
    case 'painting':
      animate3DPaintingReveal(obj);
      break;
    case 'fridge':
    case 'sink':
      show3DSearchResult(obj);
      break;
    default:
      showScene3DNotification('🔍 ' + (obj.userData.label || 'تم فحص العنصر'));
  }
}

// ────────────────────────────────────────────
// 9.  INTERACTION HANDLERS
// ────────────────────────────────────────────
function handle3DHotspotCollect(orb) {
  const idx = orb.userData.hotspotIndex ?? 0;
  const level = D3Engine.currentLevelData;
  const evidenceText = level ? level.evidence : '🔍 دليل مجمع';

  // Play pulse animation
  let scale = 1.0;
  const expand = setInterval(() => {
    scale += 0.05;
    orb.scale.setScalar(scale);
    orb.material.opacity = Math.max(0, orb.material.opacity - 0.08);
    if (orb.material.opacity <= 0) {
      clearInterval(expand);
      D3Engine.scene.remove(orb);
      D3Engine.interactables = D3Engine.interactables.filter(o => o !== orb);
    }
  }, 30);

  showScene3DNotification(`✅ تم جمع الدليل رقم ${idx+1}: ${evidenceText.split('|')[idx] || evidenceText}`);

  // Sync with game.js evidence collection
  if (typeof collectEvidenceFromScene3D === 'function') {
    collectEvidenceFromScene3D(idx, evidenceText);
  } else if (typeof window.handleCollectEvidence === 'function') {
    window.handleCollectEvidence();
  }
}

function animate3DDrawerOpen(mesh) {
  if (mesh.userData.isOpen) {
    showScene3DNotification('🗄️ الدرج مفتوح بالفعل — لا توجد أدلة إضافية.');
    return;
  }
  mesh.userData.isOpen = true;
  let progress = 0;
  const openAnim = setInterval(() => {
    progress += 0.05;
    mesh.position.z += 0.02;
    if (progress >= 1) {
      clearInterval(openAnim);
      showScene3DNotification('🗄️ تم فتح الدرج! اكتشفت: وثيقة محذوفة مُمزَّقة. تم إضافتها للأدلة.');
      if (typeof window.handleCollectEvidence === 'function') {
        window.handleCollectEvidence();
      }
    }
  }, 16);
}

function animate3DPaintingReveal(mesh) {
  if (mesh.userData.revealed) return;
  mesh.userData.revealed = true;
  let progress = 0;
  const anim = setInterval(() => {
    progress += 0.04;
    mesh.position.z += 0.04;
    mesh.rotation.z = Math.sin(progress) * 0.2;
    if (progress >= Math.PI) {
      clearInterval(anim);
      showScene3DNotification('🖼️ تم إزالة اللوحة! اكتشفت خزينة سرية مخفية خلفها! 🔒');
    }
  }, 16);
}

function open3DSafeDialog(mesh) {
  const code = prompt('🔒 أدخل الرمز السري للخزينة (4 أرقام):');
  if (code === '1342' || code === '0000' || (code && code.length === 4)) {
    showScene3DNotification('✅ تم فتح الخزينة! اكتشفت: ' + (D3Engine.currentLevelData?.hiddenEvidence?.hint || 'وثيقة سرية مهمة'));
    mesh.material.color.setHex(0x00ff88);
    if (typeof window.handleCollectEvidence === 'function') {
      window.handleCollectEvidence();
    }
  } else {
    showScene3DNotification('❌ رمز خاطئ! حاول مرة أخرى.');
  }
}

function show3DSearchResult(mesh) {
  showScene3DNotification('🔍 تم تفتيش ' + (mesh.userData.label?.split('—')[0] || 'العنصر') + ' ← لا توجد أدلة إضافية هنا.');
}

// ────────────────────────────────────────────
// 10.  360° EVIDENCE INSPECTOR (separate mini renderer)
// ────────────────────────────────────────────
function open3DEvidenceInspector(mesh) {
  const modal = document.getElementById('modal-3d-evidence-inspector');
  const title = document.getElementById('inspector-3d-title');
  const container = document.getElementById('inspector-3d-canvas-wrap');
  if (!modal || !container) return;

  const icon = mesh.userData.evidenceIcon || '🔍';
  const name = mesh.userData.evidenceName  || 'دليل مادي';
  if (title) title.textContent = `${icon} فحص 360°: ${name}`;

  // Update emoji display inside
  const obj3d = document.getElementById('inspector-3d-object-view');
  if (obj3d) obj3d.textContent = icon;

  modal.style.display = 'flex';
  init360Inspector(container, mesh.userData);
}

function init360Inspector(container, itemData) {
  // Clean previous inspector
  cleanup360Inspector();
  if (!THREE) return;

  const W = container.clientWidth  || 300;
  const H = container.clientHeight || 220;

  D3Engine.inspectorRenderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  D3Engine.inspectorRenderer.setSize(W, H);
  D3Engine.inspectorRenderer.setClearColor(0x000000, 0);
  container.appendChild(D3Engine.inspectorRenderer.domElement);

  D3Engine.inspectorScene  = new THREE.Scene();
  D3Engine.inspectorCamera = new THREE.PerspectiveCamera(50, W/H, 0.1, 100);
  D3Engine.inspectorCamera.position.set(0, 0, 3);

  // Lighting
  D3Engine.inspectorScene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const dirLight = new THREE.DirectionalLight(0xffd700, 1);
  dirLight.position.set(5, 5, 5);
  D3Engine.inspectorScene.add(dirLight);

  // 3D object representation (based on evidence type)
  const geo = getEvidenceGeometry(itemData.evidenceIcon);
  const mat = new THREE.MeshPhongMaterial({ color: 0xcccccc, shininess: 80 });
  D3Engine.inspectorMesh = new THREE.Mesh(geo, mat);
  D3Engine.inspectorScene.add(D3Engine.inspectorMesh);

  // Touch/Mouse drag rotation
  setupInspectorDrag(container);

  // Animate
  function inspectorLoop() {
    D3Engine.inspectorFrameId = requestAnimationFrame(inspectorLoop);
    if (!D3Engine.inspectorDragging) {
      D3Engine.inspectorMesh.rotation.y += 0.008;
    }
    D3Engine.inspectorRenderer.render(D3Engine.inspectorScene, D3Engine.inspectorCamera);

    // Update degree display
    const deg = Math.round((D3Engine.inspectorMesh.rotation.y * 180 / Math.PI) % 360);
    const status = document.getElementById('inspector-3d-status');
    if (status) status.textContent = `دوران 3D نشط — زاوية الدوران الحالي: ${Math.abs(deg)}°`;

    // Reveal rear fingerprint at ~180°
    const normDeg = ((deg % 360) + 360) % 360;
    const rearTrace = document.getElementById('inspector-3d-rear-trace');
    if (rearTrace) rearTrace.style.display = (normDeg > 150 && normDeg < 210) ? 'block' : 'none';
  }
  inspectorLoop();
}

function getEvidenceGeometry(icon) {
  if (!icon) return new THREE.BoxGeometry(1, 1, 1);
  if (icon.includes('☕') || icon.includes('🥛')) return new THREE.CylinderGeometry(0.3, 0.25, 0.6, 32);
  if (icon.includes('🔑') || icon.includes('🗝')) return new THREE.TorusGeometry(0.3, 0.08, 16, 32);
  if (icon.includes('📄') || icon.includes('📜')) return new THREE.BoxGeometry(0.8, 1.1, 0.04);
  if (icon.includes('🔪') || icon.includes('🗡')) return new THREE.ConeGeometry(0.07, 1.2, 8);
  if (icon.includes('💊') || icon.includes('🧪')) return new THREE.CylinderGeometry(0.15, 0.15, 0.5, 16);
  if (icon.includes('🗑️')) return new THREE.CylinderGeometry(0.3, 0.25, 0.7, 16);
  return new THREE.BoxGeometry(0.9, 0.9, 0.9);
}

function setupInspectorDrag(container) {
  let startX, startY;

  const onStart = (e) => {
    D3Engine.inspectorDragging = true;
    startX = e.clientX ?? e.touches?.[0].clientX ?? 0;
    startY = e.clientY ?? e.touches?.[0].clientY ?? 0;
    D3Engine.inspectorLastX = startX;
    D3Engine.inspectorLastY = startY;
  };
  const onMove = (e) => {
    if (!D3Engine.inspectorDragging || !D3Engine.inspectorMesh) return;
    const cx = e.clientX ?? e.touches?.[0].clientX ?? 0;
    const cy = e.clientY ?? e.touches?.[0].clientY ?? 0;
    const dx = cx - D3Engine.inspectorLastX;
    const dy = cy - D3Engine.inspectorLastY;
    D3Engine.inspectorMesh.rotation.y += dx * 0.012;
    D3Engine.inspectorMesh.rotation.x += dy * 0.012;
    D3Engine.inspectorLastX = cx;
    D3Engine.inspectorLastY = cy;
  };
  const onEnd = () => { D3Engine.inspectorDragging = false; };

  container.addEventListener('mousedown',  onStart);
  container.addEventListener('mousemove',  onMove);
  container.addEventListener('mouseup',    onEnd);
  container.addEventListener('touchstart', onStart, { passive: true });
  container.addEventListener('touchmove',  onMove,  { passive: true });
  container.addEventListener('touchend',   onEnd);
}

function cleanup360Inspector() {
  if (D3Engine.inspectorFrameId) cancelAnimationFrame(D3Engine.inspectorFrameId);
  if (D3Engine.inspectorRenderer) {
    D3Engine.inspectorRenderer.dispose();
    const canvas = D3Engine.inspectorRenderer.domElement;
    if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
    D3Engine.inspectorRenderer = null;
  }
  D3Engine.inspectorMesh = null;
}

// ────────────────────────────────────────────
// 11.  3D INTERROGATION SYSTEM
// ────────────────────────────────────────────
const SuspectExpressions = {
  calm:     { face: '😐 وجه هادئ: يحافظ على تعبير محايد وينظر بثبات.', body: '🤚 لغة الجسد: مسترخٍ، يضع يديه على الطاولة بطريقة طبيعية.' },
  nervous:  { face: '😰 تعابير التوتر: يرمش بسرعة وتظهر قطرات عرق خفية.', body: '🤚 لغة الجسد: يحرك ساقه تحت الطاولة ويشبك أصابعه.' },
  lying:    { face: '🤥 إشارات الكذب: نظرات جانبية وتعديل وضع الرقبة.', body: '🤚 لغة الجسد: يمس وجهه بشكل متكرر ويتجنب التواصل البصري.' },
  shocked:  { face: '😱 صدمة واضحة: اتساع حدقتي العينين وشحوب الوجه.', body: '🤚 لغة الجسد: تراجع للخلف وتصلب الجسم فجأة.' },
  angry:    { face: '😠 غضب مكبوت: ضم الشفتين وتعقيد عضلات الفك.', body: '🤚 لغة الجسد: شد العضلات وقبضة يد متوترة.' },
  breaking: { face: '😭 انهيار نفسي: دموع تبدأ بالظهور ورجفة في الشفة.', body: '🤚 لغة الجسد: طأطأة الرأس وتهدل الكتفين — على وشك الاعتراف!' },
};

function update3DSuspectExpression(pressurePct, hasEvidencePresented) {
  let expressionKey = 'calm';

  if (pressurePct >= 90) expressionKey = 'breaking';
  else if (pressurePct >= 70) expressionKey = hasEvidencePresented ? 'shocked' : 'angry';
  else if (pressurePct >= 50) expressionKey = 'nervous';
  else if (pressurePct >= 30) expressionKey = 'lying';
  else expressionKey = 'calm';

  const expr = SuspectExpressions[expressionKey];
  const faceEl = document.getElementById('expression-face-text');
  const bodyEl = document.getElementById('expression-body-text');

  if (faceEl) {
    faceEl.textContent = expr.face;
    faceEl.style.color = pressurePct > 60 ? '#ff6b6b' : pressurePct > 30 ? '#ffd700' : '#ccc';
  }
  if (bodyEl) {
    bodyEl.textContent = expr.body;
    bodyEl.style.color = pressurePct > 60 ? '#ff6b6b' : '#ccc';
  }

  // Update mood badge
  const moodEl = document.getElementById('interrogate-mood');
  const moodLabels = {
    calm: '😐 هادئ/بارد', nervous: '😰 متوتر', lying: '🤥 يكذب',
    shocked: '😱 صدمة', angry: '😠 غاضب', breaking: '😭 على وشك الاعتراف!'
  };
  if (moodEl) {
    moodEl.textContent = moodLabels[expressionKey];
    moodEl.style.background = pressurePct > 70 ? 'rgba(239,68,68,0.2)' :
                               pressurePct > 40 ? 'rgba(245,158,11,0.2)' : 'rgba(255,255,255,0.1)';
    moodEl.style.color = pressurePct > 70 ? '#ff6b6b' : pressurePct > 40 ? '#ffd700' : 'var(--gold)';
  }

  // Add visual shake to suspect image if nervous/breaking
  const img = document.getElementById('interrogate-img');
  if (img) {
    if (pressurePct >= 80) {
      img.style.animation = 'suspect-shake 0.3s infinite';
    } else if (pressurePct >= 50) {
      img.style.animation = 'suspect-sweat 1s infinite';
    } else {
      img.style.animation = '';
    }
  }

  D3Engine.nervousnessLevel = pressurePct;
}

function apply3DSpotlightEffect(intense) {
  const interBody = document.getElementById('interrogation-body');
  if (!interBody) return;
  if (intense) {
    interBody.style.background = 'radial-gradient(ellipse 60% 60% at 50% 35%, rgba(255,200,0,0.15) 0%, rgba(0,0,0,0.9) 80%)';
  } else {
    interBody.style.background = '';
  }
}

// ────────────────────────────────────────────
// 12.  ANIMATION LOOP
// ────────────────────────────────────────────
function animate3D() {
  if (!D3Engine.isActive) return;
  D3Engine.animFrameId = requestAnimationFrame(animate3D);

  const time = Date.now() * 0.001;

  // Pulse evidence hotspots
  D3Engine.scene.children.forEach(child => {
    if (child.userData.isRing) {
      child.scale.setScalar(1 + Math.sin(time * 2) * 0.12);
      child.material.opacity = 0.3 + Math.abs(Math.sin(time * 2)) * 0.4;
    }
    if (child.userData.interactType === 'hotspot') {
      child.position.y += Math.sin(time * 2 + child.position.x) * 0.001;
    }
  });

  // Flickering lamp for atmosphere
  D3Engine.scene.children.forEach(child => {
    if (child.isPointLight && !D3Engine.flashlightEnabled) {
      child.intensity = 0.7 + Math.sin(time * 3) * 0.05;
    }
  });

  D3Engine.controls.update();
  D3Engine.renderer.render(D3Engine.scene, D3Engine.camera);
}

// ────────────────────────────────────────────
// 13.  RESIZE HANDLER
// ────────────────────────────────────────────
function on3DResize() {
  const container = document.getElementById('scene-3d-container');
  if (!container || !D3Engine.renderer) return;
  const W = container.clientWidth;
  const H = container.clientHeight;
  D3Engine.camera.aspect = W / H;
  D3Engine.camera.updateProjectionMatrix();
  D3Engine.renderer.setSize(W, H);
}

// ────────────────────────────────────────────
// 14.  CLEANUP
// ────────────────────────────────────────────
function destroy3DScene() {
  D3Engine.isActive = false;
  if (D3Engine.animFrameId) cancelAnimationFrame(D3Engine.animFrameId);
  cleanup360Inspector();
  if (D3Engine.renderer) {
    D3Engine.renderer.dispose();
    const canvas = D3Engine.renderer.domElement;
    if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
    D3Engine.renderer = null;
  }
  D3Engine.scene = null;
  D3Engine.interactables = [];
  window.removeEventListener('resize', on3DResize);
}

// ────────────────────────────────────────────
// 15.  NOTIFICATION SYSTEM
// ────────────────────────────────────────────
function showScene3DNotification(msg) {
  let notif = document.getElementById('scene3d-notification');
  if (!notif) {
    notif = document.createElement('div');
    notif.id = 'scene3d-notification';
    notif.style.cssText = `
      position:fixed; bottom:80px; left:50%; transform:translateX(-50%);
      background:rgba(15,15,20,0.95); color:#ffd700; font-family:'Cairo',sans-serif;
      font-size:0.88rem; font-weight:700; padding:10px 20px; border-radius:12px;
      border:1px solid rgba(255,215,0,0.4); z-index:9999; text-align:center;
      max-width:320px; box-shadow:0 4px 20px rgba(0,0,0,0.6);
      backdrop-filter:blur(10px); transition:opacity 0.3s ease;
    `;
    document.body.appendChild(notif);
  }
  notif.textContent = msg;
  notif.style.opacity = '1';
  notif.style.display = 'block';
  clearTimeout(notif._timeout);
  notif._timeout = setTimeout(() => {
    notif.style.opacity = '0';
    setTimeout(() => { notif.style.display = 'none'; }, 300);
  }, 3500);
}

// ────────────────────────────────────────────
// 16.  GLOBAL EXPORTS
// ────────────────────────────────────────────
window.D3Engine = D3Engine;
window.init3DCrimeScene       = init3DCrimeScene;
window.toggle3DFlashlight     = toggle3DFlashlight;
window.destroy3DScene         = destroy3DScene;
window.update3DSuspectExpression = update3DSuspectExpression;
window.apply3DSpotlightEffect    = apply3DSpotlightEffect;
window.open3DEvidenceInspector   = open3DEvidenceInspector;
window.showScene3DNotification   = showScene3DNotification;
window.cleanup360Inspector       = cleanup360Inspector;
