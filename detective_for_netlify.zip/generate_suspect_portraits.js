const fs = require('fs');
const path = require('path');

const levelsPath = path.join(__dirname, 'levels.json');
const outputDir = path.join(__dirname, 'images', 'suspects');

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

let rawData = fs.readFileSync(levelsPath, 'utf8');
if (rawData.charCodeAt(0) === 0xFEFF) {
  rawData = rawData.slice(1);
}
const levels = JSON.parse(rawData);

// Female name detection hints
const FEMALE_HINTS = [
  'عبير', 'آية', 'نور', 'ريم', 'سارة', 'هناء', 'رانيا', 'ندى', 'لمى', 'إيمان', 'دينا', 'هدى', 'منى',
  'سمر', 'رشا', 'غادة', 'مريم', 'أميرة', 'ياسمين', 'روان', 'لينا', 'هبة', 'شيرين', 'نيفين', 'فاطمة',
  'زينب', 'أسماء', 'خديجة', 'عائشة', 'حنان', 'سحر', 'ابتسام', 'إبتسام', 'وفاء', 'سهام', 'هالة',
  'أمل', 'شيماء', 'ناهد', 'فايزة', 'فريدة', 'إلهام', 'راندا', 'إنجي', 'ميرنا', 'شادية', 'نيللي',
  'نيلي', 'لوسي', 'دعاء', 'رحاب', 'أروى', 'ألاء', 'علا', 'ولاء', 'نجلاء', 'سلمى', 'ليلى', 'نهى',
  'ميار', 'ميس', 'رنا', 'تالا', 'جنى', 'لارا', 'لارة', 'دلال', 'أفنان', 'رغد', 'ريف', 'ريهام',
  'شهد', 'كوثر', 'بسمة', 'بسمه', 'هيا', 'هيام', 'أهداف', 'نادية', 'نرمين', 'منال', 'مروة', 'مها',
  'نادين', 'كريمة', 'حليمة', 'حسناء', 'فاتن', 'فاتنة', 'صفاء', 'سناء', 'سمية', 'سميرة', 'صباح',
  'لبنى', 'لمار', 'رهف', 'لانا', 'تغريد', 'وفاء', 'خلود', 'سلوى', 'مي'
];

function isFemaleName(name) {
  if (!name) return false;
  const n = name.trim();
  const first = n.split(' ')[0];
  if (first.endsWith('ة') || first.endsWith('ى') || first.endsWith('اء')) return true;
  return FEMALE_HINTS.some(h => n.includes(h));
}

// Simple deterministic hash
function hashString(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) + str.charCodeAt(i);
    hash = hash & hash;
  }
  return Math.abs(hash);
}

// Skin tones palette (Authentic Middle Eastern tones)
const SKIN_TONES = [
  { base: '#f4c7a5', shadow: '#d89b72', highlight: '#fbe2cd', lip: '#c97272' },
  { base: '#e8b288', shadow: '#be7e54', highlight: '#f5ccae', lip: '#b75b5b' },
  { base: '#d89c6d', shadow: '#ad6a3d', highlight: '#e8b894', lip: '#9b4e4e' },
  { base: '#c68453', shadow: '#96562a', highlight: '#dba277', lip: '#883e3e' },
  { base: '#f7d3ba', shadow: '#daa484', highlight: '#fde9dc', lip: '#d68282' },
];

// Hair colors palette
const HAIR_COLORS = [
  { main: '#1a1412', dark: '#0c0908', highlight: '#382a24' },
  { main: '#2c1b18', dark: '#180d0b', highlight: '#4a2f2a' },
  { main: '#3a2016', dark: '#22110a', highlight: '#5e3725' },
  { main: '#111111', dark: '#050505', highlight: '#292929' },
  { main: '#423229', dark: '#291d17', highlight: '#634c3e' },
  { main: '#555555', dark: '#333333', highlight: '#777777' }, // grey/silver
];

// Eye colors
const EYE_COLORS = ['#3d2314', '#2b170c', '#4a3319', '#1f382b', '#243340'];

// Suit/Outfit colors by category
const SUIT_COLORS = [
  { jacket: '#1b2430', lapel: '#131b24', shirt: '#ffffff', tie: '#9e2a2b', accent: '#ffd700' },
  { jacket: '#2b2d42', lapel: '#1d1e2c', shirt: '#edf2f4', tie: '#3a86ff', accent: '#00f0ff' },
  { jacket: '#1e2022', lapel: '#141516', shirt: '#f0f0f0', tie: '#e63946', accent: '#ffb703' },
  { jacket: '#283618', lapel: '#1b2410', shirt: '#fefae0', tie: '#bc6c25', accent: '#dda15e' },
  { jacket: '#3d348b', lapel: '#272159', shirt: '#ffffff', tie: '#f72585', accent: '#7209b7' },
  { jacket: '#14213d', lapel: '#0d1629', shirt: '#ffffff', tie: '#fca311', accent: '#fca311' }
];

function generateSuspectSVG(suspect, levelNum, suspectIdx) {
  const name = suspect.name || `مشتبه ${suspectIdx}`;
  const role = suspect.role || 'مشتبه به';
  const isFemale = isFemaleName(name);
  const hash = hashString(name + '_' + role);

  const skin = SKIN_TONES[hash % SKIN_TONES.length];
  const hair = HAIR_COLORS[(hash >> 2) % HAIR_COLORS.length];
  const eyeColor = EYE_COLORS[(hash >> 4) % EYE_COLORS.length];
  const outfit = SUIT_COLORS[(hash >> 6) % SUIT_COLORS.length];

  const hasGlasses = (role.includes('محاسب') || role.includes('تقني') || role.includes('معلومات') || role.includes('أرشيف') || (hash % 5 === 0));
  const hasBeard = !isFemale && ((hash % 3 === 0) || role.includes('حارس') || role.includes('سائق'));
  const hasMustache = !isFemale && !hasBeard && (hash % 4 === 0);

  // Determine Profession Theme
  let roleIcon = '👤';
  let badgeColor = outfit.accent;
  let uniformType = 'business'; // business, security, medical, tech, worker, elegant

  if (role.includes('حارس') || role.includes('أمن') || role.includes('حراسة') || role.includes('شخصي')) {
    uniformType = 'security';
    roleIcon = '🛡️';
  } else if (role.includes('طبيب') || role.includes('دكتور') || role.includes('صيدل') || role.includes('مستشفى') || role.includes('شرعي')) {
    uniformType = 'medical';
    roleIcon = '⚕️';
  } else if (role.includes('تقني') || role.includes('كمبيوتر') || role.includes('معلومات') || role.includes('مبرمج') || role.includes('هاكر')) {
    uniformType = 'tech';
    roleIcon = '💻';
  } else if (role.includes('نظافة') || role.includes('خادمة') || role.includes('طاهي') || role.includes('طباخ') || role.includes('سائق') || role.includes('بواب')) {
    uniformType = 'worker';
    roleIcon = '🔧';
  } else if (role.includes('آثار') || role.includes('متحف') || role.includes('سياحة')) {
    uniformType = 'archaeology';
    roleIcon = '🏺';
  } else if (role.includes('شريك') || role.includes('ثري') || role.includes('مدير') || role.includes('رئيس')) {
    uniformType = 'executive';
    roleIcon = '💼';
  } else if (role.includes('سكرتير') || role.includes('مساعد')) {
    uniformType = 'assistant';
    roleIcon = '📋';
  }

  // Hair style index
  const hairStyle = hash % 4;

  // Background gradient colors
  const bgGradients = [
    { start: '#0d131f', end: '#060910', accent: '#1a2c47' },
    { start: '#190e1f', end: '#0a050d', accent: '#381647' },
    { start: '#141c14', end: '#080d08', accent: '#213b21' },
    { start: '#1f130e', end: '#0d0705', accent: '#472718' },
    { start: '#131b1f', end: '#060a0d', accent: '#1c3e4a' }
  ];
  const bg = bgGradients[(levelNum + suspectIdx) % bgGradients.length];

  // SVG Generation
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 560" width="400" height="560">
  <defs>
    <!-- Background Gradients -->
    <linearGradient id="bgGrad_${hash}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${bg.start}"/>
      <stop offset="60%" stop-color="${bg.accent}"/>
      <stop offset="100%" stop-color="${bg.end}"/>
    </linearGradient>

    <radialGradient id="spotlight_${hash}" cx="50%" cy="35%" r="55%">
      <stop offset="0%" stop-color="rgba(255, 255, 255, 0.12)"/>
      <stop offset="60%" stop-color="rgba(0, 0, 0, 0)"/>
      <stop offset="100%" stop-color="rgba(0, 0, 0, 0.6)"/>
    </radialGradient>

    <linearGradient id="skinGrad_${hash}" x1="30%" y1="0%" x2="70%" y2="100%">
      <stop offset="0%" stop-color="${skin.highlight}"/>
      <stop offset="50%" stop-color="${skin.base}"/>
      <stop offset="100%" stop-color="${skin.shadow}"/>
    </linearGradient>

    <linearGradient id="hairGrad_${hash}" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${hair.highlight}"/>
      <stop offset="40%" stop-color="${hair.main}"/>
      <stop offset="100%" stop-color="${hair.dark}"/>
    </linearGradient>

    <linearGradient id="suitGrad_${hash}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${outfit.jacket}"/>
      <stop offset="100%" stop-color="${outfit.lapel}"/>
    </linearGradient>

    <linearGradient id="accentGrad_${hash}" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ff416c"/>
      <stop offset="100%" stop-color="#ff4b2b"/>
    </linearGradient>

    <!-- Clip Path for Card Frame -->
    <clipPath id="cardClip_${hash}">
      <rect x="0" y="0" width="400" height="560" rx="16" ry="16"/>
    </clipPath>

    <!-- Drop Shadow -->
    <filter id="shadow_${hash}" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="6" stdDeviation="6" flood-color="rgba(0,0,0,0.6)"/>
    </filter>
  </defs>

  <g clip-path="url(#cardClip_${hash})">
    <!-- Base Card Background -->
    <rect width="400" height="560" fill="url(#bgGrad_${hash})"/>
    <rect width="400" height="560" fill="url(#spotlight_${hash})"/>

    <!-- Grid / Noir Overlay Lines -->
    <g stroke="rgba(255,255,255,0.03)" stroke-width="1">
      <line x1="0" y1="80" x2="400" y2="80"/>
      <line x1="0" y1="160" x2="400" y2="160"/>
      <line x1="0" y1="240" x2="400" y2="240"/>
      <line x1="0" y1="320" x2="400" y2="320"/>
      <line x1="0" y1="400" x2="400" y2="400"/>
      <line x1="80" y1="0" x2="80" y2="480"/>
      <line x1="160" y1="0" x2="160" y2="480"/>
      <line x1="240" y1="0" x2="240" y2="480"/>
      <line x1="320" y1="0" x2="320" y2="480"/>
    </g>

    <!-- Top Dossier Banner -->
    <rect x="16" y="14" width="368" height="32" rx="6" fill="rgba(0,0,0,0.5)" stroke="rgba(255,255,255,0.1)" stroke-width="1"/>
    <text x="32" y="35" fill="#e0e0e0" font-family="'Cairo', 'Segoe UI', sans-serif" font-size="12" font-weight="700" letter-spacing="1">DOSSIER #0${levelNum}</text>
    <text x="368" y="35" text-anchor="end" fill="${badgeColor}" font-family="'Cairo', 'Segoe UI', sans-serif" font-size="12" font-weight="800">مشتبه ${suspectIdx}</text>

    <!-- Portrait Illustration -->
    <g transform="translate(0, 10)" filter="url(#shadow_${hash})">
      
      <!-- Shoulders & Body / Outfit -->
      ${generateOutfit(uniformType, outfit, hash)}

      <!-- Neck -->
      <path d="M 172 250 L 172 295 C 172 310 228 310 228 295 L 228 250 Z" fill="${skin.shadow}"/>
      <path d="M 176 250 L 176 290 C 176 300 224 300 224 290 L 224 250 Z" fill="url(#skinGrad_${hash})"/>

      <!-- Head Base -->
      <ellipse cx="200" cy="205" rx="58" ry="72" fill="url(#skinGrad_${hash})"/>

      <!-- Ears -->
      <ellipse cx="140" cy="210" rx="9" ry="16" fill="${skin.shadow}"/>
      <ellipse cx="142" cy="210" rx="6" ry="12" fill="${skin.base}"/>
      <ellipse cx="260" cy="210" rx="9" ry="16" fill="${skin.shadow}"/>
      <ellipse cx="258" cy="210" rx="6" ry="12" fill="${skin.base}"/>
      ${isFemale ? `<circle cx="142" cy="224" r="3.5" fill="#ffd700"/><circle cx="258" cy="224" r="3.5" fill="#ffd700"/>` : ''}

      <!-- Eyes & Brows -->
      ${generateEyes(isFemale, eyeColor, skin, hash)}

      <!-- Nose -->
      <path d="M 200 195 L 195 224 Q 200 229 205 224 Z" fill="${skin.shadow}"/>
      <path d="M 197 222 Q 200 226 203 222" stroke="${skin.shadow}" stroke-width="2" fill="none"/>

      <!-- Mouth & Expression -->
      <path d="M 186 248 Q 200 255 214 248" stroke="${skin.lip}" stroke-width="${isFemale ? '3' : '2'}" fill="none" stroke-linecap="round"/>
      ${isFemale ? `<path d="M 189 249 Q 200 256 211 249" fill="${skin.lip}" opacity="0.6"/>` : ''}

      <!-- Facial Hair (for men) -->
      ${hasBeard ? `<path d="M 148 200 Q 146 255 170 270 Q 200 282 230 270 Q 254 255 252 200 Q 250 240 230 260 Q 200 270 170 260 Q 150 240 148 200 Z" fill="${hair.dark}" opacity="0.85"/>` : ''}
      ${hasMustache ? `<path d="M 185 240 Q 200 237 215 240 Q 200 246 185 240 Z" fill="${hair.dark}" opacity="0.9"/>` : ''}

      <!-- Glasses -->
      ${hasGlasses ? `
        <!-- Left Lens -->
        <rect x="160" y="185" width="32" height="24" rx="6" fill="rgba(255,255,255,0.15)" stroke="#e0e0e0" stroke-width="2.5"/>
        <!-- Right Lens -->
        <rect x="208" y="185" width="32" height="24" rx="6" fill="rgba(255,255,255,0.15)" stroke="#e0e0e0" stroke-width="2.5"/>
        <!-- Bridge & Temples -->
        <line x1="192" y1="195" x2="208" y2="195" stroke="#e0e0e0" stroke-width="2.5"/>
        <line x1="140" y1="192" x2="160" y2="192" stroke="#e0e0e0" stroke-width="2"/>
        <line x1="240" y1="192" x2="260" y2="192" stroke="#e0e0e0" stroke-width="2"/>
        <line x1="164" y1="189" x2="180" y2="202" stroke="rgba(255,255,255,0.5)" stroke-width="1.5"/>
      ` : ''}

      <!-- Hair Style -->
      ${generateHair(isFemale, hairStyle, hair, hash)}
    </g>

    <!-- Bottom Nameplate Card -->
    <g transform="translate(16, 442)">
      <!-- Nameplate Background Glass -->
      <rect width="368" height="96" rx="12" fill="rgba(15, 18, 28, 0.92)" stroke="rgba(255, 255, 255, 0.12)" stroke-width="1.2"/>
      
      <!-- Top Accent Line -->
      <rect x="0" y="0" width="368" height="3" fill="url(#accentGrad_${hash})" rx="1.5"/>

      <!-- Role Icon Badge -->
      <rect x="14" y="14" width="42" height="42" rx="8" fill="rgba(255, 255, 255, 0.06)" stroke="rgba(255, 255, 255, 0.1)" stroke-width="1"/>
      <text x="35" y="42" font-size="22" text-anchor="middle">${roleIcon}</text>

      <!-- Suspect Name -->
      <text x="68" y="38" fill="#ffffff" font-family="'Cairo', 'Tajawal', sans-serif" font-size="18" font-weight="900" text-anchor="start">${name}</text>

      <!-- Suspect Role -->
      <text x="68" y="58" fill="${badgeColor}" font-family="'Cairo', 'Tajawal', sans-serif" font-size="13" font-weight="700" text-anchor="start">${role}</text>

      <!-- Status Tag -->
      <g transform="translate(268, 18)">
        <rect width="86" height="24" rx="6" fill="rgba(255, 65, 108, 0.15)" stroke="rgba(255, 65, 108, 0.4)" stroke-width="1"/>
        <text x="43" y="16" fill="#ff4b2b" font-family="'Cairo', sans-serif" font-size="11" font-weight="800" text-anchor="middle">تحت التحقيق</text>
      </g>

      <!-- Fingerprint / Case Details Bar -->
      <g transform="translate(14, 68)" opacity="0.6">
        <line x1="0" y1="0" x2="340" y2="0" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
        <text x="0" y="18" fill="#8e9bb0" font-family="'Cairo', sans-serif" font-size="10">ملف القضية: ${levelNum} | البصمة: #${hash.toString(16).substring(0, 6).toUpperCase()}</text>
        <text x="340" y="18" fill="#8e9bb0" font-family="'Cairo', sans-serif" font-size="10" text-anchor="end">أقوال مسجلة 🎙️</text>
      </g>
    </g>

    <!-- Outer Card Border Highlight -->
    <rect x="1" y="1" width="398" height="558" rx="15" fill="none" stroke="rgba(255, 255, 255, 0.1)" stroke-width="1.5"/>
  </g>
</svg>`;
}

function generateOutfit(type, outfit, hash) {
  switch (type) {
    case 'security':
      return `
        <!-- Security Uniform -->
        <path d="M 100 370 L 130 280 Q 200 300 270 280 L 300 370 Z" fill="#141c2b"/>
        <!-- Epaulets -->
        <rect x="115" y="280" width="32" height="14" rx="3" fill="#c99700" transform="rotate(-15 115 280)"/>
        <rect x="253" y="272" width="32" height="14" rx="3" fill="#c99700" transform="rotate(15 253 272)"/>
        <!-- Shirt & Tie -->
        <polygon points="175,285 200,340 225,285" fill="#f0f4f8"/>
        <polygon points="194,300 206,300 203,370 197,370" fill="#0b1017"/>
        <!-- Gold Badge -->
        <polygon points="145,315 155,310 160,322 155,332 145,332 140,322" fill="#ffd700" stroke="#b8860b" stroke-width="1"/>
      `;
    case 'medical':
      return `
        <!-- Doctor Lab Coat -->
        <path d="M 90 370 L 125 280 Q 200 295 275 280 L 310 370 Z" fill="#edf2f7"/>
        <!-- Scrubs under -->
        <polygon points="170,285 200,345 230,285" fill="#2b6cb0"/>
        <!-- Stethoscope -->
        <path d="M 160 285 Q 165 340 185 345 Q 195 348 200 360" stroke="#4a5568" stroke-width="3.5" fill="none"/>
        <circle cx="200" cy="360" r="7" fill="#cbd5e0" stroke="#4a5568" stroke-width="2"/>
        <!-- Pocket with Pens -->
        <rect x="135" y="325" width="26" height="32" rx="3" fill="#e2e8f0" stroke="#cbd5e0" stroke-width="1"/>
        <line x1="142" y1="318" x2="142" y2="328" stroke="#3182ce" stroke-width="2.5"/>
        <line x1="149" y1="316" x2="149" y2="328" stroke="#e53e3e" stroke-width="2.5"/>
      `;
    case 'tech':
      return `
        <!-- Tech Hoodie / Cyber Outfit -->
        <path d="M 95 370 L 125 280 Q 200 295 275 280 L 305 370 Z" fill="#1a202c"/>
        <path d="M 155 280 Q 200 330 245 280" fill="none" stroke="#2d3748" stroke-width="16"/>
        <!-- Glowing Cyber Badge -->
        <rect x="138" y="320" width="22" height="32" rx="4" fill="#0d1117" stroke="#00f0ff" stroke-width="1.5"/>
        <circle cx="149" cy="330" r="3" fill="#00f0ff"/>
        <line x1="143" y1="340" x2="155" y2="340" stroke="#00f0ff" stroke-width="1.5"/>
        <!-- Headset Mic -->
        <path d="M 136 210 Q 130 235 155 245" stroke="#718096" stroke-width="2" fill="none"/>
        <circle cx="157" cy="246" r="3" fill="#00f0ff"/>
      `;
    case 'worker':
      return `
        <!-- Worker / Driver / Cleaner Uniform -->
        <path d="M 95 370 L 125 280 Q 200 295 275 280 L 305 370 Z" fill="#2d3748"/>
        <!-- Collar -->
        <polygon points="160,285 200,320 175,340 140,290" fill="#4a5568"/>
        <polygon points="240,285 200,320 225,340 260,290" fill="#4a5568"/>
        <!-- Undershirt -->
        <polygon points="175,285 200,320 225,285" fill="#e2e8f0"/>
        <!-- Name Tag -->
        <rect x="230" y="320" width="34" height="16" rx="3" fill="#ffffff" stroke="#cbd5e0" stroke-width="1"/>
        <line x1="235" y1="328" x2="258" y2="328" stroke="#e53e3e" stroke-width="2"/>
      `;
    default:
      // Business Suit / Executive
      return `
        <!-- Suit Jacket -->
        <path d="M 90 370 L 125 280 Q 200 295 275 280 L 310 370 Z" fill="url(#suitGrad_${hash})"/>
        <!-- Lapels -->
        <polygon points="140,285 190,360 170,360 120,295" fill="${outfit.lapel}"/>
        <polygon points="260,285 210,360 230,360 280,295" fill="${outfit.lapel}"/>
        <!-- White Shirt -->
        <polygon points="175,285 200,350 225,285" fill="${outfit.shirt}"/>
        <!-- Tie -->
        <polygon points="194,295 206,295 204,365 200,372 196,365" fill="${outfit.tie}"/>
        <!-- Tie Clip -->
        <line x1="195" y1="325" x2="205" y2="325" stroke="${outfit.accent}" stroke-width="2"/>
        <!-- Pocket Square -->
        <polygon points="135,325 145,315 155,325" fill="${outfit.tie}"/>
      `;
  }
}

function generateEyes(isFemale, eyeColor, skin, hash) {
  const leftX = 175;
  const rightX = 225;
  const y = 195;

  return `
    <!-- Eyebrows -->
    <path d="M ${leftX - 16} ${y - 12} Q ${leftX} ${y - 18} ${leftX + 14} ${y - 10}" stroke="#1f1610" stroke-width="${isFemale ? '2.8' : '4'}" stroke-linecap="round" fill="none"/>
    <path d="M ${rightX - 14} ${y - 10} Q ${rightX} ${y - 18} ${rightX + 16} ${y - 12}" stroke="#1f1610" stroke-width="${isFemale ? '2.8' : '4'}" stroke-linecap="round" fill="none"/>

    <!-- Eye Sclera -->
    <ellipse cx="${leftX}" cy="${y}" rx="11" ry="7" fill="#ffffff"/>
    <ellipse cx="${rightX}" cy="${y}" rx="11" ry="7" fill="#ffffff"/>

    <!-- Iris -->
    <circle cx="${leftX}" cy="${y}" r="5.5" fill="${eyeColor}"/>
    <circle cx="${rightX}" cy="${y}" r="5.5" fill="${eyeColor}"/>

    <!-- Pupil -->
    <circle cx="${leftX}" cy="${y}" r="3" fill="#000000"/>
    <circle cx="${rightX}" cy="${y}" r="3" fill="#000000"/>

    <!-- Highlights -->
    <circle cx="${leftX - 1.5}" cy="${y - 1.5}" r="1.5" fill="#ffffff"/>
    <circle cx="${rightX - 1.5}" cy="${y - 1.5}" r="1.5" fill="#ffffff"/>

    <!-- Eyelids & Lashes -->
    <path d="M ${leftX - 12} ${y - 2} Q ${leftX} ${y - 8} ${leftX + 12} ${y - 2}" stroke="#1a1412" stroke-width="${isFemale ? '2.5' : '1.5'}" fill="none"/>
    <path d="M ${rightX - 12} ${y - 2} Q ${rightX} ${y - 8} ${rightX + 12} ${y - 2}" stroke="#1a1412" stroke-width="${isFemale ? '2.5' : '1.5'}" fill="none"/>
    ${isFemale ? `
      <line x1="${leftX + 10}" y1="${y - 4}" x2="${leftX + 15}" y2="${y - 8}" stroke="#1a1412" stroke-width="2"/>
      <line x1="${rightX + 10}" y1="${y - 4}" x2="${rightX + 15}" y2="${y - 8}" stroke="#1a1412" stroke-width="2"/>
    ` : ''}
  `;
}

function generateHair(isFemale, style, hair, hash) {
  if (isFemale) {
    if (style === 0) {
      // Sleek Bun with bangs
      return `
        <ellipse cx="200" cy="140" rx="66" ry="42" fill="url(#hairGrad_${hash})"/>
        <circle cx="200" cy="115" r="28" fill="${hair.dark}"/>
        <path d="M 140 180 Q 155 135 200 135 Q 245 135 260 180 Q 240 160 200 160 Q 160 160 140 180 Z" fill="url(#hairGrad_${hash})"/>
        <!-- Side strands -->
        <path d="M 140 180 Q 138 230 148 245" stroke="url(#hairGrad_${hash})" stroke-width="8" stroke-linecap="round" fill="none"/>
        <path d="M 260 180 Q 262 230 252 245" stroke="url(#hairGrad_${hash})" stroke-width="8" stroke-linecap="round" fill="none"/>
      `;
    } else if (style === 1) {
      // Elegant Bob Haircut
      return `
        <path d="M 135 200 C 130 140 150 120 200 120 C 250 120 270 140 265 200 C 275 240 260 265 250 265 C 240 265 255 210 245 165 Q 200 150 155 165 C 145 210 160 265 150 265 C 140 265 125 240 135 200 Z" fill="url(#hairGrad_${hash})"/>
      `;
    } else if (style === 2) {
      // Wavy Long Hair
      return `
        <path d="M 135 200 C 130 130 155 118 200 118 C 245 118 270 130 265 200 C 280 270 265 310 245 320 Q 255 240 245 170 Q 200 150 155 170 Q 145 240 155 320 C 135 310 120 270 135 200 Z" fill="url(#hairGrad_${hash})"/>
      `;
    } else {
      // Hijab / Headscarf Style
      return `
        <path d="M 135 220 C 130 130 150 115 200 115 C 250 115 270 130 265 220 C 275 285 245 320 200 320 C 155 320 125 285 135 220 Z" fill="${hair.dark}"/>
        <path d="M 148 180 Q 200 155 252 180 Q 256 240 200 265 Q 144 240 148 180 Z" fill="none" stroke="${hair.main}" stroke-width="4"/>
      `;
    }
  } else {
    // Male Hair Styles
    if (style === 0) {
      // Classic Side Part
      return `
        <path d="M 138 185 C 135 130 160 120 200 120 C 240 120 265 130 262 185 C 255 150 230 142 200 145 C 170 148 150 155 138 185 Z" fill="url(#hairGrad_${hash})"/>
      `;
    } else if (style === 1) {
      // Modern Fade / Short crop
      return `
        <path d="M 142 180 C 140 135 165 125 200 125 C 235 125 260 135 258 180 C 255 155 235 145 200 145 C 165 145 145 155 142 180 Z" fill="url(#hairGrad_${hash})"/>
      `;
    } else if (style === 2) {
      // Textured Pompadour
      return `
        <path d="M 138 185 C 135 115 170 105 200 105 C 235 105 265 120 262 185 C 255 145 230 138 200 140 C 170 142 150 150 138 185 Z" fill="url(#hairGrad_${hash})"/>
      `;
    } else {
      // Slicked Back / Distinguished
      return `
        <path d="M 140 190 C 138 135 160 122 200 122 C 240 122 262 135 260 190 C 252 160 230 150 200 150 C 170 150 148 160 140 190 Z" fill="url(#hairGrad_${hash})"/>
      `;
    }
  }
}

// Generate all 300 SVG files
console.log('Generating 300 bespoke detective character portraits...');
let count = 0;

levels.forEach(lvl => {
  const levelNum = lvl.level || lvl.Level;
  if (!lvl.suspects || !Array.isArray(lvl.suspects)) return;

  lvl.suspects.forEach((suspect, idx) => {
    const suspectIdx = idx + 1;
    const svgContent = generateSuspectSVG(suspect, levelNum, suspectIdx);
    const fileName = `level_${levelNum}_suspect_${suspectIdx}.svg`;
    const filePath = path.join(outputDir, fileName);

    fs.writeFileSync(filePath, svgContent, 'utf8');
    count++;
  });
});

console.log(`Successfully generated ${count} character SVG portraits in ${outputDir}!`);
