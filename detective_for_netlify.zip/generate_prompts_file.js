const fs = require('fs');
const path = require('path');

const levels = JSON.parse(fs.readFileSync(path.join(__dirname, 'levels.json'), 'utf8'));

const promptsCatalog = [];

levels.forEach(lvl => {
  const levelNum = lvl.level || lvl.Level;
  const location = lvl.sceneLocation || 'موقع الحادث';
  
  lvl.suspects.forEach((suspect, idx) => {
    const suspectIdx = idx + 1;
    const prompt = `Cinematic realistic photograph of an Egyptian ${suspect.role} named ${suspect.name}, at ${location}, moody noir crime scene lighting, dramatic shadows, 8k resolution, photorealistic portrait, depth of field, high detail.`;
    
    promptsCatalog.push({
      level: levelNum,
      caseTitle: lvl.title,
      suspectIndex: suspectIdx,
      name: suspect.name,
      role: suspect.role,
      targetFilename: `level_${levelNum}_suspect_${suspectIdx}.jpg`,
      prompt: prompt
    });
  });
});

fs.writeFileSync(path.join(__dirname, 'all_character_prompts.json'), JSON.stringify(promptsCatalog, null, 2), 'utf8');
console.log(`Generated ${promptsCatalog.length} cinematic prompts in all_character_prompts.json`);
