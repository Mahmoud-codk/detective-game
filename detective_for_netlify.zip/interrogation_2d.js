/* ═══════════════════════════════════════════════════════════════════
   🎭  INTERROGATION 2D ENGINE — Animated Suspect + Lie Detection
   ═══════════════════════════════════════════════════════════════════
   Features:
   • Suspect idle breathing animation (chest rise / subtle scale)
   • Random blinking (eyelid canvas overlay on portrait)
   • Emotional state machine: Calm → Nervous → Breaking
   • Sweat particle effects when nervous
   • Heartbeat/pulse bar visual animation
   • Screen micro-shake on breaking point
   • Red flash overlay on confrontation
   • Eye direction hints (looking away = lying indicator)
   • Smoke/steam atmospheric particles
   • All integrated with existing startInterrogation() + pressureBar
   ═══════════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ──────────────────────────────────────────────────────────────
     STATE MACHINE
  ────────────────────────────────────────────────────────────── */
  const STATES = { CALM: 0, UNEASY: 1, NERVOUS: 2, BREAKING: 3 };

  const IS = {
    state: STATES.CALM,
    pressure: 0,        // 0–100 (mirrors DOM pressure bar)
    tick: 0,
    rafId: null,
    blinkTimer: 0,
    blinkDuration: 0,
    blinking: false,
    breathScale: 1,
    breathDir: 1,
    sweatParticles: [],
    eyeOffset: 0,       // -1 (look away) to 1 (eye contact)
    eyeTarget: 0,
    shakeX: 0, shakeY: 0,
    flashAlpha: 0,
    smokeParticles: [],
    isCulprit: false,
    suspectImgEl: null,
    overlayCanvas: null,
    overlayCtx: null,
    portraitWrap: null,
    active: false,
  };

  /* ──────────────────────────────────────────────────────────────
     INIT (called once on DOMContentLoaded)
  ────────────────────────────────────────────────────────────── */
  function init() {
    // Create overlay canvas on top of suspect portrait
    const imgFrame = document.querySelector('.suspect-img-frame');
    if (!imgFrame) return;

    IS.suspectImgEl = document.getElementById('interrogate-img');
    IS.portraitWrap = imgFrame;

    // Overlay canvas (same size as portrait)
    IS.overlayCanvas = document.createElement('canvas');
    IS.overlayCanvas.style.cssText = `
      position:absolute; inset:0; width:100%; height:100%;
      pointer-events:none; z-index:10;
      border-radius: inherit;
    `;
    imgFrame.style.position = 'relative';
    imgFrame.appendChild(IS.overlayCanvas);

    // Atmosphere canvas (room ambiance)
    createAtmosphere();
    resizeOverlay();
    window.addEventListener('resize', resizeOverlay);
    spawnSmoke();
    scheduleNextBlink();
  }

  function resizeOverlay() {
    const frame = IS.portraitWrap;
    if (!frame || !IS.overlayCanvas) return;
    IS.overlayCanvas.width = frame.offsetWidth || 200;
    IS.overlayCanvas.height = frame.offsetHeight || 240;
    IS.overlayCtx = IS.overlayCanvas.getContext('2d');
  }

  /* Atmospheric background particles on interrogation screen */
  function createAtmosphere() {
    const screen = document.getElementById('interrogation-screen');
    if (!screen) return;

    const atmoCanvas = document.createElement('canvas');
    atmoCanvas.id = 'interrogation-atmosphere';
    atmoCanvas.style.cssText = `
      position:absolute; inset:0; width:100%; height:100%;
      pointer-events:none; z-index:0; opacity:0.4;
    `;
    screen.style.position = 'relative';
    screen.insertBefore(atmoCanvas, screen.firstChild);
  }

  /* ──────────────────────────────────────────────────────────────
     PUBLIC API (called from game.js)
  ────────────────────────────────────────────────────────────── */
  window.Interrogation2D = {
    start(isCulprit) {
      IS.isCulprit = isCulprit;
      IS.state = STATES.CALM;
      IS.pressure = 0;
      IS.tick = 0;
      IS.blinking = false;
      IS.shakeX = IS.shakeY = 0;
      IS.flashAlpha = 0;
      IS.eyeTarget = isCulprit ? -0.3 : 0.2;  // culprits look slightly away
      IS.active = true;
      IS.sweatParticles = [];
      resizeOverlay();
      if (!IS.rafId) loop();
    },

    stop() {
      IS.active = false;
      if (IS.rafId) { cancelAnimationFrame(IS.rafId); IS.rafId = null; }
      clearPortraitOverlay();
      resetPortraitTransform();
    },

    setPressure(pct) {
      IS.pressure = Math.max(0, Math.min(100, pct));
      updateState();
    },

    triggerConfrontation() {
      IS.flashAlpha = 1.0;
      IS.shakeX = 8; IS.shakeY = 4;
      IS.state = STATES.BREAKING;
      spawnBurstSweat(20);
      // Haptic (if supported)
      if (navigator.vibrate) navigator.vibrate([80, 30, 120]);
    },

    triggerLie() {
      IS.flashAlpha = 0.4;
      IS.shakeX = 4; IS.shakeY = 2;
      // Eye look away sharply
      IS.eyeTarget = IS.isCulprit ? -0.8 : -0.2;
      setTimeout(() => { IS.eyeTarget = IS.isCulprit ? -0.3 : 0.2; }, 1500);
      spawnBurstSweat(8);
    },
  };

  function updateState() {
    const p = IS.pressure;
    if (p < 30) IS.state = STATES.CALM;
    else if (p < 60) IS.state = STATES.UNEASY;
    else if (p < 85) IS.state = STATES.NERVOUS;
    else IS.state = STATES.BREAKING;
  }

  /* ──────────────────────────────────────────────────────────────
     BLINK SCHEDULER
  ────────────────────────────────────────────────────────────── */
  function scheduleNextBlink() {
    const minInterval = IS.state >= STATES.NERVOUS ? 1200 : 2500;
    const maxInterval = IS.state >= STATES.NERVOUS ? 3000 : 6000;
    const delay = minInterval + Math.random() * (maxInterval - minInterval);
    setTimeout(() => {
      IS.blinking = true;
      IS.blinkDuration = 120 + Math.random() * 80; // ms
      setTimeout(() => {
        IS.blinking = false;
        scheduleNextBlink();
      }, IS.blinkDuration);
    }, delay);
  }

  /* ──────────────────────────────────────────────────────────────
     SWEAT PARTICLES
  ────────────────────────────────────────────────────────────── */
  function spawnBurstSweat(count) {
    const W = IS.overlayCanvas ? IS.overlayCanvas.width : 200;
    for (let i = 0; i < count; i++) {
      IS.sweatParticles.push({
        x: 0.3 + Math.random() * 0.4,
        y: 0.15 + Math.random() * 0.35,
        vy: 0.002 + Math.random() * 0.003,
        vx: (Math.random() - 0.5) * 0.001,
        life: 0,
        maxLife: 0.8 + Math.random() * 0.5,
        size: 2 + Math.random() * 3,
      });
    }
  }

  function tickSweat() {
    const dt = 1 / 60;
    IS.sweatParticles = IS.sweatParticles.filter(p => p.life < p.maxLife);
    for (const p of IS.sweatParticles) {
      p.life += dt;
      p.x += p.vx;
      p.y += p.vy;
    }
    // Auto-spawn sweat in nervous/breaking state
    if (IS.state >= STATES.NERVOUS && IS.tick % 18 === 0) {
      const intensity = IS.state === STATES.BREAKING ? 3 : 1;
      spawnBurstSweat(intensity);
    }
  }

  /* Smoke */
  function spawnSmoke() {
    IS.smokeParticles = [];
    for (let i = 0; i < 12; i++) {
      IS.smokeParticles.push(newSmokeParticle(true));
    }
  }

  function newSmokeParticle(randomStart) {
    return {
      x: 0.1 + Math.random() * 0.8,
      y: randomStart ? Math.random() * 0.3 + 0.6 : 1.05,
      vy: -(0.0003 + Math.random() * 0.0004),
      vx: (Math.random() - 0.5) * 0.0002,
      life: randomStart ? Math.random() : 0,
      maxLife: 3 + Math.random() * 2,
      size: 20 + Math.random() * 30,
      alpha: 0.04 + Math.random() * 0.06,
    };
  }

  /* ──────────────────────────────────────────────────────────────
     BREATHING ANIMATION (CSS transform on portrait)
  ────────────────────────────────────────────────────────────── */
  function animateBreathing() {
    const speed = IS.state >= STATES.NERVOUS ? 0.06 : 0.025;
    const range = IS.state >= STATES.NERVOUS ? 0.012 : 0.006;

    IS.breathScale += IS.breathDir * speed * range;
    if (IS.breathScale > 1 + range) IS.breathDir = -1;
    if (IS.breathScale < 1 - range * 0.3) IS.breathDir = 1;

    // Shake
    if (IS.shakeX > 0.3) {
      IS.shakeX *= 0.85;
      IS.shakeY *= 0.85;
    } else {
      IS.shakeX = IS.shakeY = 0;
    }

    const sx = IS.shakeX ? (Math.random() - 0.5) * IS.shakeX : 0;
    const sy = IS.shakeY ? (Math.random() - 0.5) * IS.shakeY : 0;

    if (IS.suspectImgEl) {
      IS.suspectImgEl.style.transform = `scale(${IS.breathScale}) translate(${sx}px,${sy}px)`;
      IS.suspectImgEl.style.transition = IS.shakeX > 0 ? 'none' : 'transform 0.1s ease';

      // Apply nervous CSS filter
      if (IS.state === STATES.BREAKING) {
        IS.suspectImgEl.style.filter = 'saturate(1.8) contrast(1.2) hue-rotate(-10deg)';
      } else if (IS.state === STATES.NERVOUS) {
        IS.suspectImgEl.style.filter = 'saturate(1.3) contrast(1.1)';
      } else {
        IS.suspectImgEl.style.filter = '';
      }
    }
  }

  function resetPortraitTransform() {
    if (IS.suspectImgEl) {
      IS.suspectImgEl.style.transform = '';
      IS.suspectImgEl.style.filter = '';
      IS.suspectImgEl.style.transition = '';
    }
  }

  /* ──────────────────────────────────────────────────────────────
     PORTRAIT OVERLAY DRAW (blink, sweat, eye, flash)
  ────────────────────────────────────────────────────────────── */
  function drawPortraitOverlay() {
    const canvas = IS.overlayCanvas;
    const ctx = IS.overlayCtx;
    if (!canvas || !ctx) return;

    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    // ── Blink overlay (eyelid sweep) ──
    if (IS.blinking) {
      // Draw semi-transparent eyelid covers over eye region
      // Eyes typically in upper-middle 15–40% height, 25–75% width
      const eyeY = H * 0.28;
      const eyeH = H * 0.08;

      // Top eyelid
      const lidGrd = ctx.createLinearGradient(0, eyeY - eyeH * 0.5, 0, eyeY + eyeH * 0.5);
      lidGrd.addColorStop(0, 'rgba(60,40,30,0)');
      lidGrd.addColorStop(0.5, 'rgba(60,40,30,0.85)');
      lidGrd.addColorStop(1, 'rgba(60,40,30,0)');
      ctx.fillStyle = lidGrd;
      ctx.fillRect(W * 0.15, eyeY - eyeH * 0.5, W * 0.7, eyeH);
    }

    // ── Eye direction micro-hint ──
    // Smooth lerp eye offset
    IS.eyeOffset += (IS.eyeTarget - IS.eyeOffset) * 0.03;
    // Only draw if notably looking away
    if (Math.abs(IS.eyeOffset) > 0.15) {
      const ex = W * (0.5 + IS.eyeOffset * 0.15);
      const ey = H * 0.28;
      ctx.beginPath();
      ctx.arc(ex, ey, 4, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0,242,254,${Math.abs(IS.eyeOffset) * 0.3})`;
      ctx.fill();
    }

    // ── Sweat drops ──
    for (const p of IS.sweatParticles) {
      const alpha = (1 - p.life / p.maxLife) * 0.8;
      if (alpha <= 0) continue;
      const px = p.x * W, py = p.y * H;

      // Drop shape
      ctx.save();
      ctx.globalAlpha = alpha;
      const grd = ctx.createRadialGradient(px, py - p.size * 0.3, 0, px, py, p.size);
      grd.addColorStop(0, 'rgba(180,220,255,0.9)');
      grd.addColorStop(0.7, 'rgba(120,180,240,0.6)');
      grd.addColorStop(1, 'rgba(100,160,220,0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.ellipse(px, py, p.size * 0.5, p.size, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // ── Red confrontation flash ──
    if (IS.flashAlpha > 0.01) {
      ctx.fillStyle = `rgba(255,40,40,${IS.flashAlpha * 0.45})`;
      ctx.fillRect(0, 0, W, H);
      IS.flashAlpha *= 0.90;
    }

    // ── State vignette tint ──
    if (IS.state >= STATES.UNEASY) {
      const intensity = (IS.state - 1) / 2; // 0–1
      const tint = ctx.createRadialGradient(W / 2, H / 2, H * 0.1, W / 2, H / 2, H * 0.8);
      tint.addColorStop(0, 'rgba(0,0,0,0)');
      tint.addColorStop(1, `rgba(120,0,0,${intensity * 0.25})`);
      ctx.fillStyle = tint;
      ctx.fillRect(0, 0, W, H);
    }
  }

  function clearPortraitOverlay() {
    if (IS.overlayCtx && IS.overlayCanvas) {
      IS.overlayCtx.clearRect(0, 0, IS.overlayCanvas.width, IS.overlayCanvas.height);
    }
  }

  /* ──────────────────────────────────────────────────────────────
     ATMOSPHERE DRAW (smoke on interrogation room bg)
  ────────────────────────────────────────────────────────────── */
  function drawAtmosphere() {
    const canvas = document.getElementById('interrogation-atmosphere');
    if (!canvas) return;

    const screen = document.getElementById('interrogation-screen');
    if (!screen) return;
    if (!canvas.width || canvas.width !== screen.offsetWidth) {
      canvas.width = screen.offsetWidth || 375;
      canvas.height = screen.offsetHeight || 600;
    }
    const W = canvas.width, H = canvas.height;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, W, H);

    const dt = 1 / 60;
    IS.smokeParticles = IS.smokeParticles.filter(p => p.life < p.maxLife);
    for (const p of IS.smokeParticles) {
      p.life += dt;
      p.x += p.vx;
      p.y += p.vy;
      const progress = p.life / p.maxLife;
      const alpha = Math.sin(progress * Math.PI) * p.alpha;
      const r = p.size * (0.5 + progress * 0.5);
      const grd = ctx.createRadialGradient(p.x * W, p.y * H, 0, p.x * W, p.y * H, r);
      grd.addColorStop(0, `rgba(180,160,140,${alpha})`);
      grd.addColorStop(1, 'rgba(140,120,100,0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.arc(p.x * W, p.y * H, r, 0, Math.PI * 2);
      ctx.fill();
    }
    while (IS.smokeParticles.length < 12) IS.smokeParticles.push(newSmokeParticle(false));
  }

  /* ──────────────────────────────────────────────────────────────
     PRESSURE BAR PULSE (visual heartbeat)
  ────────────────────────────────────────────────────────────── */
  function animatePressureBar() {
    const bar = document.getElementById('pressure-bar-fill');
    if (!bar) return;
    const t = IS.tick / 60;
    const beats = IS.state >= STATES.NERVOUS ? 2.5 : 1.2;
    const pulse = 1 + Math.sin(t * Math.PI * beats * 2) * 0.05;
    bar.style.transform = `scaleY(${pulse})`;
    bar.style.transformOrigin = 'center';

    // Colour shifts with pressure
    if (IS.state === STATES.BREAKING) {
      bar.style.background = `linear-gradient(90deg, #ff0000, #ff416c)`;
      bar.style.boxShadow = `0 0 10px rgba(255,0,0,0.7)`;
    } else if (IS.state === STATES.NERVOUS) {
      bar.style.background = `linear-gradient(90deg, #ff6b35, #ff416c)`;
      bar.style.boxShadow = `0 0 8px rgba(255,107,53,0.5)`;
    } else if (IS.state === STATES.UNEASY) {
      bar.style.background = `linear-gradient(90deg, #ffb703, #ff6b35)`;
      bar.style.boxShadow = '';
    } else {
      bar.style.background = '';
      bar.style.boxShadow = '';
    }
  }

  /* ──────────────────────────────────────────────────────────────
     EXPRESSION BOX AUTO-UPDATE
  ────────────────────────────────────────────────────────────── */
  const EXPRESSIONS = {
    face: {
      [STATES.CALM]: '👀 تعابير الوجه: هادئ ويحافظ على التواصل البصري.',
      [STATES.UNEASY]: '😐 تعابير الوجه: يتجنب النظر المباشر أحياناً.',
      [STATES.NERVOUS]: '😰 تعابير الوجه: عرق خفيف، نظرات متقلبة ومتوترة.',
      [STATES.BREAKING]: '😱 تعابير الوجه: احمرار واضح، ارتجاف في الشفتين!',
    },
    body: {
      [STATES.CALM]: '🤚 لغة الجسد: مسترخٍ وإيقاع التنفس طبيعي.',
      [STATES.UNEASY]: '🤚 لغة الجسد: تعلق الأصابع، تنفس أسرع قليلاً.',
      [STATES.NERVOUS]: '🤚 لغة الجسد: تعلق مستمر، تعرق ظاهر، تنفس سريع.',
      [STATES.BREAKING]: '🤚 لغة الجسد: يرتجف، يتحرك باستمرار، على وشك الانهيار!',
    },
  };

  let lastExpressionState = -1;
  function updateExpressionBox() {
    if (IS.state === lastExpressionState) return;
    lastExpressionState = IS.state;
    const face = document.getElementById('expression-face-text');
    const body = document.getElementById('expression-body-text');
    if (face) face.textContent = EXPRESSIONS.face[IS.state] || EXPRESSIONS.face[0];
    if (body) body.textContent = EXPRESSIONS.body[IS.state] || EXPRESSIONS.body[0];
  }

  /* ──────────────────────────────────────────────────────────────
     MAIN LOOP
  ────────────────────────────────────────────────────────────── */
  function loop() {
    if (!IS.active) return;
    IS.tick++;

    tickSweat();
    animateBreathing();
    drawPortraitOverlay();
    drawAtmosphere();
    animatePressureBar();
    updateExpressionBox();

    // Periodically randomize eye direction (culprits avoid gaze more)
    if (IS.tick % 200 === 0) {
      const avoid = IS.isCulprit ? 0.7 : 0.3;
      IS.eyeTarget = Math.random() < avoid
        ? -(0.3 + Math.random() * 0.5)  // look away
        : 0.1 + Math.random() * 0.3;    // eye contact
    }

    IS.rafId = requestAnimationFrame(loop);
  }

  /* ──────────────────────────────────────────────────────────────
     HOOK INTO EXISTING game.js
  ────────────────────────────────────────────────────────────── */
  /* We patch startInterrogation after it's defined */
  function hookGameEngine() {
    // Read pressure updates from the DOM bar (game.js manages it)
    // Observe pressure-pct span for changes
    const pctEl = document.getElementById('pressure-pct');
    if (pctEl && window.MutationObserver) {
      const obs = new MutationObserver(() => {
        const val = parseFloat(pctEl.textContent) || 0;
        if (window.Interrogation2D) window.Interrogation2D.setPressure(val);
      });
      obs.observe(pctEl, { childList: true, characterData: true, subtree: true });
    }

    // Hook btn-back-from-interrogate to stop engine
    const backBtn = document.getElementById('btn-back-from-interrogate');
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        if (window.Interrogation2D) window.Interrogation2D.stop();
      });
    }
  }

  /* ──────────────────────────────────────────────────────────────
     CSS INJECTIONS
  ────────────────────────────────────────────────────────────── */
  const style = document.createElement('style');
  style.textContent = `
    /* Breathing transition on portrait image */
    #interrogate-img {
      transform-origin: center bottom;
      will-change: transform, filter;
    }
    /* Nervous screen tint */
    #interrogation-screen.nervous-state {
      background: linear-gradient(180deg, #0a0005 0%, #07080A 100%) !important;
    }
    /* Pressure bar pulse */
    .pressure-bar-fill {
      transform-origin: center;
      transition: background 0.5s ease, box-shadow 0.5s ease;
    }
    /* Breaking flash keyframe */
    @keyframes breakingFlash {
      0%   { background: rgba(255,0,0,0); }
      20%  { background: rgba(255,0,0,0.25); }
      100% { background: rgba(255,0,0,0); }
    }
    /* Atmospheric smoke z-index */
    #interrogation-atmosphere {
      border-radius: inherit;
    }
  `;
  document.head.appendChild(style);

  /* ──────────────────────────────────────────────────────────────
     BOOT
  ────────────────────────────────────────────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { init(); setTimeout(hookGameEngine, 500); });
  } else {
    init();
    setTimeout(hookGameEngine, 500);
  }

})();

