const fs = require('fs');
const path = require('path');

const rootDir = __dirname;
const imagesDir = path.join(rootDir, 'images');
const suspectsDir = path.join(imagesDir, 'suspects');
const levelsPath = path.join(rootDir, 'levels.json');
const levelsDataPath = path.join(rootDir, 'levels_data.js');

if (!fs.existsSync(suspectsDir)) {
  fs.mkdirSync(suspectsDir, { recursive: true });
}

let raw = fs.readFileSync(levelsPath, 'utf8');
if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
const levels = JSON.parse(raw);

// Strictly segregated pools of realistic photos
const FEMALE_POOLS = {
  maid: ['char_maid.png'],
  secretary_assistant: ['char_2f.png', 'char_7f.png'],
  expert_reception: ['char_11f.png', 'char_9f.png'],
  executive_insurance_tech: ['char_14f.png', 'char_9f.png', 'char_2f.png'],
  friend_partner: ['char_13f.png', 'char_7f.png', 'char_2f.png'],
  all_female: [
    'char_2f.png', 'char_7f.png', 'char_9f.png',
    'char_11f.png', 'char_13f.png', 'char_14f.png', 'char_maid.png'
  ]
};

const MALE_POOLS = {
  guard_security: ['char_guard.png', 'char_12.png', 'char_20.png', 'char_15.png'],
  driver: ['char_17.png', 'char_cleaner.png', 'char_6.png'],
  cleaner: ['char_cleaner.png', 'char_17.png', 'char_19.png'],
  chef: ['char_chef.png', 'char_cleaner.png'],
  accountant: ['char_accountant.png', 'char_5.png', 'char_1.png', 'char_19.png'],
  tech_developer: ['char_16.png', 'char_10.png', 'char_19.png', 'char_15.png'],
  doctor_forensic: ['char_18.png', 'char_19.png', 'char_5.png'],
  archive_records: ['char_19.png', 'char_18.png', 'char_10.png'],
  executive_deputy_partner: ['char_1.png', 'char_3.png', 'char_8.png', 'char_5.png'],
  merchant_client_wealthy: ['char_4.png', 'char_6.png', 'char_1.png', 'char_3.png'],
  competitor_shady_dismissed: ['char_20.png', 'char_8.png', 'char_15.png', 'char_4.png'],
  investigator_journalist: ['char_10.png', 'char_15.png', 'char_5.png'],
  all_male: [
    'char_1.png', 'char_3.png', 'char_4.png', 'char_5.png',
    'char_6.png', 'char_8.png', 'char_10.png', 'char_12.png',
    'char_15.png', 'char_16.png', 'char_17.png', 'char_18.png',
    'char_19.png', 'char_20.png', 'char_guard.png', 'char_accountant.png',
    'char_cleaner.png', 'char_chef.png'
  ]
};

const MALE_EXCEPTIONS = new Set([
  'مصطفى', 'يحيى', 'عيسى', 'موسى', 'مرتضى', 'رضا', 'علاء', 'بهاء', 'ضياء',
  'حمزة', 'أسامة', 'طلحة', 'عبيدة', 'قتادة', 'سلامة', 'جمعة', 'عكرمة', 'عطية'
]);

const FEMALE_NAMES = new Set([
  'عبير', 'آية', 'نور', 'ريم', 'سارة', 'هناء', 'رانيا', 'ندى', 'لمى', 'إيمان',
  'دينا', 'هدى', 'منى', 'سمر', 'رشا', 'غادة', 'مريم', 'أميرة', 'ياسمين', 'روان',
  'لينا', 'هبة', 'شيرين', 'نيفين', 'فاطمة', 'زينب', 'أسماء', 'خديجة', 'عائشة',
  'حنان', 'سحر', 'ابتسام', 'إبتسام', 'وفاء', 'سهام', 'هالة', 'أمل', 'شيماء',
  'ناهد', 'فايزة', 'فريدة', 'إلهام', 'راندا', 'إنجي', 'ميرنا', 'شادية', 'نيللي',
  'نيلي', 'لوسي', 'دعاء', 'رحاب', 'أروى', 'ألاء', 'علا', 'ولاء', 'نجلاء',
  'سلمى', 'ليلى', 'نهى', 'ميار', 'ميس', 'رنا', 'تالا', 'جنى', 'لارا', 'لارة',
  'دلال', 'أفنان', 'رغد', 'ريف', 'ريهام', 'شهد', 'كوثر', 'بسمة', 'بسمه',
  'هيا', 'هيام', 'أهداف', 'نادية', 'نرمين', 'منال', 'مروة', 'مها', 'نادين',
  'كريمة', 'حليمة', 'حسناء', 'فاتن', 'فاتنة', 'صفاء', 'سناء', 'سمية', 'سميرة',
  'صباح', 'لبنى', 'لمار', 'رهف', 'لانا', 'تغريد', 'خلود', 'سلوى', 'مي', 'شهد'
]);

function isFemale(name) {
  if (!name) return false;
  const first = name.trim().split(/\s+/)[0];
  if (MALE_EXCEPTIONS.has(first)) return false;
  if (FEMALE_NAMES.has(first)) return true;
  if (first.endsWith('ة') || first.endsWith('اء')) return true;
  return false;
}

function getCandidates(role, isFem) {
  const r = (role || '').toLowerCase();

  if (isFem) {
    if (r.includes('خادمة') || r.includes('مدبرة')) return FEMALE_POOLS.maid;
    if (r.includes('سكرتير') || r.includes('مساعد') || r.includes('مديرة مكتب')) return FEMALE_POOLS.secretary_assistant;
    if (r.includes('آثار') || r.includes('سياحة') || r.includes('استقبال')) return FEMALE_POOLS.expert_reception;
    if (r.includes('أمن') || r.includes('مشتريات') || r.includes('تأمين') || r.includes('تقني')) return FEMALE_POOLS.executive_insurance_tech;
    if (r.includes('صديقة') || r.includes('شريكة')) return FEMALE_POOLS.friend_partner;
    return FEMALE_POOLS.all_female;
  } else {
    if (r.includes('حارس') || r.includes('أمن') || r.includes('حراسة')) return MALE_POOLS.guard_security;
    if (r.includes('سائق')) return MALE_POOLS.driver;
    if (r.includes('نظافة') || r.includes('فراش') || r.includes('بواب')) return MALE_POOLS.cleaner;
    if (r.includes('طباخ') || r.includes('شيف')) return MALE_POOLS.chef;
    if (r.includes('محاسب') || r.includes('مالي') || r.includes('حسابات') || r.includes('خزينة')) return MALE_POOLS.accountant;
    if (r.includes('كمبيوتر') || r.includes('تقني') || r.includes('معلومات') || r.includes('مطوّر') || r.includes('مبرمج') || r.includes('هاكر')) return MALE_POOLS.tech_developer;
    if (r.includes('طبيب') || r.includes('دكتور') || r.includes('صيدل') || r.includes('شرعي')) return MALE_POOLS.doctor_forensic;
    if (r.includes('أرشيف') || r.includes('مكتبة') || r.includes('سجلات')) return MALE_POOLS.archive_records;
    if (r.includes('صحفي') || r.includes('محقق')) return MALE_POOLS.investigator_journalist;
    if (r.includes('عميل') || r.includes('مجوهرات') || r.includes('موزع')) return MALE_POOLS.merchant_client_wealthy;
    if (r.includes('منافس') || r.includes('مشبوه') || r.includes('مفصول') || r.includes('قاتل')) return MALE_POOLS.competitor_shady_dismissed;
    if (r.includes('نائب') || r.includes('شريك') || r.includes('مدير') || r.includes('رئيس')) return MALE_POOLS.executive_deputy_partner;
    return MALE_POOLS.all_male;
  }
}

let createdCount = 0;

levels.forEach(lvl => {
  const levelNum = lvl.level || lvl.Level;
  if (!lvl.suspects || !Array.isArray(lvl.suspects)) return;

  const usedInCase = new Set();

  lvl.suspects.forEach((suspect, idx) => {
    const suspectIdx = idx + 1;
    const destJpgName = `level_${levelNum}_suspect_${suspectIdx}.jpg`;
    const destJpgPath = path.join(suspectsDir, destJpgName);

    // If already generated by AI generator (e.g. level 1 and 2), preserve it!
    if (fs.existsSync(destJpgPath)) {
      suspect.image = `images/suspects/${destJpgName}`;
      return;
    }

    const fem = isFemale(suspect.name);
    const primaryCandidates = getCandidates(suspect.role, fem);
    const generalPool = fem ? FEMALE_POOLS.all_female : MALE_POOLS.all_male;

    let chosenBase = null;
    const shift = (levelNum * 3 + idx) % primaryCandidates.length;

    for (let i = 0; i < primaryCandidates.length; i++) {
      const img = primaryCandidates[(shift + i) % primaryCandidates.length];
      if (!usedInCase.has(img)) {
        chosenBase = img;
        break;
      }
    }

    if (!chosenBase) {
      const generalShift = (levelNum + idx) % generalPool.length;
      for (let i = 0; i < generalPool.length; i++) {
        const img = generalPool[(generalShift + i) % generalPool.length];
        if (!usedInCase.has(img)) {
          chosenBase = img;
          break;
        }
      }
    }

    if (!chosenBase) chosenBase = primaryCandidates[0];

    usedInCase.add(chosenBase);

    // Copy realistic base photo to dedicated suspect file
    const srcPath = path.join(imagesDir, chosenBase);
    if (fs.existsSync(srcPath)) {
      fs.copyFileSync(srcPath, destJpgPath);
      createdCount++;
    }

    suspect.image = `images/suspects/${destJpgName}`;
  });
});

const jsonOutput = JSON.stringify(levels, null, 2);
fs.writeFileSync(levelsPath, jsonOutput, 'utf8');
fs.writeFileSync(levelsDataPath, `window.PRELOADED_LEVELS = ${jsonOutput};`, 'utf8');

console.log(`Generated all 300 dedicated realistic character image files! Newly created: ${createdCount}`);
